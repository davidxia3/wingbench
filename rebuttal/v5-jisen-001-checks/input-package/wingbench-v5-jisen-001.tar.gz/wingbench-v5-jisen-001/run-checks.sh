#!/bin/bash
set -euo pipefail
# Run inside the pinned Linux scientific container as UID 1000. No CFD.
HANDOFF=$(cd -- "$(dirname -- "$0")" && pwd)
REPO="$HANDOFF/repo"
: "${WINGBENCH_CHECK_OUT:?Set a fresh absolute output path on the result volume}"
cd "$REPO"
exec /bin/bash "$REPO/rebuttal/container_entry.sh" env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
 python3 "$REPO/rebuttal/adjoint/campaign_v5/preflight.py" --execution-target jisen \
 --release-sha256 0d501cb205d5d9cfd98a2bb863981f1cf1be716b54ddd39ecd51bc69e5c455ca --check-approval "$HANDOFF/check-authorization.json" --out "$WINGBENCH_CHECK_OUT"

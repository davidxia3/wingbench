"""Real IPOPT regression of the recorded near-bound start; analytic oracle only."""
import json
from pathlib import Path
import types
import numpy as np
from rebuttal.adjoint.campaign_v5 import core
from rebuttal.adjoint.campaign_v5.common import write

def run(out, cyipopt):
    from benchmark.common import load_box
    fixtures=Path(__file__).parent/'fixtures'
    initial=json.loads((fixtures/'near-bound-initial.json').read_text())
    x0=np.r_[np.zeros(38),initial['alphas']]
    pushed=np.array(json.loads((fixtures/'near-bound-pushed.json').read_text()))
    reports={};base=core.Bridge
    for mode in ('default_push_control','fixed'):
        callbacks=[];requests=[]
        class Observed(base):
            def jacobian(self,x):
                callbacks.append(x.tolist());return super().jacobian(x)
        class Problem:
            def __init__(self,**kw):self.p=cyipopt.Problem(**kw)
            def add_option(self,*args):return self.p.add_option(*args)
            def solve(self,x):
                if mode=='default_push_control':
                    self.p.add_option('bound_push',.01);self.p.add_option('bound_frac',.01)
                return self.p.solve(x)
            def close(self):self.p.close()
        def oracle(op,x,reservation):
            requests.append(dict(op=op,x=x.tolist()))
            if op=='forward' and np.array_equal(x,pushed):
                return dict(status='scientific_failure',value=None,error='Injected failure at recorded bound-pushed start')
            v=np.empty((3,2));g=np.zeros((3,2,41))
            for m in range(3):
                v[m,0]=initial['target_cl']+.1*(x[38+m]-x0[38+m])+.02*x[0]
                v[m,1]=.03+.002*(x[0]-.5)**2+.001*np.dot(x[1:38],x[1:38])
                g[m,0,0]=.02;g[m,0,38+m]=.1
                g[m,1,0]=.004*(x[0]-.5);g[m,1,1:38]=.002*x[1:38]
            return dict(status='ok',value=(v if op=='forward' else g).tolist())
        try:
            core.Bridge=Observed
            status=core.optimize(Path(out)/mode,initial,load_box(),oracle,{'synthetic':True},8,
                types.SimpleNamespace(Problem=Problem,CyIpoptEvaluationError=cyipopt.CyIpoptEvaluationError))
        finally:core.Bridge=base
        reports[mode]=dict(status=status,jacobian_requests=callbacks,oracle_requests=requests)
    write(Path(out)/'evidence.json',dict(CFD_calls=0,adjoint_solves=0,results=reports),exclusive=True)
    assert reports['default_push_control']['status'].get('optimizer_status')==-13,reports
    fixed=reports['fixed']
    assert fixed['status']['phase'] in ('optimizer_converged','budget_complete'),fixed
    assert fixed['jacobian_requests'] and np.array_equal(fixed['jacobian_requests'][0],x0),fixed
    assert not any(np.array_equal(r['x'],pushed) for r in fixed['oracle_requests']),fixed
    return dict(passed=True,CFD_calls=0,adjoint_solves=0,results=reports)

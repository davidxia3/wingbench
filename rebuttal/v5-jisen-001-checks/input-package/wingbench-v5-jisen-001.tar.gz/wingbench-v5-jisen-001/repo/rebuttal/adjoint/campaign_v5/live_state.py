"""Validated live-state handoff helpers, versioned for v5; no standalone launcher."""
import hashlib
import time
import numpy as np
from rebuttal.adjoint.campaign_v5.numerics import Evaluator, write_json

def sha_array(value):
    value = np.ascontiguousarray(value)
    return hashlib.sha256(value.dtype.str.encode() + str(value.shape).encode() + value.tobytes()).hexdigest()


class RetainSolver:
    """Keep exactly one original solver; observe, never change its CFD calls."""
    def __init__(self, module, record):
        self.module, self.record = module, record
        self.cls = module.ADFLOW
        self.original_call = self.cls.__call__
        self.instances = []
        self.forward_allowed = True

    def __enter__(self):
        owner = self

        def construct(*args, **kwargs):
            if owner.instances:
                raise RuntimeError('Benchmark constructed multiple CFD solvers')
            obj = owner.cls(*args, **kwargs)
            owner.instances.append(obj)
            return obj

        def observed_call(solver, ap, *args, **kwargs):
            if not owner.forward_allowed:
                raise RuntimeError('Forbidden extra forward solve after benchmark trim')
            start = time.monotonic()
            try:
                return owner.original_call(solver, ap, *args, **kwargs)
            finally:
                owner.record(solver, ap, time.monotonic() - start)

        self.module.ADFLOW = construct
        self.cls.__call__ = observed_call
        return self

    def forbid_forward(self):
        self.forward_allowed = False

    def __exit__(self, *exc):
        self.module.ADFLOW = self.cls
        self.cls.__call__ = self.original_call


def snapshot(solver, ap, comm):
    state = np.asarray(solver.getStates()).copy()
    coords = np.asarray(solver.getSurfaceCoordinates(solver.designFamilyGroup, includeZipper=False))
    record = {
        'state_sha256_by_rank': comm.allgather(sha_array(state)),
        'surface_sha256_by_rank': comm.allgather(sha_array(coords)),
        'raw_norms_by_rank': comm.allgather(list(map(float, solver.getResNorms()))),
        'alpha': float(ap.alpha), 'area_ref': float(ap.areaRef),
        'solve_failed': bool(ap.solveFailed), 'fatal_fail': bool(ap.fatalFail),
    }
    return record, state


def attach_live_evaluator(solver, ap, comm, case, initial):
    from benchmark.common import load_box
    from rebuttal.adjoint.geometry import Surface
    from idwarp import USMesh
    from scipy.spatial import cKDTree
    from mpi4py import MPI
    ev = Evaluator()
    ev.comm, ev.out = comm, case
    ev.solver, ev.ap = solver, ap
    ev.surface = Surface(initial['geometry'], load_box().sd)
    ev.base_surface, ev.base_area = ev.surface.evaluate(np.zeros(38))
    if not all(comm.allgather(abs(ev.base_area - float(ap.areaRef)) <= 1e-12)):
        raise ValueError('Geometry reference area differs from benchmark area')
    ev.mesh = USMesh(options={'gridFile': str(case.parent / 'wing_vol.cgns')}, comm=comm)
    solver.setMesh(ev.mesh)
    ev.coords0 = solver.getSurfaceCoordinates(solver.designFamilyGroup, includeZipper=False)
    dist, ev.indices = cKDTree(ev.base_surface).query(ev.coords0)
    ev.mapping_error = comm.allreduce(float(dist.max()) if len(dist) else 0., op=MPI.MAX)
    if not np.isfinite(ev.mapping_error) or ev.mapping_error > 2e-6:
        raise ValueError('Episode initial mesh/surface mapping mismatch')
    ap.addDV('alpha', name='alpha')
    options = {'adjointL2Convergence': 1e-12, 'adjointMaxIter': 1000,
               'restartAdjoint': True, 'frozenTurbulence': False, 'ADPC': True, 'adjointSubspaceSize': 200}
    for key, val in options.items():
        solver.setOption(key, val)
        if solver.getOption(key) != val:
            raise RuntimeError('Adjoint option failed to apply: ' + key)
    ev.calls, ev.adjoint_calls, ev.adjoint_attempts, ev.counter = [], [], [], 0
    ev.last_y = np.r_[np.zeros(38), float(ap.alpha)]
    funcs = {}
    solver.evalFunctions(ap, funcs, evalFuncs=['cl', 'cd'])
    ev.last_values = np.array([funcs[ap.name + '_cl'], funcs[ap.name + '_cd']])
    return ev


"""V4 candidate construction: benchmark forward target; unchanged adjoint settings."""
from pathlib import Path
import hashlib
import numpy as np
from benchmark.common import load_box
from rebuttal.adjoint.geometry import Surface
from rebuttal.adjoint.campaign_v4.numerics import Evaluator as StrictEvaluator, write_json


class CampaignEvaluator(StrictEvaluator):
    def __init__(self,comm,mesh,out,initialization,mach_index):
        from adflow import ADFLOW
        from baseclasses import AeroProblem
        from idwarp import USMesh
        from scipy.spatial import cKDTree
        from mpi4py import MPI
        self.comm,self.out=comm,Path(out)
        self.row={'geometry':list(initialization['geometry'])}
        self.reference={'mach':float(initialization['mach'][mach_index]),
                        'realized_aoa_deg':float(initialization['alphas'][mach_index]),
                        'cl_target':float(initialization['target_cl'])}
        self.surface=Surface(self.row['geometry'],load_box().sd)
        self.base_surface,area=self.surface.evaluate(np.zeros(38))
        self.base_area=area;self.calls=[];self.adjoint_calls=[];self.adjoint_attempts=[];self.counter=0
        self.solver=ADFLOW(options={
            'gridFile':str(mesh),'outputDirectory':str(out),
            'monitorvariables':['resrho','cl','cd','resturb'],
            'writeVolumeSolution':False,'writeSurfaceSolution':False,'writeTecplotSurfaceSolution':False,
            'equationType':'RANS','MGCycle':'3w','useANKSolver':True,'useNKSolver':True,'NKSwitchTol':1e-8,
            'L2Convergence':1e-10,'nCyclesCoarse':500,'nCycles':3000,
            'adjointL2Convergence':1e-12,'adjointMaxIter':1000,
            'restartAdjoint':True,'frozenTurbulence':False,'ADPC':True},comm=comm)
        self.mesh=USMesh(options={'gridFile':str(mesh)},comm=comm);self.solver.setMesh(self.mesh)
        self.coords0=self.solver.getSurfaceCoordinates(self.solver.designFamilyGroup,includeZipper=False)
        dist,self.indices=cKDTree(self.base_surface).query(self.coords0)
        self.mapping_error=comm.allreduce(float(dist.max()) if len(dist) else 0.,op=MPI.MAX)
        if not np.isfinite(self.mapping_error) or self.mapping_error>2e-6:raise ValueError('Episode initial mesh/surface mapping mismatch')
        self.ap=AeroProblem(name='campaign_m{}'.format(mach_index),mach=self.reference['mach'],
            alpha=self.reference['realized_aoa_deg'],reynolds=20e6,reynoldsLength=1.,T=300.,
            areaRef=area,chordRef=1.,xRef=.25,evalFuncs=['cl','cd'])
        self.ap.addDV('alpha',name='alpha');self.last_y=None
        if comm.rank==0:
            frozen=Path(__file__).resolve().parent/'numerics.py'
            write_json(self.out/'setup.json',{
                'episode_id':initialization['episode_id'],'mach_index':mach_index,'reference':self.reference,
                'initialization_source':'Free fresh original-grade initialization; excluded from eight search attempts',
                'geometry':self.row,'surface_area':area,'mapping_max_distance':self.mapping_error,'ranks':comm.size,
                'forward_target':1e-10,'forward_gate':1e-10,'native_target':1e-12,'native_gate':1.1e-9,
                'max_native_attempts_per_function':3,'frozen_turbulence':False,
                'inherited_forward_and_gradient_source_sha256':hashlib.sha256(frozen.read_bytes()).hexdigest(),
                'geometry_chain_step_sd':1e-5,'root_alignment':'unchanged rigid reference-root translation'})

"""Separate original-grader check of a committed nomination; never feeds search."""
import argparse
import json
from pathlib import Path
import sys
import time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v5.common import write,sha,now,HERE,verify_release,require_approval,original_grader

def main(args):
    release=verify_release(HERE/'release.json',args.release_sha256)
    require_approval(args.approval,args.release_sha256)
    from benchmark.common import load_tasks,json_ready,geometry_sha256
    from rebuttal.adjoint.campaign_v1.run_initial_grade import grade_costs,check_constructor_runtime
    from rebuttal.adjoint.campaign_v1.run_initial_grade import preflight_runtime
    preflight_runtime(release['runtime_expected_sha256'])
    from rebuttal.adjoint.campaign_v5.run import validate_initial
    initial=validate_initial(args.initial,args.release_sha256);stage=json.loads(args.stage.read_text())
    binding=json.loads((args.stage.parent/'binding.json').read_text())
    if (binding['initialization_sha256']!=sha(args.initial) or
        binding['pilot_release_sha256']!=args.release_sha256):
        raise ValueError('Nomination belongs to a different initial wing or release')
    if initial['release_sha256']!=args.release_sha256:raise ValueError('Wrong initialization release')
    nomination=stage['nomination'];geometry=nomination['geometry']
    if stage['phase']=='blocked':raise ValueError('Unresolved execution is not a completed pilot')
    args.out.mkdir(parents=True,exist_ok=False)
    write(args.out/'nomination.json',dict(nomination=nomination,stage_sha256=sha(args.stage),
        selected_before_private_grade=True,search_feedback=False),exclusive=True)
    if geometry_sha256(geometry)==initial['geometry_sha256']:
        if sha(args.initial.parent/'initial_grade.json')!=initial['grade_sha256']:raise ValueError('Initial grade changed')
        write(args.out/'result.json',dict(reused_initial_grade=True,new_CFD_calls=0,
            delivered=initial['delivered'],score=initial['initial_score'],improvement=0.,
            source_grade_sha256=initial['grade_sha256'],stage_sha256=sha(args.stage)),exclusive=True)
        return
    grader=original_grader(load_tasks()[initial['task']],args.out/'work',run_id=initial['episode_id']+'-private')
    write(args.out/'constructor_check.json',check_constructor_runtime(grader),exclusive=True)
    write(args.out/'reservation.json',dict(phase='private_grading',started_at=now(),
        geometry_sha256=geometry_sha256(geometry),search_feedback=False),exclusive=True)
    begin=time.monotonic();raw=None
    try:raw=json_ready(grader.grade(geometry,initial['episode_id']+'-private'))
    except Exception as exc:
        write(args.out/'execution_error.json',dict(error=str(exc),automatic_retry=False,
            costs=grade_costs(raw,time.monotonic()-begin,True)),exclusive=True)
        raise
    write(args.out/'grade.json',raw,exclusive=True)
    if raw['geometry']['sha256']!=geometry_sha256(geometry):raise ValueError('Private grade geometry mismatch')
    grade=raw['benchmark_grade'];pred=float(nomination['score']);score=grade['ld'] if grade['delivered'] else None
    relative=abs(float(score)-pred)/abs(float(score)) if score is not None else None
    write(args.out/'result.json',dict(reused_initial_grade=False,new_CFD_calls=1,delivered=grade['delivered'],
        score=score,starting_score=initial['initial_score'],
        improvement=(float(score)/float(initial['initial_score'])-1) if score is not None else None,
        native_prediction=pred,relative_native_disagreement=relative,
        native_original_agreement_passed=(relative is not None and relative<=.005),
        stage_sha256=sha(args.stage),raw_grade_sha256=sha(args.out/'grade.json'),
        costs=grade_costs(raw,time.monotonic()-begin,True),search_feedback=False,finished_at=now()),exclusive=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--initial',type=Path,required=True)
    p.add_argument('--stage',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--release-sha256',required=True);p.add_argument('--approval',type=Path,required=True)
    main(p.parse_args())

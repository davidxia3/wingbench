#!/bin/bash
# Prepared only. Separate explicit user approval must exist before submission.
#SBATCH --account=p33116
#SBATCH --partition=normal
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --mem=288G
#SBATCH --time=2-00:00:00
#SBATCH --no-requeue
#SBATCH --job-name=wb-v4-pilot
set -euo pipefail
RELEASE_REPO=${1:?immutable source checkout}
RELEASE_SHA=${2:?release SHA256}
APPROVAL=${3:?scientific approval inside workspace}
CHECK_APPROVAL=${4:?checks approval inside workspace}
OUT_ROOT=${5:?new episode output root inside workspace}
INDEX=${SLURM_ARRAY_TASK_ID:?explicit index required}
[[ "$INDEX" =~ ^[0-5]$ && "$RELEASE_SHA" =~ ^[0-9a-f]{64}$ ]]
module --ignore_cache load singularityce/4.3.1-gcc-8.5.0
export LD_LIBRARY_PATH="/gpfs/software/2025/spack/opt/spack/linux-rhel8-x86_64/gcc-8.5.0/libfuse-3.16.2-cg5xbdf2pwgqhdwoaujsoqaw2mhvjb3t/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
RUN_ROOT=/scratch/unk4211/wingbench-rebuttal-20261106
container() {
 singularity exec --userns --cleanenv \
  --env "SLURM_JOB_ID=$SLURM_JOB_ID" --env "SLURM_NTASKS=$SLURM_NTASKS" \
  --env "SLURM_ARRAY_TASK_ID=$INDEX" --env "SLURM_JOB_NODELIST=$SLURM_JOB_NODELIST" \
  --bind "$RUN_ROOT:/workspace" --bind "$RELEASE_REPO:/workspace/repo:ro" \
  "$RUN_ROOT/runtime/mdolab-recovered-20261107T072200Z" \
  bash --noprofile --norc /workspace/repo/rebuttal/container_entry.sh \
  env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 "$@"
}
container python3 -c 'import sys; from rebuttal.adjoint.campaign_v4.common import require_approval; require_approval(sys.argv[1],sys.argv[2],int(sys.argv[3]))' "$APPROVAL" "$RELEASE_SHA" "$INDEX"
CHECK_OUT="$OUT_ROOT/index-$INDEX/checks-$SLURM_JOB_ID"
container python3 /workspace/repo/rebuttal/adjoint/campaign_v4/preflight.py \
 --out "$CHECK_OUT" --release-sha256 "$RELEASE_SHA" --check-approval "$CHECK_APPROVAL"
container python3 /workspace/repo/rebuttal/adjoint/campaign_v4/pipeline.py \
 --index "$INDEX" --out "$OUT_ROOT/index-$INDEX/episode" --release-sha256 "$RELEASE_SHA" \
 --approval "$APPROVAL" --runtime-check "$CHECK_OUT/certificate.json"

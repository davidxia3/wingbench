"""No-CFD regression tests of real campaign accounting and callback paths.

A scripted optimizer drives edge cases here. optimizer_smoke.py separately tests
actual pinned IPOPT before any numerical qualification or search is authorized.
"""
import json
from pathlib import Path
import tempfile
import types
import unittest
import numpy as np
from rebuttal.adjoint.campaign_v5.core import (optimize,Transcript,InfrastructureFailure,
    ReplayMismatch,BudgetReached,ForwardFailure,aggregate)
from rebuttal.adjoint.campaign_v5.common import write,require_approval,require_runtime_check
from rebuttal.adjoint.campaign_v5.numerics import forward_valid,native_valid

class Box:
    sd=np.ones(38)
    def to_standardized(self,x):return np.asarray(x)

def initial():return dict(geometry=[0.]*38,alphas=[0.]*3,target_cl=.41,initial_score=20.5,
    reference_cl_cd=[[.41,.02]]*3)

class Oracle:
    def __init__(self,mode='ok'):self.mode=mode;self.calls=[]
    def __call__(self,op,x,reservation):
        self.calls.append((op,x.copy(),reservation.copy()))
        if (self.mode=='initial_failure' and op=='forward' and np.all(x==0) or
            self.mode=='trial_failure' and op=='forward' and x[0]>0 or
            self.mode=='adjoint_failure' and op=='gradient'):
            return dict(status='scientific_failure',error='injected scientific failure',value=None)
        if self.mode=='execution_error' and x[0]>0:raise RuntimeError('injected MPI disappearance')
        v=np.array([[.41,.02]]*3);g=np.zeros((3,2,41))
        return dict(status='ok',value=(v if op=='forward' else g).tolist())

class EvaluationError(Exception):pass

def optimizer(mode='trials'):
    class Problem:
        def __init__(self,**kw):
            if mode=='constructor_failure':raise RuntimeError('injected optimizer constructor failure')
            self.b=kw['problem_obj']
        def add_option(self,*args):pass
        def close(self):pass
        def solve(self,x):
            if mode=='negative_exit':return x,dict(status=-2,status_msg=b'infeasible test')
            if mode=='gradient':
                try:self.b.gradient(x)
                except EvaluationError:pass
            else:
                for i in range(1,12):
                    y=x.copy();y[0]=i*.01
                    try:self.b.objective(y)
                    except EvaluationError:
                        if self.b.stopped:break
            return x,dict(status=5,status_msg=b'scripted stop')
    return types.SimpleNamespace(Problem=Problem,CyIpoptEvaluationError=EvaluationError)

class CoreTests(unittest.TestCase):
    def run_case(self,mode='ok',opt='trials'):
        with tempfile.TemporaryDirectory() as d:
            oracle=Oracle(mode)
            status=optimize(Path(d),initial(),Box(),oracle,{'test':True},8,optimizer(opt))
            disk=json.loads((Path(d)/'stage-08.json').read_text())
            self.assertEqual(status,disk)
            return status,oracle
    def test_initial_free_exact_and_eight_new(self):
        s,o=self.run_case();self.assertEqual(s['search_attempts'],8)
        self.assertEqual(s['phase'],'budget_complete');self.assertEqual(len(o.calls),9)
        self.assertTrue(o.calls[0][2]['free_initial'])
        self.assertTrue(np.all(o.calls[0][1]==0))
    def test_failed_trials_charged_and_next_trials_possible(self):
        s,o=self.run_case('trial_failure');self.assertEqual(s['search_attempts'],8)
        self.assertEqual(len(o.calls),9);self.assertTrue(s['starting_wing_returned'])
    def test_failed_exact_start_prevents_optimizer_trials(self):
        s,o=self.run_case('initial_failure');self.assertEqual(s['search_attempts'],0)
        self.assertEqual(s['phase'],'stopped');self.assertEqual(len(o.calls),1)
    def test_failed_adjoint_is_terminal(self):
        s,o=self.run_case('adjoint_failure','gradient')
        self.assertEqual(s['phase'],'adjoint_failure');self.assertEqual(s['search_attempts'],0)
        self.assertEqual([c[0] for c in o.calls],['forward','gradient'])
    def test_unexpected_execution_preserves_reservation(self):
        s,o=self.run_case('execution_error');self.assertEqual(s['phase'],'blocked')
        self.assertEqual(s['search_attempts'],0);self.assertEqual(s['search_attempts_reserved'],1)
        self.assertIsNotNone(s['pending_reservation']);self.assertEqual(len(o.calls),2)
    def test_constructor_failure_writes_final_status(self):
        s,o=self.run_case(opt='constructor_failure');self.assertEqual(s['phase'],'blocked')
        self.assertEqual(len(o.calls),1)
    def test_negative_ipopt_status_is_not_converged(self):
        s,_=self.run_case(opt='negative_exit');self.assertEqual(s['phase'],'optimizer_terminated')
        self.assertEqual(s['optimizer_status'],-2)
    def test_pending_cannot_be_retried(self):
        with tempfile.TemporaryDirectory() as d:
            write(Path(d)/'pending.json',dict(sequence=0,request={'op':'forward'},search_attempt=1))
            with self.assertRaises(InfrastructureFailure):Transcript(d,np.zeros(41),8,Oracle(),{})
    def test_replay_mismatch_stops_before_new_work(self):
        with tempfile.TemporaryDirectory() as d:
            t=Transcript(d,np.zeros(41),8,Oracle(),{});t.call('forward',np.zeros(41))
            o=Oracle();replay=Transcript(d,np.zeros(41),8,o,{})
            with self.assertRaises(ReplayMismatch):replay.call('forward',np.ones(41))
            self.assertEqual(o.calls,[])
    def test_no_other_budget_accepted(self):
        for cap in (0,4,9,32):
            with tempfile.TemporaryDirectory() as d:
                with self.assertRaises(ValueError):Transcript(d,np.zeros(41),cap,Oracle(),{})
    def test_callback_cache_does_not_duplicate_expensive_calls(self):
        from rebuttal.adjoint.campaign_v5.core import Bridge
        import signal
        with tempfile.TemporaryDirectory() as d:
            o=Oracle();t=Transcript(d,np.zeros(41),8,o,{})
            b=Bridge(t,initial(),Box.sd,EvaluationError)
            try:
                b.objective(np.zeros(41));b.constraints(np.zeros(41))
                b.gradient(np.zeros(41));b.jacobian(np.zeros(41))
                self.assertEqual([c[0] for c in o.calls],['forward','gradient'])
            finally:signal.setitimer(signal.ITIMER_REAL,0)

class GateTests(unittest.TestCase):
    def test_restored_forward_gate(self):
        self.assertTrue(forward_valid([1.,1.,1e-10],[.4,.02],False))
        self.assertFalse(forward_valid([1.,1.,1.001e-10],[.4,.02],False))
        for norms,values,failed in [([0,0,0],[.4,.02],False),([1,1,1e-12],[.4,.02],True),
            ([1,1,float('nan')],[.4,.02],False),([1,1,1e-12],[float('nan'),.02],False)]:
            self.assertFalse(forward_valid(norms,values,failed))
    def test_adjoint_failure_flag_overrides_residual(self):
        self.assertTrue(native_valid([1,1,1.1e-9],False))
        self.assertFalse(native_valid([1,1,1e-13],True))
        self.assertFalse(native_valid([1,1,1.2e-9],False))
    def test_draft_does_not_authorize(self):
        with self.assertRaises(ValueError):require_approval(Path(__file__).with_name('authorization.json'),'x')
    def test_approval_binds_release_and_cap(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'approval.json';a=dict(launch_authorized=True,release_sha256='x',pilot_indices=list(range(6)),
                search_attempt_limit=8,user_approval_reference='test-only')
            write(p,a);self.assertEqual(require_approval(p,'x',5),a)
            with self.assertRaises(ValueError):require_approval(p,'y')
            with self.assertRaises(ValueError):require_approval(p,'x',6)
    def test_historical_qualification_not_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'cert.json';write(p,dict(passed=True,forward_gate=1.1e-12))
            with self.assertRaises(ValueError):require_runtime_check(p,'x',{})

if __name__=='__main__':unittest.main(verbosity=2)

class RuntimeApprovalTests(unittest.TestCase):
    def test_checks_permission_does_not_authorize_science(self):
        from rebuttal.adjoint.campaign_v5.common import require_check_approval
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a.json';write(p,dict(checks_authorized=True,release_sha256='x',
                scope='software_runtime_only',user_approval_reference='test',launch_authorized=False))
            require_check_approval(p,'x')
            with self.assertRaises(ValueError):require_approval(p,'x')
    def test_runtime_certificate_requires_hash_and_zero_science(self):
        from rebuttal.adjoint.campaign_v5.common import sha
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);write(p/'evidence.json',{'passed':True})
            c=dict(schema='wingbench-v5-software-runtime-check',passed=True,release_sha256='x',
                runtime={},scientific_calls=0,optimizer_smoke_passed=True,mpi16_import_smoke_passed=True,
                evidence_file='evidence.json',evidence_sha256=sha(p/'evidence.json'))
            write(p/'cert.json',c);require_runtime_check(p/'cert.json','x',{})
            with self.assertRaises(ValueError):require_runtime_check(p/'cert.json','different',{})
            c['scientific_calls']=1;write(p/'cert.json',c)
            with self.assertRaises(ValueError):require_runtime_check(p/'cert.json','x',{})
            c['scientific_calls']=0;write(p/'cert.json',c);write(p/'evidence.json',{'changed':True})
            with self.assertRaises(ValueError):require_runtime_check(p/'cert.json','x',{})

"""Zero-CFD integration regressions; fake native solver, real worker/protocol paths."""
import copy
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import scripts.cfd.grading_protocol
import scripts.cfd.grade_schema
from rebuttal.adjoint.campaign_v5 import worker,live_initial,core
from rebuttal.adjoint.campaign_v5.common import sha,write
from rebuttal.adjoint.campaign_v5.trim_artifacts import checked_path
from rebuttal.adjoint.campaign_v5.test_worker import Comm
from rebuttal.adjoint.campaign_v5.test_core import initial,Box,Oracle,EvaluationError


class IntegrationTests(unittest.TestCase):
    def test_ipopt_receives_start_preserving_options(self):
        seen={}
        class Problem:
            def __init__(self,**kw):pass
            def add_option(self,k,v):seen[k]=v
            def solve(self,x):return x,dict(status=0,status_msg=b'analytic stub')
            def close(self):pass
        with tempfile.TemporaryDirectory() as d:
            core.optimize(Path(d),initial(),Box(),Oracle(),{},8,
                types.SimpleNamespace(Problem=Problem,CyIpoptEvaluationError=EvaluationError))
        self.assertEqual(seen['bound_push'],1e-10)
        self.assertEqual(seen['bound_frac'],1e-10)
        self.assertEqual(seen['bound_relax_factor'],0.)

    def test_live_worker_does_not_repeat_forward_before_gradient(self):
        events=[]
        class Fake:
            def __init__(self,leaf):
                self.calls=[dict(relative_residual=1e-11,solve_failed=False,qualified=True)]*5
                self.adjoint_attempts=[];self.last_values=np.array([.41,.02])
                self.solver=types.SimpleNamespace(adflow=object())
                write(leaf/'setup.json',{'live':True})
            def forward(self,*a):raise AssertionError('Extra proposal-zero CFD forbidden')
            def gradient(self,y,values):
                events.append(('gradient',values.tolist()))
                return np.ones((2,39))
        def retain(path,data,mach,leaf,x,comm):
            events.append(('trim',mach));return Fake(leaf)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);write(p/'initial.json',dict(mesh=dict(relative_path='mesh')))
            for n,op in enumerate(['forward','gradient','stop']):
                command=dict(op=op,mach=0,x=[0.]*41,proposal_zero=True)
                if op=='gradient':command['values']=[.41,.02]
                write(p/f'requests/{n:05}.json',command)
            with patch.dict('sys.modules',{'mpi4py':types.SimpleNamespace(MPI=types.SimpleNamespace(COMM_WORLD=Comm()))}), \
                 patch.object(live_initial,'retain',side_effect=retain):
                worker.main(types.SimpleNamespace(initial=p/'initial.json',work=p))
            first=json.loads((p/'responses/00000.json').read_text())
            second=json.loads((p/'responses/00001.json').read_text())
            self.assertEqual(first['status'],'ok');self.assertEqual(second['status'],'ok')
            self.assertEqual(len(first['cost']['forward_records']),5)
            self.assertEqual(second['cost']['forward_records'],[])
            self.assertEqual(events,[('trim',0),('gradient',[.41,.02])])

    def replay(self,mutation=None,failed=False):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);initroot=root/'initial';initroot.mkdir();leaf=root/'worker/mach_0';leaf.mkdir(parents=True)
            def pin(name,text):
                f=initroot/name;f.write_text(text);return dict(relative_path=name,sha256=sha(f))
            mesh=pin('mesh','mesh');inp=pin('input','{}');script=pin('script','benchmark')
            rows=[]
            for m in range(3):
                cond=pin(f'conds{m}',json.dumps(dict(M3=.8+m*.01,AA=6.64,CL_targ=.41)))
                rows.append(dict(mach=.8+m*.01,conditions=cond,solver_script=script,reference_cl_cd=[.41,.02]))
            data=dict(mesh=mesh,benchmark_trim=dict(input=inp,conditions=rows),mach=[.8,.81,.82],
                target_cl=.41,alphas=[4.]*3,original_protocol_sha256='protocol')
            # Use the exact serialized Mach values in this fixture.
            data['mach']=[r['mach'] for r in rows]
            write(initroot/'initial.json',data);calls=[]
            class Solver:
                def __init__(self):
                    self.curAP=types.SimpleNamespace(alpha=4.,solveFailed=failed,fatalFail=False)
                    self.state='live'
                def __call__(self,ap):calls.append(ap.alpha)
                def getResNorms(self):return [1.,1.,1e-11]
            module=types.SimpleNamespace(ADFLOW=Solver)
            def run_script(*a,**kw):
                s=module.ADFLOW()
                for j in range(5):s(s.curAP)
                write(leaf/'output.json',dict(results=dict(wing_cl=.41,wing_cd=.02)))
            def attach(s,ap,comm,out,ini):
                if mutation=='state':s.state='changed'
                y=np.r_[np.zeros(38),4.+(1e-8 if mutation=='angle' else 0.)]
                return types.SimpleNamespace(last_y=y,last_values=np.array([.41,.02]),calls=[])
            cwd=Path.cwd()
            with patch.dict('sys.modules',{'adflow':module}), \
                 patch('scripts.cfd.grading_protocol.load_protocol',return_value=types.SimpleNamespace(sha256='protocol',seed_alpha0=6.64)), \
                 patch('scripts.cfd.grade_schema.classify_condition_attempt',return_value={'outcome_class':'valid'}), \
                 patch.object(live_initial.runpy,'run_path',side_effect=run_script), \
                 patch.object(live_initial,'attach_live_evaluator',side_effect=attach), \
                 patch.object(live_initial,'snapshot',side_effect=lambda s,a,c:({'state':s.state},None)):
                if failed or mutation:
                    with self.assertRaises(RuntimeError):live_initial.retain(initroot/'initial.json',data,0,leaf,np.r_[np.zeros(38),[4.]*3],Comm())
                    result=None
                else:result=live_initial.retain(initroot/'initial.json',data,0,leaf,np.r_[np.zeros(38),[4.]*3],Comm())
            self.assertEqual(Path.cwd(),cwd)
            self.assertEqual(len(calls),5)
            self.assertEqual(len(json.loads((leaf/'trim_forward_calls.json').read_text())),5)
            if result is not None:self.assertEqual(len(result.calls),5)
    def test_benchmark_trim_handoff_uses_exact_state_and_records_all_calls(self):self.replay()
    def test_changed_live_state_rejected(self):self.replay('state')
    def test_changed_actual_angle_rejected_without_extra_cfd(self):self.replay('angle')
    def test_failed_benchmark_cfd_not_used_for_gradient(self):self.replay(failed=True)

    def test_artifact_hash_and_escape_checks(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'input').write_text('original');r=dict(relative_path='input',sha256=sha(p/'input'))
            self.assertEqual(checked_path(p,r),(p/'input').resolve())
            (p/'input').write_text('changed')
            with self.assertRaises(ValueError):checked_path(p,r)
            r['relative_path']='../input'
            with self.assertRaises(ValueError):checked_path(p,r)

    def test_proposal_zero_cannot_be_used_for_another_wing(self):
        x=np.r_[np.zeros(38),[4.]*3];live_initial.require_proposal_zero({'alphas':[4.]*3},x)
        x[0]=1e-9
        with self.assertRaises(ValueError):live_initial.require_proposal_zero({'alphas':[4.]*3},x)

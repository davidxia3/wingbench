"""Counted attempt1 only: original grader, immutable reservation, no optimizer.

An existing episode directory/reservation is never retried. The entire episode
directory may move only when quiescent; absolute paths in the untouched raw
grader result are historical provenance, while initialization uses relative
artifact paths for later verified reconstruction.
"""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
import resource
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
NUMERICAL_PROTOCOL = ROOT/'rebuttal/compute/jisen_verify_v1/numerical_protocol.json'
JISEN_PACKAGE = ROOT/'rebuttal/compute/jisen_verify_v1/package_manifest.json'
JISEN_PREFLIGHT = ROOT/'rebuttal/compute/jisen_verify_v1/preflight.py'
FLAGS = {'phase_scope':'initial_grade_only', 'can_release_optimization':False,
         'optimization_started':False, 'native_adjoint_solves':0}


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()


def write_new(path, value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    # Exclusive create plus fsync makes the reservation durable before grading.
    # Any partial file left by a crash still blocks a scientific retry.
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
        stream.flush();os.fsync(stream.fileno())
    descriptor=os.open(str(path.parent),os.O_RDONLY)
    try:os.fsync(descriptor)
    finally:os.close(descriptor)


def safe_source(relative):
    path=Path(relative)
    if path.is_absolute() or '..' in path.parts:raise ValueError('Source path must be repo-relative')
    target=(ROOT/path).resolve()
    if ROOT.resolve() not in target.parents:raise ValueError('Source escapes release checkout')
    return target


def validate_inputs(args):
    if sha(args.manifest)!=args.manifest_sha256:raise ValueError('Initialization manifest hash differs')
    release_path=HERE/'initial_phase_release.json'
    if sha(release_path)!=args.release_sha256:raise ValueError('Initial-phase release hash differs')
    release=json.loads(release_path.read_text());manifest=json.loads(args.manifest.read_text())
    if (release.get('schema')!='wingbench-adjoint-initial-phase-release-v1' or
            release.get('phase')!='initial_grade_only' or release.get('can_release_optimization') is not False):
        raise ValueError('Release does not authorize only initial grading')
    binding=release['initialization_manifest']
    if (binding['sha256']!=args.manifest_sha256 or
            safe_source(binding['path'])!=args.manifest.resolve()):
        raise ValueError('Release/initialization manifest binding differs')
    sources=release.get('source_sha256',{})
    if str(Path(__file__).resolve().relative_to(ROOT)) not in sources:
        raise ValueError('Release does not pin this initial-grade driver')
    for relative,expected in sources.items():
        if sha(safe_source(relative))!=expected:raise ValueError('Frozen release source differs: '+relative)
    for dependency in (JISEN_PACKAGE,JISEN_PREFLIGHT):
        if str(dependency.relative_to(ROOT)) not in sources:
            raise ValueError('Release must pin runtime provenance dependency: '+str(dependency))
    for relative,expected in manifest['source_sha256'].items():
        if sha(safe_source(relative))!=expected:raise ValueError('Initialization source differs: '+relative)
    protocol_hash=sha(NUMERICAL_PROTOCOL)
    if (release.get('frozen_numerical_protocol_sha256')!=protocol_hash or
            manifest.get('numerical_protocol_sha256')!=protocol_hash):
        raise ValueError('Frozen numerical protocol binding differs')
    if manifest.get('schema')!='wingbench-adjoint-campaign-initialization-v1':
        raise ValueError('Unknown initialization schema')
    episodes=manifest['episodes']
    if len(episodes)!=30 or [e['episode_index'] for e in episodes]!=list(range(30)):
        raise ValueError('Exactly the predeclared30 episodes are required')
    if args.episode_id is not None:
        selected=[e for e in episodes if e['episode_id']==args.episode_id]
        if len(selected)!=1:raise ValueError('Episode ID is absent or duplicated')
        episode=selected[0]
    else:episode=episodes[args.episode_index]
    from benchmark.common import geometry_sha256, load_tasks, load_box
    task=load_tasks()[episode['task']]
    if (episode['task_id']!=task.task_id or episode['target_cl']!=task.target_cl or
            episode['aoa_seed_deg']!=task.aoa_seed_deg or episode['mach']!=list(task.mach) or
            geometry_sha256(episode['geometry'])!=episode['geometry_sha256'] or
            episode.get('checkpoint_0_nomination_geometry_sha256')!=episode['geometry_sha256'] or
            not load_box().contains(episode['geometry']) or
            episode.get('initial_grade_attempt')!=1 or episode.get('max_attempts')!=32):
        raise ValueError('Episode task, geometry or counted-attempt contract differs')
    if episode['episode_id']!='adjoint-v1-s{:02d}-{}'.format(episode['seed'],episode['task']):
        raise ValueError('Episode identity differs from seed/task')
    frozen_runtime=json.loads(JISEN_PACKAGE.read_text())['runtime_expected_sha256']
    coverage_runtime=json.loads((ROOT/'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json').read_text())['expected_runtime_sha256']
    if any(frozen_runtime.get(k)!=v for k,v in coverage_runtime.items()):
        raise ValueError('Jisen and frozen coverage runtime hashes disagree')
    if release.get('runtime_expected_sha256')!=frozen_runtime:
        raise ValueError('Release changed the pinned scientific runtime')
    return episode, task, release, protocol_hash


def runtime_record():
    """Runs in a separate child, before the grader parent initializes MPI."""
    spec=importlib.util.spec_from_file_location('frozen_jisen_preflight',str(JISEN_PREFLIGHT))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    runtime=module.runtime_record()
    if runtime['cst_commit']!='9500b19a732463c26b32f6860ac6c517c7d212a5':
        raise RuntimeError('Pinned CST commit differs')
    runtime['hardware']=module.hardware_record()
    return runtime


def preflight_runtime(expected):
    result=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--runtime-probe-only'],
                           capture_output=True,text=True,timeout=180)
    records=[line[len('CAMPAIGN_RUNTIME='):] for line in result.stdout.splitlines()
             if line.startswith('CAMPAIGN_RUNTIME=')]
    if result.returncode or len(records)!=1:
        raise RuntimeError('Pinned runtime probe failed: '+result.stderr[-2000:]+result.stdout[-2000:])
    runtime=json.loads(records[0])
    if any(runtime['sha256'].get(k)!=v for k,v in expected.items()):
        raise RuntimeError('Pinned scientific runtime hashes differ')
    return runtime, {'stdout':result.stdout,'stderr':result.stderr,'return_code':result.returncode}


def artifact(path, episode_dir):
    path=Path(path).resolve();root=episode_dir.resolve()
    if root not in path.parents or not path.is_file():
        raise ValueError('Required migration artifact is missing or escapes episode directory')
    return {'relative_path':str(path.relative_to(root)),'sha256':sha(path),'size_bytes':path.stat().st_size}


def check_constructor_runtime(grader):
    """Use the constructor's existing probe; do not run a second MPI smoke."""
    execution=grader.protocol.payload['execution']
    if execution['mpi_ranks']!=16 or execution['infrastructure_retries']!=0:
        raise RuntimeError('Exactly16 ranks and zero original-grader retries required')
    status=grader.runtime_status
    if status.get('probed') is not True or not status.get('report_file'):
        raise RuntimeError('Original-grader constructor runtime probe did not complete')
    fingerprint_path=Path(status['report_file'])
    fingerprint=json.loads(fingerprint_path.read_text())
    smoke=fingerprint.get('mpi_smoke_test',{})
    filtered=fingerprint.get('filtered_scientific_import_smoke',{})
    expected=grader.protocol.payload['environment']['required_child_environment']
    effective=fingerprint.get('effective_probe_environment',{})
    if (fingerprint.get('status')!='complete' or smoke.get('passed') is not True or
            smoke.get('requested_ranks')!=16 or filtered.get('passed') is not True or
            filtered.get('returncode')!=0 or filtered.get('effective_environment')!=effective or
            smoke.get('required_child_environment')!=expected or
            smoke.get('probe_process_load_bearing_environment')!=expected or
            any(effective.get(k)!=v for k,v in expected.items())):
        raise RuntimeError('Original exact-environment MPI16/import smoke failed')
    return {'original_grader_runtime_status':status,
            'runtime_fingerprint_sha256':sha(fingerprint_path),
            'original_protocol_sha256':grader.protocol.sha256}


def grade_costs(raw, wall, grade_call_started):
    record=raw if isinstance(raw,dict) else {}
    conditions=record.get('conditions',[])
    meshes=record.get('mesh',{}).get('attempts',[])
    timing=record.get('timing',{})
    children=resource.getrusage(resource.RUSAGE_CHILDREN)
    return {'joint_attempts_reserved':1,
            'original_grader_calls_started':int(grade_call_started),
            'original_grader_results_returned':int(raw is not None),
            'mesh_process_attempts':len(meshes),
            'mach_condition_process_attempts':sum(len(c.get('attempts',[])) for c in conditions),
            'trim_iterations_by_mach':[{'mach':c.get('mach'),
                'iterations':[a.get('measurements',{}).get('solvecl_iterations') for a in c.get('attempts',[])]}
                for c in conditions],
            'CL_adjoints':0,'CD_adjoints':0,'native_refinement_attempts':0,'llm_calls':0,'surrogate_calls':0,
            'wall_seconds':wall,'reported_grader_timing':timing,
            'reported_grade_core_hours':float(timing['core_seconds'])/3600 if timing.get('core_seconds') is not None else None,
            'allocated_core_hours_estimate':16*wall/3600,
            'child_user_cpu_seconds':children.ru_utime,'child_system_cpu_seconds':children.ru_stime,
            'max_single_child_rss_platform_units':children.ru_maxrss,
            'memory_note':'ru_maxrss is not aggregate MPI peak memory; scheduler/cgroup evidence is required.',
            'failure_cost_note':'When no final grade exists, partial process counts remain unknown; all work/logs are retained.'}


def execute_episode(episode, task, out_root, bindings, runtime, probe_log, grader_factory=None):
    """One owner and one attempt; dependency injection is for local fake tests."""
    episode_dir=Path(out_root)/'episodes'/episode['episode_id']
    episode_dir.mkdir(parents=True,exist_ok=False)
    nomination={'episode_id':episode['episode_id'],'checkpoint':0,'geometry':episode['geometry'],
                'geometry_sha256':episode['geometry_sha256'],'source':'predeclared_initial_context_geometry',
                'manifest_sha256':bindings['manifest_sha256'],'created_at':now()}
    write_new(episode_dir/'initial_nomination.json',nomination)
    write_new(episode_dir/'nominations.json',{'episode_id':episode['episode_id'],
        'optimizer_reads_private_grades':False,'joint_attempts_consumed':0,
        'phase':'initial_grade_reserved','nominations':{'0':nomination}})
    reservation=dict(FLAGS, schema='wingbench-counted-initial-reservation-v1', episode_id=episode['episode_id'],
        episode_index=episode['episode_index'],seed=episode['seed'],task=episode['task'],
        geometry_sha256=episode['geometry_sha256'],geometry=episode['geometry'],
        joint_attempt=1,kind='initial_original_grade',started_at=now(),host=socket.gethostname(),
        pid=os.getpid(),slurm_job_id=os.environ.get('SLURM_JOB_ID'),
        slurm_array_task_id=os.environ.get('SLURM_ARRAY_TASK_ID'),
        slurm_job_nodelist=os.environ.get('SLURM_JOB_NODELIST'),
        initial_nomination_sha256=sha(episode_dir/'initial_nomination.json'),**bindings)
    write_new(episode_dir/'initial_reservation.json',reservation)
    # The durable reservation precedes constructor/runtime-smoke/grade calls.
    write_new(episode_dir/'initial_runtime.json',runtime)
    write_new(episode_dir/'initial_runtime_probe_log.json',probe_log)
    started=time.monotonic();raw=None;failure=None;initial=None;grade_call_started=False
    if grader_factory is None:
        from benchmark.grade_local import LocalGrader
        grader_factory=LocalGrader
    try:
        grader=grader_factory(task,episode_dir/'work',run_id=episode['episode_id'])
        constructor_runtime=check_constructor_runtime(grader)
        write_new(episode_dir/'initial_constructor_runtime.json',constructor_runtime)
        grade_call_started=True
        raw=grader.grade(episode['geometry'],episode['episode_id'])
        from benchmark.common import json_ready
        raw=json_ready(raw)
        write_new(episode_dir/'initial_grade.json',raw)
        if (raw['geometry']['sha256']!=episode['geometry_sha256'] or
                raw['geometry']['geom_38d']!=episode['geometry']):
            raise RuntimeError('Original grader returned a different geometry binding')
        if (raw['protocol']['canonical_sha256']!=grader.protocol.sha256 or
                raw['protocol']['snapshot']!=grader.protocol.snapshot()):
            raise RuntimeError('Original grader returned a different task protocol')
        grade=raw['benchmark_grade'];delivered=grade['delivered']
        if type(delivered) is not bool:raise ValueError('Malformed original delivery flag')
        initial=dict(FLAGS, schema='wingbench-adjoint-counted-initialization-v1',
            episode_id=episode['episode_id'],episode_index=episode['episode_index'],seed=episode['seed'],
            task=episode['task'],task_id=episode['task_id'],geometry=episode['geometry'],
            geometry_sha256=episode['geometry_sha256'],target_cl=episode['target_cl'],mach=episode['mach'],
            joint_attempts_consumed=1,remaining_joint_trial_attempts=31,
            grade_available=True,grade_sha256=sha(episode_dir/'initial_grade.json'),
            initial_reservation_sha256=sha(episode_dir/'initial_reservation.json'),
            delivered=delivered,initialization_complete=False,alphas=[],mesh=None,initial_score=None,
            original_grade_outcome=grade.get('outcome'),original_grade_reason_codes=grade.get('reason_codes'),
            original_grader_protocol_sha256=raw['protocol']['canonical_sha256'],**bindings)
        if delivered:
            score=float(grade['ld'])
            if not math.isfinite(score) or score<=0:raise ValueError('Invalid delivered original score')
            initial['initial_score']=score
            conditions=sorted(raw['conditions'],key=lambda c:float(c['mach']))
            if grade.get('outcome')!='pass' or [float(c['mach']) for c in conditions]!=episode['mach']:
                raise ValueError('Original grader Mach conditions differ')
            lds=[]
            for condition in conditions:
                if condition['outcome_class']!='valid' or float(condition['cl_target'])!=episode['target_cl']:
                    raise ValueError('Delivered condition outcome or target differs')
                cl,cd,ld,err=[float(condition['measurements'][key]) for key in ('cl','cd','ld','err_cl')]
                if (not all(math.isfinite(v) for v in (cl,cd,ld,err)) or min(cl,cd,ld)<=0 or ld>40 or
                        not math.isclose(ld,cl/cd,rel_tol=1e-12,abs_tol=1e-12) or
                        abs(cl-episode['target_cl'])>.02 or not 0<=err<.0005):
                    raise ValueError('Delivered condition measurements fail original eligibility')
                lds.append(ld)
            if not math.isclose(score,math.exp(sum(math.log(v) for v in lds)/3),rel_tol=1e-12,abs_tol=1e-12):
                raise ValueError('Delivered aggregate score differs from original condition scores')
            alphas=[float(c['measurements']['realized_aoa_deg']) for c in conditions]
            if not all(math.isfinite(a) and -10<=a<=25 for a in alphas):
                raise ValueError('Invalid trimmed alpha for later initialization')
            grid=raw['mesh']['volume_grid_artifact']
            mesh=artifact(grid['path'],episode_dir)
            if grid.get('sha256')!=mesh['sha256']:raise ValueError('Returned mesh hash differs from disk')
            initial.update(alphas=alphas,mesh=mesh,initialization_complete=True,
                           phase='initialized_awaiting_qualification')
        else:initial.update(initialization_complete=True,phase='terminated_initial_grade_failure')
    except Exception as exc:
        failure={'error_type':type(exc).__name__,'error':str(exc),'recorded_at':now(),
                 'grade_available':raw is not None,'all_partial_work_preserved':True,
                 'scientific_retry_allowed':False}
        write_new(episode_dir/'initial_grade_exception.json',failure)
        if initial is None:
            initial=dict(FLAGS,schema='wingbench-adjoint-counted-initialization-v1',
                episode_id=episode['episode_id'],episode_index=episode['episode_index'],seed=episode['seed'],
                task=episode['task'],task_id=episode['task_id'],geometry=episode['geometry'],
                geometry_sha256=episode['geometry_sha256'],target_cl=episode['target_cl'],mach=episode['mach'],
                joint_attempts_reserved=1,joint_attempts_consumed=None,remaining_joint_trial_attempts=None,
                grade_available=(episode_dir/'initial_grade.json').is_file(),
                grade_sha256=sha(episode_dir/'initial_grade.json') if (episode_dir/'initial_grade.json').is_file() else None,
                initial_reservation_sha256=sha(episode_dir/'initial_reservation.json'),
                delivered=False,initialization_complete=False,alphas=[],mesh=None,initial_score=None,**bindings)
        initial.update(phase='blocked_initial_execution_error',initialization_complete=False,
            grade_exception_sha256=sha(episode_dir/'initial_grade_exception.json'),error=failure)
    initial['finished_at']=now()
    initial['costs']=grade_costs(raw,time.monotonic()-started,grade_call_started)
    initial['costs']['joint_attempts_completed']=initial['joint_attempts_consumed']
    initial['outcome_note']='The original outcome is preserved; a timeout or undetermined grade is not evidence of physical invalidity.'
    initial['migration_policy']='Only a quiescent completed initial phase or a wholly unstarted episode may migrate. Preserve this directory and verify all relative artifact hashes; no in-progress SLSQP restart is implemented.'
    write_new(episode_dir/'initialization.json',initial)
    print(json.dumps({k:initial[k] for k in ['episode_id','phase','delivered','initialization_complete',
                                           'joint_attempts_consumed','can_release_optimization']},indent=2),flush=True)
    return 0 if initial['delivered'] and initial['initialization_complete'] else 2


def constructor_preflight(episode,task,out_root,bindings,runtime,probe_log,grader_factory=None):
    """Non-CFD check: never creates an episode or reserves a scientific attempt."""
    directory=Path(out_root)/('preflight_'+episode['episode_id'])
    directory.mkdir(parents=True,exist_ok=False)
    write_new(directory/'runtime.json',runtime)
    write_new(directory/'runtime_probe_log.json',probe_log)
    if grader_factory is None:
        from benchmark.grade_local import LocalGrader
        grader_factory=LocalGrader
    started=time.monotonic()
    report=dict(FLAGS,preflight_only=True,episode_reservations_created=0,
                original_grader_calls_started=0,passed=False,**bindings)
    try:
        grader=grader_factory(task,directory/'work',run_id='campaign_preflight')
        report.update(check_constructor_runtime(grader))
        report.update(passed=True,
            historical_fingerprint_note='Original LocalGrader records historical fingerprint matching separately; this preflight requires the frozen nine-file runtime pins and successful exact-environment MPI16/import smoke.')
    except Exception as exc:
        report['error']={'type':type(exc).__name__,'message':str(exc)}
    report.update(wall_seconds=time.monotonic()-started,finished_at=now())
    write_new(directory/'preflight.json',report)
    print(json.dumps(report,indent=2),flush=True)
    return 0 if report['passed'] else 2


def main():
    if sys.argv[1:]==['--runtime-probe-only']:
        print('CAMPAIGN_RUNTIME='+json.dumps(runtime_record(),allow_nan=False),flush=True)
        return 0
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-root',type=Path,required=True)
    parser.add_argument('--manifest',type=Path,default=HERE/'initialization_manifest.json')
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--release-sha256',required=True)
    parser.add_argument('--preflight-only',action='store_true',help='Check constructor/MPI/runtime only; never reserve or grade an episode')
    choice=parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--episode-index',type=int,choices=range(30))
    choice.add_argument('--episode-id')
    args=parser.parse_args()
    episode,task,release,protocol_hash=validate_inputs(args)
    # No incidental environment override: the original grader's existing
    # rejection and child filter remain authoritative.
    from benchmark.grade_local import load_task_protocol
    protocol=load_task_protocol(task,verify_files=True)
    protocol.reject_parent_overrides()
    if os.geteuid()==0:raise RuntimeError('Original grader refuses root')
    runtime,probe_log=preflight_runtime(release['runtime_expected_sha256'])
    bindings={'manifest_sha256':args.manifest_sha256,'protocol_sha256':protocol_hash,
              'initial_phase_release_sha256':args.release_sha256}
    if args.preflight_only:
        return constructor_preflight(episode,task,args.out_root,bindings,runtime,probe_log)
    return execute_episode(episode,task,args.out_root,bindings,runtime,probe_log)


if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        print('Initial phase blocked; no automatic retry: {}: {}'.format(type(exc).__name__,exc),file=sys.stderr)
        sys.exit(2)

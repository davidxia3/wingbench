"""Prospective v5 numerical operations. Forward target/gate matches benchmark.

Adjoint target, failure flags, explicit residual gate and derivative math remain
unchanged. Historical qualification certificates do not certify this revision.
"""
from pathlib import Path
import json
import math
import time
import numpy as np


FORWARD_GATE=1e-10
NATIVE_GATE=1.1e-9
MAX_NATIVE_ATTEMPTS=3


def json_safe(value):
    if isinstance(value,dict):return {k:json_safe(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [json_safe(v) for v in value]
    if isinstance(value,np.ndarray):return json_safe(value.tolist())
    if isinstance(value,(float,np.floating)) and not math.isfinite(float(value)):return None
    if isinstance(value,np.generic):return value.item()
    return value


def write_json(path,value):
    path=Path(path);temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(json_safe(value),indent=2,allow_nan=False)+'\n')
    temporary.replace(path)


def forward_valid(norms,values,failed):
    norms=np.asarray(norms,dtype=float);values=np.asarray(values,dtype=float)
    return bool(norms.shape==(3,) and np.isfinite(norms).all() and norms[0]>0 and
        np.all(norms[1:]>=0) and np.isfinite(values).all() and not failed and
        math.isfinite(float(norms[-1]/norms[0])) and norms[-1]/norms[0]<=FORWARD_GATE)


def native_valid(norms,failed):
    norms=np.asarray(norms,dtype=float)
    return bool(norms.shape==(3,) and np.isfinite(norms).all() and norms[0]>0 and
        np.all(norms[1:]>=0) and not failed and math.isfinite(float(norms[-1]/norms[0])) and
        norms[-1]/norms[0]<=NATIVE_GATE)


class Evaluator:
    def all_true(self,condition):
        return all(self.comm.allgather(bool(condition)))

    def forward(self,y,label):
        y=np.asarray(y,dtype=float)
        if not self.all_true(y.shape==(39,) and np.isfinite(y).all()):
            raise ValueError('Forward requires a finite39-vector')
        points,area=self.surface.evaluate(y[:38])
        coordinates=self.coords0+points[self.indices]-self.base_surface[self.indices]
        if not self.all_true(np.isfinite(coordinates).all() and np.isfinite(area) and area>0):
            raise ValueError('Invalid surface or reference area')
        self.solver.setSurfaceCoordinates(coordinates,self.solver.designFamilyGroup)
        self.ap.alpha=float(y[38]);self.ap.areaRef=area
        start=time.monotonic();self.solver(self.ap)
        funcs={};self.solver.evalFunctions(self.ap,funcs)
        norms=np.asarray(self.solver.getResNorms(),dtype=float)
        values=np.array([funcs[self.ap.name+'_cl'],funcs[self.ap.name+'_cd']],dtype=float)
        failed=bool(self.ap.solveFailed or self.ap.fatalFail)
        valid=self.all_true(forward_valid(norms,values,failed))
        relative=float(norms[-1]/norms[0]) if norms.shape==(3,) and norms[0]>0 else float('nan')
        self.counter+=1
        record={'call':self.counter,'label':label,'input':y.tolist(),'cl':float(values[0]),
            'cd':float(values[1]),'area':area,'relative_residual':relative,'solve_failed':failed,
            'raw_norms':norms.tolist(),'raw_norms_repr':[repr(float(v)) for v in norms],
            'finite_flags':{'norms':bool(np.isfinite(norms).all()),'values':bool(np.isfinite(values).all())},
            'qualified':valid,'forward_gate':FORWARD_GATE,'wall_seconds':time.monotonic()-start}
        self.calls.append(record)
        if self.comm.rank==0:
            write_json(self.out/'forward_calls.json',self.calls)
            print('V5_FORWARD_RESULT',json.dumps(json_safe(record)),flush=True)
        self.comm.barrier()
        if not valid:raise RuntimeError('Forward solve failed v5 numerical checks')
        self.last_y=y.copy();self.last_values=values.copy()
        return values

    def gradient(self,y,values):
        from mpi4py import MPI
        y=np.asarray(y,dtype=float);values=np.asarray(values,dtype=float)
        if not self.all_true(self.last_y is not None and np.array_equal(y,self.last_y) and
                             values.shape==(2,) and np.isfinite(values).all() and
                             np.array_equal(values,self.last_values)):
            raise ValueError('Gradient requires a finite matching forward')
        surface_jac,area_jac=self.surface.jacobian(y[:38],self.indices)
        _,area=self.surface.evaluate(y[:38])
        if not self.all_true(np.isfinite(surface_jac).all() and np.isfinite(area_jac).all() and
                             np.isfinite(area) and area>0):
            raise ValueError('Invalid geometry Jacobian')
        gradient=np.empty((2,39))
        for index,function in enumerate(('cl','cd')):
            start=time.monotonic()
            for attempt in range(1,MAX_NATIVE_ATTEMPTS+1):
                begin=time.monotonic();sens={}
                self.solver.evalFunctionsSens(self.ap,sens,evalFuncs=[function])
                initial,starting,final,failed=self.solver.getAdjointResNorms()
                norms=np.asarray([initial,starting,final],dtype=float)
                solver_failed=bool(failed or self.ap.adjointFailed)
                well_formed=self.all_true(np.isfinite(norms).all() and initial>0 and min(starting,final)>=0)
                qualified=self.all_true(native_valid(norms,solver_failed))
                any_failed=not self.all_true(not solver_failed)
                relative=float(final/initial) if initial>0 else float('nan')
                record={'function':function,'attempt':attempt,'rhs_norm':float(initial),
                    'starting_residual_norm':float(starting),'final_residual_norm':float(final),
                    'relative_residual':relative,'failed':any_failed,'solver_failed':any_failed,
                    'native_gate':NATIVE_GATE,'strict_native_gate':NATIVE_GATE,'qualified':qualified,
                    'internal_target':1e-12,'solver_status':'accepted' if qualified else 'failed_gate_or_solver',
                    'status_authority':'ADflow failure flags AND recomputed finite residual gate',
                    'petsc_reason_code':None,'reason_code_note':'Not exposed by pinned ADflow API; not inferred as fact',
                    'finite_norms':well_formed,'raw_norms_repr':[repr(float(v)) for v in norms],
                    'wall_seconds':time.monotonic()-begin}
                self.adjoint_attempts.append(record.copy())
                if self.comm.rank==0:
                    write_json(self.out/'adjoint_attempts.json',self.adjoint_attempts)
                    write_json(self.out/'native_attempts.json',self.adjoint_attempts)
                    print('V5_NATIVE_ATTEMPT',json.dumps(json_safe(record)),flush=True)
                self.comm.barrier()
                if qualified or any_failed or not well_formed:break
            self.adjoint_calls.append(record.copy())
            if self.comm.rank==0:
                write_json(self.out/'adjoint_calls.json',self.adjoint_calls)
                write_json(self.out/'native_finals.json',self.adjoint_calls)
            self.comm.barrier()
            if not qualified:raise RuntimeError('Adjoint failed v5 numerical checks after bounded refinement')
            psi=np.asarray(self.solver.getAdjoint(function)).copy()
            if not self.all_true(np.isfinite(psi).all()):raise ValueError('Nonfinite adjoint')
            xsbar=self.solver.computeJacobianVectorProductBwd(resBar=-psi,funcsBar={function:1.},xSDeriv=True)
            local=np.einsum('ij,ijk->k',xsbar,surface_jac)
            gradient[index,:38]=self.comm.allreduce(local,op=MPI.SUM)-values[index]/area*area_jac
            gradient[index,38]=float(np.asarray(sens[self.ap.name+'_'+function]['alpha']).ravel()[0])
            if not self.all_true(np.isfinite(gradient[index]).all()):raise ValueError('Nonfinite total derivative')
            if self.comm.rank==0:
                write_json(self.out/'gradient_progress.json',{'functions_finished':['cl','cd'][:index+1],
                    'gradient_cl_cd':gradient[:index+1].tolist(),'native_finals':self.adjoint_calls,
                    'qualification_completed':False,'can_release_pilot':False})
            self.comm.barrier()
        return gradient

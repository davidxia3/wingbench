"""Fresh candidate processes make failed-trial recovery independent of solver state."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import numpy as np
from rebuttal.adjoint.campaign_v4.common import HERE,write,now

class Executor:
    def __init__(self,initial,out):
        self.initial=Path(initial);self.out=Path(out);self.proc=None;self.log=None
        self.sequence=0;self.work=None;self.x=None;self.values=None

    def close(self):
        if self.proc is not None:
            if self.proc.poll() is None:
                os.killpg(self.proc.pid,signal.SIGTERM)
                try:self.proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(self.proc.pid,signal.SIGKILL);self.proc.wait()
            if self.log:self.log.close()
            self.proc=None

    def start(self,x,reservation):
        self.close();self.work=self.out/('oracle-%05d'%reservation['sequence'])
        self.work.mkdir(parents=True,exist_ok=False)
        (self.work/'requests').mkdir();(self.work/'responses').mkdir()
        self.log=(self.work/'worker.log').open('w')
        env=os.environ.copy()
        env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONNOUSERSITE='1')
        cmd=['mpirun','-np','16','--bind-to','none',sys.executable,str(HERE/'worker.py'),
            '--initial',str(self.initial),'--work',str(self.work)]
        self.proc=subprocess.Popen(cmd,stdout=self.log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        self.sequence=0;self.x=np.asarray(x).copy();self.values=None
        write(self.work/'launch.json',dict(command=cmd,pid=self.proc.pid,started_at=now(),reservation=reservation))

    def rpc(self,command,timeout):
        path=self.work/'responses'/('%05d.json'%self.sequence)
        start=time.monotonic()
        write(self.work/'requests'/('%05d.json'%self.sequence),command,exclusive=True)
        while not path.exists():
            elapsed=time.monotonic()-start
            if self.proc.poll() is not None:
                return dict(status='infrastructure_failure',error='MPI process exited without a classified result',
                    value=None,cost=dict(wall_seconds=elapsed,allocated_rank_hours=16*elapsed/3600))
            if elapsed>=timeout:
                active=json.loads((self.work/'active.json').read_text()) if (self.work/'active.json').exists() else {}
                self.close()
                kind='scientific_failure' if active.get('phase')==command['op'] else 'infrastructure_failure'
                result=dict(status=kind,error='Prospective %s wall-time limit reached'%command['op'],
                    value=None,cost=dict(wall_seconds=elapsed,allocated_rank_hours=16*elapsed/3600,
                    partial_records_in_worker_directory=True))
                write(self.work/('timeout-%05d.json'%self.sequence),result)
                return result
            time.sleep(.25)
        response=json.loads(path.read_text())
        if response['request']!=command:raise ValueError('Worker response is for a different request')
        self.sequence+=1
        return response

    def __call__(self,op,x,reservation):
        if op=='forward':self.start(x,reservation)
        elif self.proc is None or not np.array_equal(x,self.x) or self.values is None:
            return dict(status='infrastructure_failure',error='Gradient lacks matching live forward state',value=None)
        results=[];costs=[]
        for mach in range(3):
            cmd={'op':op,'x':np.asarray(x).tolist(),'mach':mach}
            if op=='gradient':cmd['values']=self.values[mach]
            response=self.rpc(cmd,7200 if op=='forward' else 14400)
            costs.append(response.get('cost',{}))
            if response['status']!='ok':
                self.close()
                return dict(status=response['status'],error=str(response.get('error')),value=None,cost={'conditions':costs})
            results.append(response['value'])
        if op=='forward':self.values=results
        return dict(status='ok',value=results,cost={'conditions':costs})

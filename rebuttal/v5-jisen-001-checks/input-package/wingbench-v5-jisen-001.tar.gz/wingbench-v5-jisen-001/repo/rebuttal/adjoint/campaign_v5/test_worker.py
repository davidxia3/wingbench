"""Actual worker loop, serialization, and live-state protocol with mock solvers."""
import copy
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch
import numpy as np
from rebuttal.adjoint.campaign_v5 import worker
from rebuttal.adjoint.campaign_v5.common import write
from rebuttal.adjoint.campaign_v5.numerics import Evaluator as NumericalEvaluator
from rebuttal.adjoint.campaign_v5.executor import Executor

class Comm:
    rank=0;size=16
    def barrier(self):pass
    def bcast(self,v,root):return v
    def allgather(self,v):return [v]*16
    def gather(self,v,root):return [v]*16


def invoke(fail=False,bad_success=False,op='forward'):
    record=dict(cl=.41,cd=.02,relative_residual=1e-10,solve_failed=False,qualified=True,
        raw_norms_repr=['1.0','1.0','1e-10'],finite_flags=dict(norms=True,values=True))
    if fail:record.update(cl=float('nan'),cd=float('nan'),relative_residual=float('nan'),
        solve_failed=True,qualified=False,raw_norms_repr=['0.0','0.0','nan'],
        finite_flags=dict(norms=False,values=False))
    if bad_success:record['wall_seconds']=float('nan')
    class Evaluator:
        def __init__(self,comm,mesh,leaf,initial,mach):
            self.calls=[];self.adjoint_attempts=[]
            self.solver=types.SimpleNamespace(adflow=object(),setOption=lambda *a:None)
            write(leaf/'setup.json',{})
        def forward(self,*args):
            self.calls.append(copy.deepcopy(record))
            if fail:raise RuntimeError('Forward solve failed v5 numerical checks')
            return np.array([.41,.02])
    mods={'mpi4py':types.SimpleNamespace(MPI=types.SimpleNamespace(COMM_WORLD=Comm())),
        'rebuttal.adjoint.campaign_v5.evaluator':types.SimpleNamespace(CampaignEvaluator=Evaluator)}
    with patch.dict('sys.modules',mods),tempfile.TemporaryDirectory() as d:
        out=Path(d);write(out/'initial.json',dict(mesh=dict(relative_path='mock')))
        write(out/'requests/00000.json',dict(op=op,mach=0,x=[0.]*41))
        write(out/'requests/00001.json',dict(op='stop'))
        worker.main(types.SimpleNamespace(initial=out/'initial.json',work=out))
        return json.loads((out/'responses/00000.json').read_text())

class WorkerTests(unittest.TestCase):
    def test_nan_failure_delivered_with_cost_and_flags(self):
        r=invoke(fail=True);self.assertEqual(r['status'],'scientific_failure');self.assertIsNone(r['value'])
        c=r['cost']['forward_records'][0];self.assertIsNone(c['relative_residual'])
        self.assertFalse(c['qualified']);self.assertFalse(c['finite_flags']['norms'])
        self.assertEqual(c['raw_norms_repr'],['0.0','0.0','nan'])
        self.assertGreater(r['cost']['wall_seconds'],0)
    def test_valid_success_is_not_changed(self):
        r=invoke();self.assertEqual(r['status'],'ok');self.assertEqual(r['value'],[.41,.02])
        self.assertEqual(r['cost']['forward_records'][0]['relative_residual'],1e-10)
    def test_nonfinite_success_cost_is_not_silently_sanitized(self):
        with self.assertRaises(ValueError):invoke(bad_success=True)
    def test_unknown_operation_does_not_call_adjoint(self):
        r=invoke(op='unknown');self.assertEqual(r['status'],'infrastructure_failure')
        self.assertEqual(r['cost']['forward_records'],[])
    def test_gradient_values_must_match_last_forward_exactly(self):
        e=NumericalEvaluator();e.comm=Comm();e.last_y=np.zeros(39);e.last_values=np.array([.41,.02])
        with patch.dict('sys.modules',{'mpi4py':types.SimpleNamespace(MPI=object())}):
            with self.assertRaisesRegex(ValueError,'matching forward'):e.gradient(np.zeros(39),[.41,.021])
            with self.assertRaisesRegex(ValueError,'matching forward'):e.gradient(np.ones(39),e.last_values)
    def test_new_forward_always_creates_worker_and_gradient_reuses_matching_one(self):
        class SimExecutor(Executor):
            def __init__(self):super().__init__('mock','mock');self.starts=[];self.requests=[]
            def start(self,x,r):
                self.starts.append(r['sequence']);self.proc=object();self.x=np.array(x);self.values=None
            def rpc(self,c,timeout):
                self.requests.append(c)
                return dict(status='ok',value=[.41,.02] if c['op']=='forward' else np.zeros((2,41)).tolist())
        e=SimExecutor();x=np.zeros(41)
        self.assertEqual(e('gradient',x,{'sequence':0})['status'],'infrastructure_failure')
        e('forward',x,{'sequence':1});e('gradient',x,{'sequence':2})
        self.assertEqual(e.starts,[1]);self.assertEqual(e.requests[-1]['values'],[.41,.02])
        self.assertEqual(e('gradient',x+1,{'sequence':3})['status'],'infrastructure_failure')
        e('forward',x+1,{'sequence':4});self.assertEqual(e.starts,[1,4])

if __name__=='__main__':unittest.main(verbosity=2)

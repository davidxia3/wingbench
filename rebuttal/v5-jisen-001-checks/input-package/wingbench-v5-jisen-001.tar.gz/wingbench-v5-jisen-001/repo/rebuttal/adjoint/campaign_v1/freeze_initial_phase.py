"""Freeze the initial-grade phase in a new, isolated repository snapshot.

This does not certify numerical optimization and cannot release it. The
pre-existing Jisen release is read and verified, never changed.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
REL = 'rebuttal/adjoint/campaign_v1/'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def freeze(destination, extras):
    original = ROOT / 'rebuttal/compute/jisen_verify_v1/package_manifest.json'
    package = json.loads(original.read_text())
    expected = dict(package['source_sha256'])
    expected['rebuttal/compute/jisen_verify_v1/package_manifest.json'] = sha(original)
    for name in extras:
        path = Path(name)
        if path.is_absolute() or '..' in path.parts or not str(path).startswith(REL):
            raise ValueError('Extra must be an explicit relative campaign file: ' + name)
        expected[name] = sha(ROOT / path)
    expected[REL + 'freeze_initial_phase.py'] = sha(Path(__file__))
    manifest_path = REL + 'initialization_manifest.json'
    if manifest_path not in expected:
        raise ValueError('Initialization manifest must be explicitly included')
    initialization = json.loads((ROOT / manifest_path).read_text())
    for name, digest in initialization['source_sha256'].items():
        path = Path(name)
        if path.is_absolute() or '..' in path.parts:
            raise ValueError('Invalid initialization source path: ' + name)
        if name in expected and expected[name] != digest:
            raise ValueError('Initialization and Jisen source hashes disagree: ' + name)
        expected[name] = digest
    # Check all bytes before creating a release; no partially verified source.
    for name, digest in expected.items():
        if sha(ROOT / name) != digest:
            raise ValueError('Frozen source changed: ' + name)
    destination.mkdir(parents=True, exist_ok=False)
    repo = destination / 'repo'
    for name, digest in sorted(expected.items()):
        target = repo / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
        if sha(target) != digest:
            raise ValueError('Snapshot copy changed: ' + name)
    release = {
        'schema': 'wingbench-adjoint-initial-phase-release-v1',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'phase': 'initial_grade_only',
        'can_release_optimization': False,
        'source_git_commit': package['source_git_commit'],
        'initialization_manifest': {'path': manifest_path, 'sha256': expected[manifest_path]},
        'source_sha256': expected,
        'runtime_expected_sha256': package['runtime_expected_sha256'],
        'frozen_numerical_protocol_sha256': package['protocol_sha256'],
        'grading_mode': 'local',
        'official_sealed_grade': False,
        'scientific_scope': 'Exactly one original-grader initial evaluation per predeclared episode, counted as attempt 1 of 32. No adjoint optimization.',
        'limitations': [
            'Native adjoint qualification, bounded pilot, and independent pilot regrade have not passed.',
            'Hardware timing is recorded; Quest results are not automatically hardware-equivalent to the historical AWS reference.',
            'The seed policy includes one repeated start: 30 episodes, 27 distinct task/start pairs.',
        ],
    }
    release_path = repo / (REL + 'initial_phase_release.json')
    release_path.write_text(json.dumps(release, indent=2, sort_keys=True) + '\n')
    for path in repo.rglob('*'):
        if path.is_file():
            path.chmod(0o444)
    return {'destination': str(destination.resolve()), 'repository': str(repo.resolve()),
            'release_sha256': sha(release_path), 'source_files': len(expected),
            'manifest_sha256': expected[manifest_path], 'can_release_optimization': False}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--dest', type=Path, required=True)
    p.add_argument('--extra', action='append', required=True)
    args = p.parse_args()
    print(json.dumps(freeze(args.dest, args.extra), indent=2))

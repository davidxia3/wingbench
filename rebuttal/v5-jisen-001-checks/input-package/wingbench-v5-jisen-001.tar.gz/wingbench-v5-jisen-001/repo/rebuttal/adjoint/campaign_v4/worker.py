"""Resident MPI worker for exactly one candidate, isolated from every other trial."""
import argparse
import json
from pathlib import Path
import resource
import sys
import time
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v4.common import write,now

def failure_kind(exc):
    known=('Forward solve failed v4 numerical checks','Adjoint failed v4 numerical checks',
           'Nonfinite adjoint','Invalid geometry Jacobian','Nonfinite total derivative',
           'Invalid surface or reference area','Surface topology changed',
           'Nonpositive candidate CL/CD')
    return 'scientific' if isinstance(exc,(RuntimeError,ValueError)) and str(exc).startswith(known) else 'execution'

def verify_forward_record(record):
    residual=record['relative_residual']
    if (not np.isfinite(residual) or not 0<=residual<=1e-10 or
        record['solve_failed'] is not False or record.get('qualified') is not True):
        raise RuntimeError('Forward solve failed v4 numerical checks: inconsistent record')

def main(args):
    from mpi4py import MPI
    from rebuttal.adjoint.campaign_v4.evaluator import CampaignEvaluator
    from benchmark.common import json_ready
    comm=MPI.COMM_WORLD
    if comm.size!=16:raise ValueError('Exactly 16 ranks required')
    initial=json.loads(args.initial.read_text());mesh=args.initial.parent/initial['mesh']['relative_path']
    evaluators={};sequence=0
    while True:
        command=None
        if comm.rank==0:
            path=args.work/'requests'/('%05d.json'%sequence)
            while not path.exists():time.sleep(.1)
            command=json.loads(path.read_text())
        command=comm.bcast(command,root=0)
        if command['op']=='stop':return 0
        start=time.monotonic();mach=command['mach'];result=None;error=None
        before_cpu=resource.getrusage(resource.RUSAGE_SELF)
        old_calls=old_native=0
        try:
            x=np.asarray(command['x'],dtype=float)
            if command['op'] not in ('forward','gradient') or mach not in (0,1,2) or x.shape!=(41,) or not np.isfinite(x).all():
                raise ValueError('Malformed candidate request')
            if mach not in evaluators:
                if comm.rank==0:write(args.work/'active.json',dict(phase='constructor',mach=mach,started_at=now()))
                leaf=args.work/('mach_%d'%mach)
                if comm.rank==0:leaf.mkdir(exist_ok=False)
                comm.barrier()
                ev=CampaignEvaluator(comm,mesh,leaf,initial,mach)
                ev.solver.setOption('timeLimit',7200.)
                evaluators[mach]=ev
                if len({id(e.solver.adflow) for e in evaluators.values()})!=len(evaluators):
                    raise RuntimeError('Solver instances share mutable Fortran state')
                if comm.rank==0:
                    setup=json.loads((leaf/'setup.json').read_text())
                    setup.update(initialization_source='Free v4 original-grade initialization',
                        candidate_initialization='Fresh solver, cold flow state for each candidate',
                        timeLimit=7200.,candidate_request=command['x'])
                    write(leaf/'setup.json',setup)
            ev=evaluators[mach];old_calls=len(ev.calls);old_native=len(ev.adjoint_attempts)
            x=np.asarray(command['x'],dtype=float); y=np.r_[x[:38],x[38+mach]]
            if comm.rank==0:write(args.work/'active.json',dict(phase=command['op'],mach=mach,started_at=now()))
            if command['op']=='forward':
                result=ev.forward(y,'v4-candidate')
                verify_forward_record(ev.calls[-1])
                if np.any(result<=0):raise RuntimeError('Nonpositive candidate CL/CD')
            else:
                g=ev.gradient(y,np.asarray(command['values'],dtype=float))
                result=np.zeros((2,41));result[:,:38]=g[:,:38];result[:,38+mach]=g[:,38]
        except Exception as exc:
            kind=failure_kind(exc)
            if str(exc)=='Nonpositive candidate CL/CD':kind='scientific'
            error={'error':str(exc),'type':type(exc).__name__,'kind':kind}
        errors=comm.allgather(error)
        after=resource.getrusage(resource.RUSAGE_SELF)
        cpu=comm.gather((after.ru_utime+after.ru_stime)-(before_cpu.ru_utime+before_cpu.ru_stime),root=0)
        rss=comm.gather(after.ru_maxrss*1024,root=0)
        elapsed=time.monotonic()-start
        if comm.rank==0:
            failure=next((e for e in errors if e and e['kind']!='scientific'),None) or next((e for e in errors if e),None)
            ev=evaluators.get(mach)
            response={'status':('scientific_failure' if failure['kind']=='scientific' else 'infrastructure_failure') if failure else 'ok',
                'error':failure,'value':None if failure else np.asarray(result).tolist(),
                'request':command,'finished_at':now(),
                'cost':{'wall_seconds':elapsed,'allocated_rank_hours':16*elapsed/3600,
                    'rank_cpu_seconds':cpu,'per_rank_highwater_bytes':rss,
                    'forward_records':ev.calls[old_calls:] if ev else [],
                    'native_attempts':ev.adjoint_attempts[old_native:] if ev else [],
                    'memory_note':'Rank process highwater; not aggregate concurrent peak'}}
            if failure:
                # Failed diagnostics may contain NaN; retain flags/raw repr and
                # encode unavailable numbers as null. Never sanitize a success.
                response['cost']=json_ready(response['cost'])
            write(args.work/'responses'/('%05d.json'%sequence),response)
        sequence+=1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--initial',type=Path,required=True)
    p.add_argument('--work',type=Path,required=True);a=p.parse_args()
    try:sys.exit(main(a))
    except BaseException:
        import traceback;traceback.print_exc()
        from mpi4py import MPI
        MPI.COMM_WORLD.Abort(3)

"""Launch one approved, fresh eight-attempt pilot; no continuation or replacement."""
import argparse
import importlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v5.common import HERE,sha,write,verify_release,now,require_approval,require_runtime_check,runtime_binding

def optimizer_runtime():
    import cyipopt
    import numpy
    import numpy.core._multiarray_umath as numeric
    mod=importlib.import_module(cyipopt.Problem.__module__)
    files=[Path(mod.__file__),Path(cyipopt.__file__),Path(numeric.__file__),Path(sys.executable)]
    ldd=subprocess.check_output(['ldd',str(files[0])],text=True)
    files += [Path(s) for s in re.findall(r'=>\s+(/\S+)',ldd)]
    cpu=next((s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),'unknown')
    return dict(cyipopt_version=cyipopt.__version__,ipopt_version=list(cyipopt.IPOPT_VERSION),
        numpy_version=numpy.__version__,files={str(p):sha(p) for p in files},cpu_model=cpu,
        thread_environment={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')})

def validate_initial(initial_path,release_sha256):
    initial=json.loads(initial_path.read_text())
    roster=json.loads((HERE/'roster.json').read_text())
    row=next(r for r in roster['episodes'] if r['episode_id']==initial['episode_id'])
    if row['episode_index'] not in range(6):raise ValueError('Only pilot episodes released')
    if initial['roster_sha256']!=sha(HERE/'roster.json') or any(initial[k]!=row[k] for k in ('episode_index','geometry','geometry_sha256','task','target_cl','mach')):
        raise ValueError('Initial wing or task identity changed')
    if initial['release_sha256']!=release_sha256:raise ValueError('Wrong initial release')
    if sha(initial_path.parent/'initial_grade.json')!=initial['grade_sha256']:raise ValueError('Initial evidence changed')
    if not initial['delivered']:raise ValueError('Initial wing was not delivered; no optimization permitted')
    raw=json.loads((initial_path.parent/'initial_grade.json').read_text())
    conditions=sorted(raw['conditions'],key=lambda c:float(c['mach']))
    if (raw['benchmark_grade']['delivered'] is not True or
        raw['benchmark_grade']['ld']!=initial['initial_score'] or
        raw['geometry']['sha256']!=row['geometry_sha256'] or
        raw['protocol']['canonical_sha256']!=initial['original_protocol_sha256'] or
        [float(c['mach']) for c in conditions]!=row['mach'] or
        [float(c['measurements']['realized_aoa_deg']) for c in conditions]!=initial['alphas']):
        raise ValueError('Initialization values disagree with original raw grade')
    initial['reference_cl_cd']=[[float(c['measurements'][k]) for k in ('cl','cd')]
        for c in conditions]
    mesh=initial_path.parent/initial['mesh']['relative_path']
    if not mesh.resolve().is_relative_to(initial_path.parent.resolve()) or sha(mesh)!=initial['mesh']['sha256']:
        raise ValueError('Initial mesh missing, changed, or outside episode')
    from rebuttal.adjoint.campaign_v5.trim_artifacts import capture,validate
    if capture(raw,initial_path.parent)!=initial.get('benchmark_trim'):
        raise ValueError('Benchmark trim inputs disagree with original grade')
    validate(initial,initial_path.parent)
    return initial

def main(args):
    release=verify_release(HERE/'release.json',args.release_sha256)
    require_approval(args.approval,args.release_sha256)
    if args.stage_limit!=8:raise ValueError('Eight-attempt pilot only')
    initial=validate_initial(args.initial,args.release_sha256)
    from rebuttal.adjoint.campaign_v1.run_initial_grade import preflight_runtime
    runtime,_=preflight_runtime(release['runtime_expected_sha256'])
    opt_runtime=optimizer_runtime()
    if opt_runtime['cyipopt_version']!='1.4.1' or opt_runtime['ipopt_version']!=[3,13,4]:raise ValueError('Untested optimizer build')
    if any(v!='1' for v in opt_runtime['thread_environment'].values()):raise ValueError('Deterministic single-threaded optimizer required')
    checked_runtime=runtime_binding(runtime,opt_runtime)
    require_runtime_check(args.runtime_check,args.release_sha256,checked_runtime)
    if args.out.exists():raise ValueError('Fresh pilot only; existing episode output cannot be restarted')
    args.out.mkdir(parents=True,exist_ok=False)
    # Only a single live owner can enter or replay this episode.
    import fcntl
    lock=(args.out/'owner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    write(args.out/'runtime.json',dict(scientific=runtime,optimizer=opt_runtime))
    binding={'pilot_release_sha256':args.release_sha256,'initialization_sha256':sha(args.initial),
        'initial_geometry_sha256':initial['geometry_sha256'],'optimizer_runtime':opt_runtime}
    from benchmark.common import load_box
    from rebuttal.adjoint.campaign_v5.core import optimize
    from rebuttal.adjoint.campaign_v5.executor import Executor
    import cyipopt
    executor=Executor(args.initial,args.out/'workers')
    try:result=optimize(args.out,initial,load_box(),executor,binding,args.stage_limit,cyipopt)
    finally:executor.close();lock.close()
    print(json.dumps(result,indent=2),flush=True)
    return 3 if result['phase']=='blocked' else 0

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--initial',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--release-sha256',required=True)
    p.add_argument('--stage-limit',type=int,default=8)
    p.add_argument('--approval',type=Path,required=True)
    p.add_argument('--runtime-check',type=Path,required=True)
    sys.exit(main(p.parse_args()))

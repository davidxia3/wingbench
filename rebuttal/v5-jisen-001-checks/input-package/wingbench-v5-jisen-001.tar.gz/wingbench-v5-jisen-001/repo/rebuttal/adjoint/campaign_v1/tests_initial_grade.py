"""No CFD/MPI: exercise durable reservation, result validation and failure handling."""
from pathlib import Path
from types import SimpleNamespace
import contextlib
import copy
import io
import json
import shutil
import tempfile
import unittest

from rebuttal.adjoint.campaign_v1 import run_initial_grade as driver
from benchmark.common import load_tasks


class InitialGradeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.episode=json.loads((driver.HERE/'initialization_manifest.json').read_text())['episodes'][0]
        self.task=load_tasks()[self.episode['task']]
        self.bindings={'manifest_sha256':'a'*64,'protocol_sha256':'b'*64,
                       'initial_phase_release_sha256':'c'*64}
        self.calls=[]

    def tearDown(self):self.temp.cleanup()

    @property
    def directory(self):return self.root/'episodes'/self.episode['episode_id']

    def factory(self,mode='pass'):
        test=self
        class FakeGrader:
            def __init__(self,task,work_root,run_id):
                test.calls.append('constructor')
                self.work=work_root;self.work.mkdir(parents=True,exist_ok=True)
                self.protocol=SimpleNamespace(payload={'execution':{'mpi_ranks':16,'infrastructure_retries':0}},
                    sha256='d'*64,snapshot=lambda:{'frozen':'fake-protocol'})
                env={'OMP_NUM_THREADS':'1'}
                self.protocol.payload['environment']={'required_child_environment':env}
                report=self.work/'fingerprint.json'
                report.write_text(json.dumps({'status':'complete','mpi_smoke_test':{'passed':mode!='smoke_error','requested_ranks':16,
                    'required_child_environment':env,'probe_process_load_bearing_environment':env},
                    'effective_probe_environment':env,
                    'filtered_scientific_import_smoke':{'passed':True,'returncode':0,'effective_environment':env}}))
                self.runtime_status={'probed':True,'report_file':str(report),'matches_campaign':False}
                if mode=='preflight':return
                test.assertTrue((test.directory/'initial_reservation.json').is_file())
                nomination=json.loads((test.directory/'initial_nomination.json').read_text())
                test.assertEqual(nomination['geometry'],test.episode['geometry'])
                if mode=='constructor_error':raise OSError('fake constructor unavailable')

            def grade(self,geometry,label):
                test.calls.append('grade')
                if mode=='preflight':raise AssertionError('Preflight must never call grade')
                if mode=='grade_error':raise RuntimeError('fake MPI startup exception')
                if mode=='scalar':return 7
                mesh=self.work/'mesh_attempt_00'/label/'wing_vol.cgns'
                mesh.parent.mkdir(parents=True);mesh.write_bytes(b'fake mesh for migration test')
                conditions=[]
                for index,mach in enumerate(test.episode['mach']):
                    cl=test.episode['target_cl'];ld=20.;cd=cl/ld
                    measurements={'realized_aoa_deg':2.+index,'cl':cl,'cd':cd,'ld':ld,
                                  'err_cl':1e-6,'solvecl_iterations':3}
                    conditions.append({'mach':mach,'cl_target':cl,'outcome_class':'valid',
                        'measurements':measurements,'attempts':[{'measurements':measurements}]})
                raw={'geometry':{'sha256':test.episode['geometry_sha256'],'geom_38d':geometry},
                    'protocol':{'canonical_sha256':self.protocol.sha256,'snapshot':self.protocol.snapshot()},
                    'benchmark_grade':{'delivered':mode!='no_delivery','ld':20. if mode!='no_delivery' else None,
                        'outcome':'pass' if mode!='no_delivery' else 'inconclusive_timeout',
                        'reason_codes':[] if mode!='no_delivery' else ['timeout']},
                    'conditions':list(reversed(conditions)),
                    'mesh':{'attempts':[{}],'volume_grid_artifact':{'path':str(mesh),'sha256':driver.sha(mesh)}},
                    'timing':{'core_seconds':32.,'wall_seconds':2.}}
                if mode=='mesh_hash_error':raw['mesh']['volume_grid_artifact']['sha256']='e'*64
                if mode=='mesh_escape':
                    escaped=test.root/'outside.cgns';escaped.write_bytes(b'outside')
                    raw['mesh']['volume_grid_artifact']={'path':str(escaped),'sha256':driver.sha(escaped)}
                if mode=='measurement_error':raw['conditions'][0]['measurements']['cd']*=2
                return raw
        return FakeGrader

    def run_episode(self,mode='pass'):
        with contextlib.redirect_stdout(io.StringIO()):
            result=driver.execute_episode(self.episode,self.task,self.root,self.bindings,{}, {},self.factory(mode))
        return result,json.loads((self.directory/'initialization.json').read_text())

    def test_counted_success_and_migration(self):
        code,result=self.run_episode()
        self.assertEqual(code,0);self.assertEqual(self.calls,['constructor','grade'])
        self.assertEqual(result['phase'],'initialized_awaiting_qualification')
        self.assertTrue(result['initialization_complete']);self.assertFalse(result['can_release_optimization'])
        self.assertEqual(result['joint_attempts_consumed'],1)
        self.assertEqual(result['alphas'],[2.,3.,4.]);self.assertEqual(result['initial_score'],20.)
        self.assertEqual(result['grade_sha256'],driver.sha(self.directory/'initial_grade.json'))
        moved=self.root/'moved_episode';shutil.copytree(self.directory,moved)
        self.assertEqual(driver.sha(moved/result['mesh']['relative_path']),result['mesh']['sha256'])
        with self.assertRaises(FileExistsError):self.run_episode()
        self.assertEqual(self.calls,['constructor','grade'])

    def test_partial_reservation_blocks(self):
        self.directory.mkdir(parents=True)
        (self.directory/'initial_reservation.json').write_text('{partial')
        with self.assertRaises(FileExistsError):self.run_episode()
        self.assertEqual(self.calls,[])

    def test_returned_undetermined_grade_retains_original_outcome(self):
        code,result=self.run_episode('no_delivery')
        self.assertEqual(code,2);self.assertTrue(result['initialization_complete'])
        self.assertEqual(result['phase'],'terminated_initial_grade_failure')
        self.assertEqual(result['original_grade_outcome'],'inconclusive_timeout')
        self.assertFalse(result['delivered']);self.assertEqual(result['joint_attempts_consumed'],1)
        self.assertIsNone(result['mesh']);self.assertEqual(self.calls.count('grade'),1)

    def test_constructor_exception_is_unresolved_not_failed_wing(self):
        code,result=self.run_episode('constructor_error')
        self.assertEqual(code,2);self.assertEqual(result['phase'],'blocked_initial_execution_error')
        self.assertIsNone(result['joint_attempts_consumed']);self.assertFalse(result['grade_available'])
        self.assertFalse(result['initialization_complete'])
        self.assertEqual(result['costs']['original_grader_calls_started'],0)
        self.assertFalse((self.directory/'initial_grade.json').exists())
        self.assertTrue((self.directory/'initial_grade_exception.json').is_file())

    def test_grade_exception_does_not_fabricate_completed_attempt(self):
        _,result=self.run_episode('grade_error')
        self.assertIsNone(result['joint_attempts_consumed'])
        self.assertEqual(result['costs']['original_grader_calls_started'],1)
        self.assertEqual(result['costs']['original_grader_results_returned'],0)
        self.assertIsNone(result['grade_sha256'])

    def test_each_worker_failed_mpi_smoke_blocks_before_grade(self):
        _,result=self.run_episode('smoke_error')
        self.assertEqual(result['phase'],'blocked_initial_execution_error')
        self.assertEqual(self.calls,['constructor'])
        self.assertEqual(result['costs']['original_grader_calls_started'],0)

    def test_bad_artifacts_preserve_returned_grade_but_block_use(self):
        for mode in ('mesh_hash_error','mesh_escape','measurement_error'):
            with self.subTest(mode=mode):
                if self.directory.exists():shutil.rmtree(self.directory)
                _,result=self.run_episode(mode)
                self.assertEqual(result['phase'],'blocked_initial_execution_error')
                self.assertTrue(result['delivered']);self.assertTrue(result['grade_available'])
                self.assertFalse(result['initialization_complete'])
                self.assertEqual(result['grade_sha256'],driver.sha(self.directory/'initial_grade.json'))

    def test_malformed_scalar_result_keeps_exception_evidence(self):
        _,result=self.run_episode('scalar')
        self.assertEqual(result['phase'],'blocked_initial_execution_error')
        self.assertIsNone(result['joint_attempts_consumed']);self.assertTrue(result['grade_available'])

    def test_constructor_preflight_does_not_reserve_or_grade(self):
        with contextlib.redirect_stdout(io.StringIO()):
            code=driver.constructor_preflight(self.episode,self.task,self.root,self.bindings,{}, {},self.factory('preflight'))
        self.assertEqual(code,0);self.assertEqual(self.calls,['constructor'])
        self.assertFalse((self.root/'episodes').exists())
        report=json.loads(next(self.root.glob('preflight_*/preflight.json')).read_text())
        self.assertEqual(report['episode_reservations_created'],0)
        self.assertEqual(report['original_grader_calls_started'],0)
        self.assertFalse(report['can_release_optimization'])


if __name__=='__main__':unittest.main()

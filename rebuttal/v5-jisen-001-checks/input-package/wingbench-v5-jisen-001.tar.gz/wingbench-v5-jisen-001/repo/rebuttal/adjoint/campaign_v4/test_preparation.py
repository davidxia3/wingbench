import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest
import numpy as np
from rebuttal.adjoint.campaign_v4.common import runtime_binding,sha
from rebuttal.adjoint.campaign_v4.qualify import compare,planned_directions
from benchmark.common import load_box,geometry_sha256
HERE=Path(__file__).resolve().parent

class PreparationTests(unittest.TestCase):
    def test_roster_reconstructs_without_reroll(self):
        paths=[HERE/'roster.json',HERE/'eligibility.json'];before=[sha(p) for p in paths]
        subprocess.run([sys.executable,str(HERE/'build_roster.py')],check=True,capture_output=True)
        self.assertEqual(before,[sha(p) for p in paths])
        r=json.loads(paths[0].read_text())['episodes'];self.assertEqual(len(r),6)
        for task in ('low','nominal','high'):
            rows=[e for e in r if e['task']==task];self.assertEqual(len(rows),2)
            self.assertEqual(len({e['geometry_sha256'] for e in rows}),2)
        for e in r:self.assertEqual(geometry_sha256(e['geometry']),e['geometry_sha256'])
    def test_qualification_geometry_perturbations_inside_box(self):
        r=json.loads((HERE/'roster.json').read_text())['episodes'][3];b=load_box()
        for d in planned_directions().values():
            for sign in (-1,1):self.assertTrue(b.contains(np.array(r['geometry'])+np.array(b.sd)*sign*.002*d[:38]))
    def test_derivative_check_detects_wrong_sign_or_scale(self):
        g=np.ones((3,2,41));d=np.zeros(41);d[0]=1;step=.001
        base=np.array([[.41,.02]]*3);plus=base+step;minus=base-step
        self.assertTrue(compare(g,d,plus,minus,step)['all_passed'])
        self.assertFalse(compare(-g,d,plus,minus,step)['all_passed'])
        self.assertFalse(compare(g*1.1,d,plus,minus,step)['all_passed'])
    def test_runtime_binding_stable_across_container_names_not_binaries(self):
        a=dict(sha256={'solver':'x'},hardware=dict(hostname='a',machine='x86_64',cpu_model='c',cgroup='a'))
        b=copy.deepcopy(a);b['hardware'].update(hostname='b',cgroup='b')
        self.assertEqual(runtime_binding(a,{}),runtime_binding(b,{}))
        b['sha256']['solver']='changed';self.assertNotEqual(runtime_binding(a,{}),runtime_binding(b,{}))
    def test_forward_target_equals_original_benchmark(self):
        from scripts.cfd.grading_protocol import _FINAL_SOLVER
        self.assertEqual(_FINAL_SOLVER['l2_convergence'],json.loads((HERE/'protocol.json').read_text())['forward_gate'])

if __name__=='__main__':unittest.main(verbosity=2)

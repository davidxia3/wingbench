#!/bin/bash
#SBATCH --account=p33116
#SBATCH --partition=normal
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --mem=96G
#SBATCH --time=12:00:00
#SBATCH --job-name=wb-initial-grade-v1
#SBATCH --output=/scratch/unk4211/wingbench-rebuttal-20261106/initial-grade-%A_%a.log
set -euo pipefail
module load singularityce/4.3.1-gcc-8.5.0
export LD_LIBRARY_PATH="/gpfs/software/2025/spack/opt/spack/linux-rhel8-x86_64/gcc-8.5.0/libfuse-3.16.2-cg5xbdf2pwgqhdwoaujsoqaw2mhvjb3t/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
RUN_ROOT=/scratch/unk4211/wingbench-rebuttal-20261106
CAMPAIGN_NAME=${1:?campaign output name required}
MANIFEST_SHA256=${2:?frozen initialization manifest SHA256 required}
EPISODE_INDEX=${SLURM_ARRAY_TASK_ID:-${3:?episode index required outside an array}}
RELEASE_REPO=${CAMPAIGN_RELEASE_REPO:?absolute isolated release checkout required}
RELEASE_SHA256=${CAMPAIGN_RELEASE_SHA256:?frozen initial_phase_release.json SHA256 required}
if [[ ! "$CAMPAIGN_NAME" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || \
   [[ ! "$MANIFEST_SHA256" =~ ^[0-9a-f]{64}$ ]] || \
   [[ ! "$RELEASE_SHA256" =~ ^[0-9a-f]{64}$ ]] || \
   [[ ! "$EPISODE_INDEX" =~ ^[0-9]+$ ]] || (( EPISODE_INDEX > 29 )); then
    echo 'Invalid campaign name, frozen hash or episode index.' >&2
    exit 2
fi
if [[ "$RELEASE_REPO" != /* ]] || [[ ! -d "$RELEASE_REPO" ]]; then
    echo 'CAMPAIGN_RELEASE_REPO must name an existing absolute isolated checkout.' >&2
    exit 2
fi
# The second bind overrides only source code. Outputs stay in the writable run
# root. No array or concurrency is hardcoded: the primary assigns disjoint IDs.
singularity exec --userns --cleanenv \
    --env "SLURM_JOB_ID=${SLURM_JOB_ID:-}" \
    --env "SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID:-}" \
    --env "SLURM_JOB_NODELIST=${SLURM_JOB_NODELIST:-}" \
    --bind "$RUN_ROOT:/workspace" --bind "$RELEASE_REPO:/workspace/repo:ro" \
    "$RUN_ROOT/runtime/mdolab-sandbox" \
    bash /workspace/repo/rebuttal/adjoint/campaign_v1/initial_grade_entry.sh \
    --out-root "/workspace/adjoint/$CAMPAIGN_NAME" \
    --manifest /workspace/repo/rebuttal/adjoint/campaign_v1/initialization_manifest.json \
    --manifest-sha256 "$MANIFEST_SHA256" --release-sha256 "$RELEASE_SHA256" \
    --episode-index "$EPISODE_INDEX"

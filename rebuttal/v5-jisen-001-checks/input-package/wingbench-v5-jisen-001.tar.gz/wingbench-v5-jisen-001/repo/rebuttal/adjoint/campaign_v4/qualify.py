"""Approval-gated numerical check at the restored benchmark CFD threshold.

Uses fixed roster index 3 (interior geometry), not an adjoint-screened choice.
Failures stop this qualification and do not select a different reference. Its
calls/costs are separate from optimization and never become search feedback.
"""
import argparse
import json
from pathlib import Path
import sys
import time
import numpy as np
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v4.common import HERE,sha,write,now,verify_release,require_approval,runtime_binding


def planned_directions():
    twist=np.zeros(39);twist[13]=1
    airfoil=np.zeros(39);airfoil[17]=1
    mixed=np.random.default_rng(790107).normal(size=39);mixed/=np.linalg.norm(mixed)
    return {k:np.r_[v[:38],[v[38]]*3] for k,v in [('twist',twist),('airfoil',airfoil),('mixed',mixed)]}


def compare(gradient,direction,plus,minus,step):
    predicted=np.einsum('mfi,i->mf',gradient,direction)
    measured=(np.asarray(plus)-np.asarray(minus))/(2*step)
    allowed=.02*np.maximum(abs(predicted),abs(measured))+np.array([2e-5,2e-6])
    passed=np.isfinite(predicted)&np.isfinite(measured)&(abs(predicted-measured)<=allowed)
    return dict(predicted=predicted.tolist(),measured=measured.tolist(),allowed=allowed.tolist(),
        passed=passed.tolist(),all_passed=bool(passed.all()))


def main(args):
    release=verify_release(HERE/'release.json',args.release_sha256)
    require_approval(args.approval,args.release_sha256,3)
    from rebuttal.adjoint.campaign_v4.run import validate_initial,optimizer_runtime
    from rebuttal.adjoint.campaign_v1.run_initial_grade import preflight_runtime
    from rebuttal.adjoint.campaign_v4.optimizer_smoke import run as smoke
    from rebuttal.adjoint.campaign_v4.executor import Executor
    from benchmark.common import load_box
    initial=validate_initial(args.initial,args.release_sha256)
    if initial['episode_index']!=3:raise ValueError('Qualification reference fixed to roster index 3')
    scientific,_=preflight_runtime(release['runtime_expected_sha256'])
    opt_runtime=optimizer_runtime()
    runtime=runtime_binding(scientific,opt_runtime)
    if any(v!='1' for v in runtime['optimizer']['thread_environment'].values()):
        raise ValueError('Single-threaded runtime required')
    x0=np.r_[np.zeros(38),initial['alphas']];box=load_box()
    for direction in planned_directions().values():
        for sign in (-1,1):
            y=x0+sign*.002*direction
            if not box.contains(np.asarray(initial['geometry'])+np.asarray(box.sd)*y[:38]) or np.any(y[38:] < -10) or np.any(y[38:] > 25):
                raise ValueError('Predeclared finite-difference points exceed bounds; do not shrink or replace silently')
    args.out.mkdir(parents=True,exist_ok=False)
    write(args.out/'runtime.json',dict(scientific=scientific,optimizer=opt_runtime),exclusive=True)
    # Must pass real pinned optimizer behavior with zero CFD first.
    smoke_result=smoke(args.out/'optimizer-smoke')
    executor=Executor(args.initial,args.out/'workers');events=[];checks=[];sequence=0
    def call(op,x,label):
        nonlocal sequence
        reservation=dict(sequence=sequence,request=dict(op=op,x=x.tolist()),
            label=label,started_at=now(),phase='numerical_qualification',search_attempts_consumed=0)
        path=args.out/('reservation-%03d.json'%sequence)
        write(path,reservation,exclusive=True)
        began=time.monotonic();r=executor(op,x,reservation)
        events.append(dict(reservation=reservation,response=r,controller_wall_seconds=time.monotonic()-began))
        write(args.out/'events.json',events);sequence+=1
        if r['status']!='ok':raise RuntimeError('Qualification callback failed: '+str(r.get('error')))
        result=np.asarray(r['value'],dtype=float)
        expected=(3,2) if op=='forward' else (3,2,41)
        if result.shape!=expected or not np.isfinite(result).all():raise ValueError('Invalid qualification response')
        if op=='forward' and np.any(result<=0):raise ValueError('Nonpositive qualification CL/CD')
        return result
    passed=False;error=None
    try:
        v=call('forward',x0,'anchor')
        relative=abs(v-np.asarray(initial['reference_cl_cd']))/abs(np.asarray(initial['reference_cl_cd']))
        write(args.out/'reference_reproduction.json',dict(relative_errors=relative.tolist(),limit=.005))
        if np.any(relative>.005):raise ValueError('Native reference differs from original grade by over 0.5%')
        gradient=call('gradient',x0,'anchor-adjoint')
        for name,direction in planned_directions().items():
            for step in (.002,.001):
                plus=call('forward',x0+step*direction,f'{name}-{step}-plus')
                minus=call('forward',x0-step*direction,f'{name}-{step}-minus')
                check=compare(gradient,direction,plus,minus,step)
                checks.append(dict(direction=name,step=step,**check))
                write(args.out/'checks.json',checks)
                if not check['all_passed']:raise ValueError('Directional derivative check failed; no pilot release')
        passed=len(checks)==6 and all(c['all_passed'] for c in checks)
    except Exception as exc:error=dict(type=type(exc).__name__,message=str(exc))
    finally:executor.close()
    evidence=dict(passed=passed,error=error,checks=checks,events=events,
        runtime=runtime,initial_sha256=sha(args.initial),optimizer_smoke=smoke_result,
        search_feedback=False,search_attempts_consumed=0)
    write(args.out/'evidence.json',evidence,exclusive=True)
    certificate=dict(passed=passed,release_sha256=args.release_sha256,runtime=runtime,
        forward_gate=1e-10,adjoint_gate=1.1e-9,scalar_checks=6*len(checks),
        optimizer_smoke_passed=smoke_result['passed'],evidence_file='evidence.json',
        evidence_sha256=sha(args.out/'evidence.json'),finished_at=now(),error=error)
    write(args.out/'certificate.json',certificate,exclusive=True)
    print(json.dumps(certificate,indent=2));return 0 if passed else 3

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--initial',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--release-sha256',required=True)
    p.add_argument('--approval',type=Path,required=True);sys.exit(main(p.parse_args()))

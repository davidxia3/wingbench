"""Bind the actual benchmark-generated trim inputs to a fresh initialization."""
import json
from pathlib import Path
from rebuttal.adjoint.campaign_v5.common import sha


def checked_path(root, record):
    root = Path(root).resolve()
    relative = Path(record['relative_path'])
    path = (root / relative).resolve()
    if relative.is_absolute() or '..' in relative.parts or root not in path.parents:
        raise ValueError('Trim artifact escapes initialization')
    if not path.is_file() or sha(path) != record['sha256']:
        raise ValueError('Trim artifact missing or changed')
    return path


def capture(raw, root):
    from rebuttal.adjoint.campaign_v1.run_initial_grade import artifact
    def pin(record):
        result = artifact(record['path'], root)
        if result['sha256'] != record['sha256']:
            raise ValueError('Original trim artifact changed before binding')
        return result
    conditions = []
    for condition in sorted(raw['conditions'], key=lambda c: float(c['mach'])):
        attempt = condition['attempts'][-1]
        if attempt['outcome_class'] != 'valid':
            raise ValueError('Cannot bind an invalid initial trim')
        conditions.append(dict(mach=float(condition['mach']),
            conditions=pin(attempt['artifacts']['conditions']),
            solver_script=pin(attempt['artifacts']['solver_script']),
            reference_cl_cd=[float(condition['measurements'][k]) for k in ('cl','cd')]))
    return dict(input=pin(raw['mesh']['input_after_mesh_artifact']), conditions=conditions)


def validate(initial, root):
    trim = initial['benchmark_trim']
    checked_path(root, initial['mesh'])
    checked_path(root, trim['input'])
    if len(trim['conditions']) != 3:
        raise ValueError('Exactly three benchmark trim conditions required')
    for index, row in enumerate(trim['conditions']):
        checked_path(root, row['solver_script'])
        conds = json.loads(checked_path(root, row['conditions']).read_text())
        if (row['mach'] != initial['mach'][index] or conds['M3'] != row['mach']
            or conds['CL_targ'] != initial['target_cl']):
            raise ValueError('Trim condition identity differs from initialization')
    return trim

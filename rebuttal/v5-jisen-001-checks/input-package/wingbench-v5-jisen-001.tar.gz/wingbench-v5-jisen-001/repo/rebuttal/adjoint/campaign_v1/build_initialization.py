#!/usr/bin/env python3
"""Freeze deterministic campaign starts using only the permitted prior context.

No CFD, optimization, qualification, or remote work is performed by this file.
Existing manifests are never overwritten. --check rebuilds and compares them.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from benchmark.common import geometry_sha256, load_box, load_tasks
from wingbench.protocol_context import build_initial_context, canonical_sha256

PROTOCOL_PATH = "rebuttal/compute/jisen_verify_v1/numerical_protocol.json"
PROTOCOL_SHA = "5c3e4a18e5ee19b251ffcfbd35ebf8e43806c262ee738316fc5d02ccf191ab8e"
CONTEXT_SHA = "094ac003418da96aa92696096ac79b2134b4ef13e85ab83cd3853c1768ab8d77"
SOURCES = [
    PROTOCOL_PATH,
    "configs/benchmark/undefended_50_wing_corpus_v1.json",
    "configs/benchmark/corpus50_gate_validation_batch1_candidates_v1.json",
    "configs/benchmark/corpus50_gate_validation_batch2_candidates_v1.json",
    "configs/benchmark/corpus50_gate_matched_validation_results_v1.json",
    "wingbench/protocol_context.py",
    "benchmark/common.py",
    "benchmark/optimizer_api.py",
    "scripts/cfd/geometry_hash.py",
    "scripts/cfd/task_protocols.py",
    "agents/tasks/task_documents.json",
    "configs/cfd/final_protocol_candidate_v2.json",
    "rebuttal/adjoint/campaign_v1/build_initialization.py",
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build():
    protocol = json.loads((ROOT / PROTOCOL_PATH).read_text())
    if sha(ROOT / PROTOCOL_PATH) != PROTOCOL_SHA:
        raise ValueError("Frozen numerical protocol changed")
    contract = protocol["campaign_numerical_contract"]
    seeds, task_names = contract["seed_order"], contract["task_order"]
    if seeds != list(range(1, 11)) or task_names != ["low", "nominal", "high"]:
        raise ValueError("Unexpected frozen seed/task order")
    context = build_initial_context()
    if canonical_sha256(context) != CONTEXT_SHA:
        raise ValueError("Permitted initial context changed")
    if len(context["corpus50_rows"]) != 50 or len(context["matched_validation_ungated"]) != 12:
        raise ValueError("Expected exactly 62 prior records")
    pool = {}
    eligible_records = 0
    box = load_box()

    def include(geometry, claimed_hash, eligible, source_record):
        nonlocal eligible_records
        key = geometry_sha256(geometry)
        if key != claimed_hash:
            raise ValueError("Prior geometry hash mismatch: " + source_record)
        if eligible is not True:
            return
        eligible_records += 1
        if not box.contains(geometry):
            raise ValueError("Eligible prior geometry is outside frozen bounds")
        row = pool.setdefault(key, {"geometry_sha256": key,
                                   "geometry": list(geometry), "source_records": []})
        if row["geometry"] != list(geometry):
            raise ValueError("Distinct geometries share a canonical hash")
        row["source_records"].append(source_record)

    for row in context["corpus50_rows"]:
        include(row["geometry_38d"], row["geometry_sha256"], row["score_eligible"],
                "corpus50:" + row["wing_id"])
    for row in context["matched_validation_ungated"]:
        candidate, result = row["candidate"], row["result"]
        if candidate["geometry_sha256"] != result["geometry_sha256"]:
            raise ValueError("Matched candidate/result geometry differs")
        include(candidate["geometry_38d"], candidate["geometry_sha256"],
                result["score_eligible"], "matched:" + candidate["candidate_id"])
    if eligible_records != 29 or len(pool) != 29:
        raise ValueError("Frozen eligible pool count changed")
    tasks = load_tasks()
    chosen = {}
    for seed in seeds:
        order = lambda key: hashlib.sha256(
            ("wingbench-adjoint-v1|" + str(seed) + "|" + key).encode("utf-8")
        ).hexdigest()
        chosen[seed] = min(pool, key=order)
    episodes = []
    for seed in seeds:
        selected = pool[chosen[seed]]
        duplicate_seeds = [s for s in seeds if chosen[s] == chosen[seed]]
        for name in task_names:
            task = tasks[name]
            if task.target_cl != protocol["method"]["task_target_CL"][name]:
                raise ValueError("Frozen target differs from original task")
            if list(task.mach) != protocol["method"]["mach"]:
                raise ValueError("Frozen Mach grid differs from original task")
            episodes.append({
                "episode_index": len(episodes),
                "episode_id": "adjoint-v1-s%02d-%s" % (seed, name),
                "seed": seed, "task": name, "task_id": task.task_id,
                "target_cl": task.target_cl, "aoa_seed_deg": task.aoa_seed_deg,
                "mach": list(task.mach), "geometry": selected["geometry"],
                "geometry_sha256": selected["geometry_sha256"],
                "source_records": sorted(selected["source_records"]),
                "max_attempts": 32, "initial_grade_attempt": 1,
                "remaining_joint_trial_attempts": 31,
                "duplicate_start_seed_indices": duplicate_seeds,
                "checkpoint_0_nomination_geometry_sha256": selected["geometry_sha256"],
            })
    return {
        "schema": "wingbench-adjoint-campaign-initialization-v1",
        "numerical_protocol_sha256": PROTOCOL_SHA,
        "initial_context_canonical_sha256": CONTEXT_SHA,
        "source_sha256": {path: sha(ROOT / path) for path in SOURCES},
        "initialization_policy": contract["initial_geometry_policy"],
        "eligibility": "Prior score_eligible is exactly true; deduplicate canonical geometry SHA256 before deterministic selection. No score ranking or released episode results.",
        "prior_records": 62, "eligible_prior_records": eligible_records,
        "eligible_unique_geometries": len(pool),
        "eligible_pool": [dict(pool[key], source_records=sorted(pool[key]["source_records"]))
                          for key in sorted(pool)],
        "seed_order": seeds, "task_order": task_names,
        "episode_count": len(episodes),
        "unique_start_geometries": len(set(chosen.values())),
        "unique_task_start_combinations": len(set(chosen.values())) * len(task_names),
        "duplicate_seed_groups": [[9, 10]],
        "duplicate_policy": "Keep all 30 predeclared episode IDs and fresh counted grades. Report deterministic repeated starts; also report 27-unique-task-start sensitivity. No resampling or cross-episode reuse.",
        "initial_grade_policy": contract["failed_initial_grade"],
        "optimization_release": "This manifest grants no numerical qualification or optimization release. Initial grades alone do not complete an optimization episode.",
        "episodes": episodes,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().with_name("initialization_manifest.json"))
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    expected = build()
    if args.check:
        actual = json.loads(args.output.read_text())
        if actual != expected:
            raise SystemExit("Manifest differs from fresh deterministic reconstruction")
    else:
        with args.output.open("x") as stream:
            json.dump(expected, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write("\n")
    print(json.dumps({"manifest": str(args.output), "sha256": sha(args.output),
                      "episodes": len(expected["episodes"]), "unique_task_starts": 27,
                      "checked": args.check}, sort_keys=True))


if __name__ == "__main__":
    main()

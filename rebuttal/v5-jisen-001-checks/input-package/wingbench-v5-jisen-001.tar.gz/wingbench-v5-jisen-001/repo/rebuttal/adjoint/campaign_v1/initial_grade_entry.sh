#!/bin/bash
# Portable entry inside the pinned MDO container. The grader parent must not
# receive forced OMP/BLAS/ADFLOW overrides; its frozen protocol sets child env.
set -euo pipefail
if [[ "$(id -u)" == 0 ]]; then
    echo 'The original grader requires a non-root container user.' >&2
    exit 2
fi
exec /bin/bash /workspace/repo/rebuttal/container_entry.sh \
    python3 /workspace/repo/rebuttal/adjoint/campaign_v1/run_initial_grade.py "$@"

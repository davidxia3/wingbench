"""Constrained adjoint search with charged failures and exact oracle replay.

Replay reconstructs only deterministic optimizer bookkeeping. It must consume
the exact recorded oracle request sequence before any new expensive work. A
scientific callback failure is replayed as a failure, not as a fabricated value.
"""
import json
import math
from pathlib import Path
import signal
import time
import numpy as np
from rebuttal.adjoint.campaign_v5.common import write, now

class StopSearch(Exception): pass
class PauseSearch(StopSearch): pass
class BudgetReached(StopSearch): pass
class GradientFailure(StopSearch): pass
class InfrastructureFailure(StopSearch): pass
class ReplayMismatch(StopSearch): pass
class ForwardFailure(Exception): pass

def same(a,b):
    return np.array_equal(np.asarray(a,dtype=float),np.asarray(b,dtype=float))

class Transcript:
    def __init__(self,out,x0,stage_limit,executor,binding):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True)
        self.path=self.out/'transcript.json';self.pending=self.out/'pending.json'
        self.binding=binding;self.x0=np.asarray(x0,dtype=float);self.limit=stage_limit
        if stage_limit!=8:raise ValueError('This release permits exactly an eight-attempt cap')
        self.events=json.loads(self.path.read_text()) if self.path.exists() else []
        binding_path=self.out/'binding.json'
        if binding_path.exists():
            if json.loads(binding_path.read_text())!=binding:raise ReplayMismatch('Frozen runtime/source binding changed')
        else:write(binding_path,binding,exclusive=True)
        if self.pending.exists():
            pending=json.loads(self.pending.read_text())
            if len(self.events)>pending['sequence'] and self.events[pending['sequence']]['request']==pending['request']:
                self.pending.unlink() # committed response survived; no work repeated
            else:raise InfrastructureFailure('Unresolved reservation; evidence-based recovery required')
        self.replay_length=len(self.events);self.cursor=0;self.attempts=0
        self.free_used=False;self.executor=executor;self.new_work=0

    def call(self,op,x):
        x=np.asarray(x,dtype=float)
        if op not in ('forward','gradient') or x.shape!=(41,) or not np.isfinite(x).all():
            raise InfrastructureFailure('Invalid callback request')
        request={'op':op,'x':x.tolist()}
        free=(op=='forward' and not self.free_used and same(x,self.x0))
        counted=(op=='forward' and not free)
        if self.cursor<self.replay_length:
            event=self.events[self.cursor]
            if event['request']!=request or event['free_initial']!=free:
                raise ReplayMismatch('Oracle request differs at replay index %d'%self.cursor)
        else:
            if counted and self.attempts>=8:raise BudgetReached('Eight search attempts consumed')
            if counted and self.attempts>=self.limit:raise PauseSearch('Pilot allowance reached before next trial')
            reservation=dict(sequence=len(self.events),request=request,free_initial=free,
                search_attempt=self.attempts+int(counted),reserved_at=now())
            write(self.pending,reservation,exclusive=True)
            began=time.monotonic()
            response=self.executor(op,x,reservation)
            if not isinstance(response,dict) or response.get('status') not in ('ok','scientific_failure','infrastructure_failure'):
                raise InfrastructureFailure('Malformed worker response; reservation retained')
            event=dict(reservation,response=response,controller_elapsed_seconds=time.monotonic()-began)
            self.events.append(event);write(self.path,self.events);self.pending.unlink();self.new_work+=1
        self.cursor+=1;self.attempts+=int(counted);self.free_used|=free
        response=event['response']
        if response['status']=='infrastructure_failure':raise InfrastructureFailure(response.get('error','Worker failure'))
        if response['status']=='scientific_failure':
            if op=='forward':raise ForwardFailure(response.get('error','Failed CFD'))
            raise GradientFailure(response.get('error','Failed adjoint'))
        return np.asarray(response['value'],dtype=float)

def aggregate(v,g,target):
    v=np.asarray(v,dtype=float)
    if v.shape!=(3,2) or not np.isfinite(v).all() or np.any(v<=0):raise ForwardFailure('Nonpositive or invalid CL/CD')
    if g is None:return float(-np.mean(np.log(v[:,0]/v[:,1]))),v[:,0]-target
    g=np.asarray(g,dtype=float)
    if g.shape!=(3,2,41) or not np.isfinite(g).all():raise GradientFailure('Invalid full gradient')
    return -np.mean(g[:,0]/v[:,0,None]-g[:,1]/v[:,1,None],axis=0),g[:,0]

class Bridge:
    def __init__(self,transcript,initial,sd,evaluation_error):
        self.t=transcript;self.initial=initial;self.sd=np.asarray(sd);self.EvaluationError=evaluation_error
        self.cache={};self.stopped=None;self.target=float(initial['target_cl'])
        self.best={'geometry':initial['geometry'],'score':float(initial['initial_score']),
            'source':'starting_wing','search_attempt':0}
        self.nominations={};self.start=time.monotonic();self.arm()

    def arm(self):
        signal.setitimer(signal.ITIMER_REAL,600)
    def expensive(self,op,x):
        signal.setitimer(signal.ITIMER_REAL,0)
        try:return self.t.call(op,x)
        finally:self.arm()
    def stop(self,exc):
        self.stopped=exc
        raise self.EvaluationError(str(exc))

    def values(self,x):
        if self.stopped:raise self.EvaluationError(str(self.stopped))
        if 'x' not in self.cache or not same(x,self.cache['x']):
            self.cache={'x':np.array(x,dtype=float)}
            try:
                v=self.expensive('forward',x)
                obj,c=aggregate(v,None,self.target)
                if self.t.attempts==0 and same(x,self.t.x0) and 'reference_cl_cd' in self.initial:
                    reference=np.asarray(self.initial['reference_cl_cd'],dtype=float)
                    if reference.shape!=(3,2) or np.any(np.abs(v-reference)/np.abs(reference)>.005):
                        raise StopSearch('Native starting-point reproduction differs from original grade by over 0.5%')
                self.cache.update(values=v,objective=obj,constraints=c)
                ratios=v[:,0]/v[:,1];score=float(np.exp(-obj))
                eligible=np.max(np.abs(c))<=.001 and np.all(ratios<=40)
                if eligible and self.t.attempts==0 and same(x,self.t.x0):
                    self.best['score']=score # native comparator; still the same starting geometry
                if eligible and score>self.best['score']:
                    geometry=(np.asarray(self.initial['geometry'])+self.sd*np.asarray(x)[:38]).tolist()
                    source='starting_wing' if same(geometry,self.initial['geometry']) else 'search'
                    self.best={'geometry':geometry,'score':score,'source':source,
                        'search_attempt':self.t.attempts}
            except ForwardFailure as exc:
                self.cache['failed']=str(exc)
            except StopSearch as exc:self.stop(exc)
            # Snapshot before the optimizer sees any private recommendation grade.
            if self.t.attempts in (0,1,2,4,8):
                self.nominations[str(self.t.attempts)]=dict(self.best)
                write(self.t.out/'nominations.json',dict(nominations=self.nominations,
                    private_feedback=False,search_attempts=self.t.attempts))
        if 'failed' in self.cache:raise self.EvaluationError(self.cache['failed'])
        return self.cache['values']

    def objective(self,x):
        self.values(x);return self.cache['objective']
    def constraints(self,x):
        self.values(x);return self.cache['constraints']
    def derivatives(self,x):
        self.values(x)
        if 'g' not in self.cache:
            try:
                g=self.expensive('gradient',x)
                self.cache['g']=aggregate(self.cache['values'],g,self.target)
            except StopSearch as exc:self.stop(exc)
        return self.cache['g']
    def gradient(self,x):return self.derivatives(x)[0]
    def jacobian(self,x):return self.derivatives(x)[1].ravel()
    def intermediate(self,*args):return self.stopped is None

def optimize(out,initial,box,executor,binding,stage_limit,cyipopt):
    x0=np.r_[np.zeros(38),initial['alphas']]
    z0=np.asarray(box.to_standardized(initial['geometry']))
    lb=np.r_[-3.5-z0,[-10.]*3];ub=np.r_[3.5-z0,[25.]*3]
    t=Transcript(out,x0,stage_limit,executor,binding)
    previous_handler=signal.getsignal(signal.SIGALRM)
    def stalled(*unused):raise StopSearch('Optimizer bookkeeping exceeded ten minutes')
    signal.signal(signal.SIGALRM,stalled)
    bridge=Bridge(t,initial,box.sd,cyipopt.CyIpoptEvaluationError)
    p=None
    options=dict(linear_solver='mumps',hessian_approximation='limited-memory',
        tol=1e-6,constr_viol_tol=1e-6,acceptable_iter=0,max_iter=3000,
        bound_relax_factor=0.,honor_original_bounds='yes',bound_push=1e-10,bound_frac=1e-10,print_level=5,
        output_file=str(Path(out)/('ipopt-stage-%02d.log'%stage_limit)))
    status=None
    try:
        # Verify the exact free anchor before IPOPT's bound-push can change x0.
        try:bridge.values(x0)
        except cyipopt.CyIpoptEvaluationError:
            if bridge.stopped:raise bridge.stopped
            raise StopSearch('Native initial CFD failed; no search started: '+bridge.cache.get('failed','unknown'))
        p=cyipopt.Problem(n=41,m=3,problem_obj=bridge,lb=lb,ub=ub,cl=np.zeros(3),cu=np.zeros(3))
        for k,v in options.items():p.add_option(k,v)
        _,info=p.solve(x0)
        if bridge.stopped:raise bridge.stopped
        if t.cursor!=t.replay_length and t.cursor<t.replay_length:raise ReplayMismatch('Optimizer stopped before replay completed')
        code=int(info['status'])
        status=dict(phase='optimizer_converged' if code in (0,1) else 'optimizer_terminated',optimizer_status=code,
            message=info['status_msg'].decode() if isinstance(info['status_msg'],bytes) else str(info['status_msg']))
    except PauseSearch as exc:status=dict(phase='pilot_paused',message=str(exc))
    except BudgetReached as exc:status=dict(phase='budget_complete',message=str(exc))
    except GradientFailure as exc:status=dict(phase='adjoint_failure',message=str(exc))
    except (InfrastructureFailure,ReplayMismatch) as exc:status=dict(phase='blocked',message=str(exc))
    except StopSearch as exc:status=dict(phase='stopped',message=str(exc))
    except Exception as exc:
        status=dict(phase='blocked',message=str(exc),exception_type=type(exc).__name__,automatic_retry=False)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous_handler)
        if p is not None:
            try:p.close()
            except Exception as exc:status=dict(phase='blocked',message='Optimizer cleanup failed: '+str(exc))
    pending=json.loads(t.pending.read_text()) if t.pending.exists() else None
    status.update(search_attempts=t.attempts,recorded_oracle_calls=len(t.events),
        pending_reservation=pending,search_attempts_reserved=max(t.attempts,pending['search_attempt'] if pending else 0),
        replayed_oracle_calls=min(t.cursor,t.replay_length),new_oracle_calls=t.new_work,
        nomination=bridge.best,starting_wing_returned=bridge.best['source']=='starting_wing',
        original_grader_validation_pending=True,stage_limit=stage_limit,finished_at=now())
    write(Path(out)/('stage-%02d.json'%stage_limit),status)
    return status

#!/usr/bin/env python3
"""Audit all documented online successes and freeze a score-independent draw.

Writes only v4 eligibility and roster files, refusing changes to an existing
selection. Does not launch compute or claim fresh numerical qualification.
"""
import csv
import hashlib
import json
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from benchmark.common import geometry_sha256, load_box, load_tasks

OUT = Path(__file__).resolve().parent
FILES = ['data/evaluations.csv', 'data/episodes.csv', 'data/wings.csv',
         'data/cfd_conditions.csv', 'benchmark/common.py',
         'scripts/cfd/geometry_hash.py', 'agents/tasks/task_documents.json']



def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    with (ROOT / 'data' / (name + '.csv')).open(newline='') as stream:
        return list(csv.DictReader(stream))


def require(ok, why):
    if not ok:
        raise ValueError(why)


def main():
    sources = {name: digest(ROOT / name) for name in FILES}
    evaluations = read('evaluations')
    episodes = {r['episode']: r for r in read('episodes')}
    wings = {r['wing']: r for r in read('wings')}
    conditions = defaultdict(list)
    for row in read('cfd_conditions'):
        conditions[row['evaluation']].append(row)
    box, tasks = load_box(), load_tasks()
    pool = {task: {} for task in tasks}
    excluded = []
    inspected = 0
    for e in evaluations:
        if not (e['kind'] == 'online' and e['delivered'] == 'True'):
            continue
        inspected += 1
        try:
            ep = episodes[e['episode']]
            require(all(ep[k] == e[k] for k in ['study', 'method', 'task', 'seed']), 'episode metadata mismatch')
            task = tasks[e['task']]
            require(float(ep['target_cl']) == task.target_cl, 'episode lift mismatch')
            require(bool(e['wing']) and e['wing'] in wings, 'missing geometry record')
            wing = wings[e['wing']]
            geometry = [float(wing[f'x{i:02d}']) for i in range(38)]
            require(geometry_sha256(geometry) == e['wing'], 'geometry fingerprint mismatch')
            require(box.contains(geometry), 'geometry outside design bounds')
            cc = sorted(conditions[e['evaluation']], key=lambda c: c['condition'])
            require(len(cc) == 3, 'missing three-condition evidence')
            require({c['condition'] for c in cc} == {'mach_q1', 'mach_q2', 'mach_q3'}, 'condition IDs mismatch')
            for i, c in enumerate(cc):
                require(all(c[k] == e[k] for k in ['episode', 'study', 'method', 'task']), 'condition metadata mismatch')
                require(c['outcome'] == 'valid' and c['mesh_outcome'] in ['valid', 'marginal'], 'condition or mesh not accepted')
                require(float(c['mach']) == task.mach[i] and float(c['cl_target']) == task.target_cl, 'condition target mismatch')
                fields = ['cl', 'cd', 'ld', 'err_cl', 'realized_aoa_deg', 'solvecl_l2convergence']
                require(all(c[k] != '' for k in fields), 'missing required numerical evidence')
                cl, cd, ld, err, alpha, residual = [float(c[k]) for k in fields]
                require(all(math.isfinite(v) for v in [cl, cd, ld, err, alpha, residual]), 'nonfinite numerical evidence')
                require(cl > 0 and cd > 0 and 0 < ld <= 40 and abs(cl-task.target_cl) <= .02
                        and 0 <= err < .0005 and -10 <= alpha <= 25 and residual <= 1e-10,
                        'numerical acceptance check failed')
                require(math.isclose(ld, cl/cd, rel_tol=1e-10), 'condition score inconsistency')
            score = math.exp(sum(math.log(float(c['ld'])) for c in cc)/3)
            require(math.isclose(score, float(e['ld']), rel_tol=1e-10), 'aggregate score inconsistency')
            row = pool[e['task']].setdefault(e['wing'], {
                'geometry_sha256': e['wing'], 'geometry': geometry,
                'task': e['task'], 'target_cl': task.target_cl,
                'proofs': [],
            })
            row['proofs'].append({'evaluation': e, 'conditions': cc})
        except (ValueError, KeyError) as err:
            excluded.append({'evaluation': e['evaluation'], 'task': e['task'], 'reason': str(err)})
    require(sources == {name: digest(ROOT / name) for name in FILES}, 'Source changed during audit')
    # Seed committed in protocol before seeing the draw. Dedup within each task;
    # source frequency and score do not affect selection probability.
    seed = 20261109
    selected = {}
    for task, rows in pool.items():
        selected[task] = sorted(rows, key=lambda h: hashlib.sha256(
            f'wingbench-v4|{seed}|{task}|{h}'.encode()).digest())[:2]
        require(len(selected[task]) == 2, 'Insufficient eligible wings')
    result = []
    for round_index in range(2):
        for task in ('low','nominal','high'):
            h = selected[task][round_index]; wing = pool[task][h]
            proof = sorted(wing['proofs'],key=lambda p:p['evaluation']['evaluation'])[0]
            result.append(dict(episode_index=len(result),
                episode_id=f'adjoint-v4-s{round_index+1:02d}-{task}',
                task=task,target_cl=tasks[task].target_cl,mach=list(tasks[task].mach),
                geometry=wing['geometry'],geometry_sha256=h,
                historical_proof=proof, historical_ld=float(proof['evaluation']['ld'])))
    roster = dict(schema='wingbench-v4-random-roster',seed=seed,
        sampling='Hash permutation of deduplicated geometries per task; no score ranking',
        source_sha256=sources,episodes=result)
    summary = dict(eligible_unique_wings_by_task={t:len(v) for t,v in pool.items()},
        inspected_delivered_online_evaluations=inspected,
        excluded_by_reason=dict(Counter(e['reason'] for e in excluded)),
        exclusions=excluded,all_methods_included=True,private_grades_excluded=True,
        eligible_geometry_hashes={t:sorted(v) for t,v in pool.items()})
    for name,data in [('roster.json',roster),('eligibility.json',summary)]:
        text=json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+'\n'
        path=OUT/name
        if path.exists() and path.read_text()!=text:
            raise ValueError('Refusing to replace an existing draw or evidence inventory')
        if not path.exists():path.write_text(text)
    print(json.dumps(dict(counts=summary['eligible_unique_wings_by_task'],
        excluded=summary['excluded_by_reason'],selected=[dict(index=e['episode_index'],task=e['task'],
        hash=e['geometry_sha256'],historical_ld=e['historical_ld']) for e in result]),indent=2))

if __name__ == '__main__':main()

"""Read-only resource and scratch checks adapted from the prior Jisen verifier."""
import os
import sys
import socket
import platform
import shutil
import tempfile
import subprocess
import fcntl
from pathlib import Path

def read_text(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def cgroup_resources():
    """Read this process's v1/v2 leaf and visible ancestor limits, if exposed."""
    paths = []
    membership = read_text('/proc/self/cgroup') or ''
    for row in membership.splitlines():
        _, controllers, location = row.split(':', 2)
        if not controllers:
            paths.extend([Path('/sys/fs/cgroup') / location.lstrip('/'), Path('/sys/fs/cgroup')])
        for controller in controllers.split(','):
            if controller in ('cpu', 'cpuacct', 'memory', 'cpuset'):
                paths.extend([Path('/sys/fs/cgroup') / controller / location.lstrip('/'),
                              Path('/sys/fs/cgroup') / controller])
    paths.extend([Path('/sys/fs/cgroup'), Path('/sys/fs/cgroup/cpu'),
                  Path('/sys/fs/cgroup/cpu,cpuacct'), Path('/sys/fs/cgroup/memory')])
    expanded = set()
    for path in paths:
        if '..' in path.parts:
            continue
        while str(path).startswith('/sys/fs/cgroup'):
            expanded.add(path)
            if path == Path('/sys/fs/cgroup'):
                break
            path = path.parent
    records, cpu_limits, memory_limits = [], [], []
    for path in sorted(expanded):
        cpu_max = read_text(path / 'cpu.max')
        quota = read_text(path / 'cpu.cfs_quota_us')
        period = read_text(path / 'cpu.cfs_period_us')
        mem = read_text(path / 'memory.max') or read_text(path / 'memory.limit_in_bytes')
        cpuset = read_text(path / 'cpuset.cpus.effective') or read_text(path / 'cpuset.cpus')
        if not any((cpu_max, quota, period, mem, cpuset)):
            continue
        records.append({'path': str(path), 'cpu.max': cpu_max, 'cpu_quota_us': quota,
                        'cpu_period_us': period, 'memory_limit': mem, 'cpuset': cpuset})
        if cpu_max:
            q, p = cpu_max.split()
            if q != 'max' and int(q) >= 0:
                cpu_limits.append(int(q) / int(p))
        elif quota and period and int(quota) >= 0:
            cpu_limits.append(int(quota) / int(period))
        if mem and mem != 'max' and 0 < int(mem) < (1 << 60):
            memory_limits.append(int(mem))
    return {'records': records, 'cpu_quota_units': min(cpu_limits) if cpu_limits else None,
            'memory_limit_bytes': min(memory_limits) if memory_limits else None}


def hardware_record():
    affinity = sorted(os.sched_getaffinity(0))
    physical = set()
    for cpu in affinity:
        topology = Path('/sys/devices/system/cpu/cpu' + str(cpu)) / 'topology'
        package, core = read_text(topology / 'physical_package_id'), read_text(topology / 'core_id')
        if package is not None and core is not None:
            physical.add((package, core))
    info = read_text('/proc/cpuinfo') or ''
    model = next((line.split(':', 1)[1].strip() for line in info.splitlines()
                  if line.startswith('model name')), None)
    meminfo = read_text('/proc/meminfo') or ''
    memtotal = next((int(line.split()[1]) * 1024 for line in meminfo.splitlines()
                     if line.startswith('MemTotal:')), None)
    return {'hostname': socket.gethostname(), 'machine': platform.machine(),
            'platform': platform.platform(), 'kernel': platform.release(), 'cpu_model': model,
            'affinity_logical_cpus': affinity, 'affinity_physical_core_count': len(physical) or None,
            'host_memory_bytes': memtotal, 'cgroup': cgroup_resources(),
            'physical_core_exclusivity_verified': False,
            'physical_core_note': 'Visible topology and quota do not establish exclusive physical cores; Kubernetes CPU units may be hardware threads.'}


def filesystem_probe(directory):
    """Test rename, exclusive create, flock and MPI visibility separately."""
    directory.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.preflight-', dir=str(directory)) as temp:
        root = Path(temp)
        path = root / 'probe'
        with path.open('x') as stream:
            stream.write('wingbench-preflight\n')
            stream.flush()
            os.fsync(stream.fileno())
        exclusive = False
        try:
            path.open('x').close()
        except FileExistsError:
            exclusive = True
        renamed = root / 'renamed'
        path.rename(renamed)
        content_ok = renamed.read_text() == 'wingbench-preflight\n'
        lock = root / 'lock'
        child_code = ('import fcntl,sys; f=open(sys.argv[1],"a+"); '
                      '\ntry: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)'
                      '\nexcept BlockingIOError: sys.exit(23)'
                      '\nsys.exit(0)')
        with lock.open('a+') as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            blocked = subprocess.run([sys.executable, '-c', child_code, str(lock)],
                                     capture_output=True, text=True, timeout=20)
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        unlocked = subprocess.run([sys.executable, '-c', child_code, str(lock)],
                                  capture_output=True, text=True, timeout=20)
        claim = root / 'claim'
        claim.mkdir()
        mkdir_exclusive = False
        try:
            claim.mkdir()
        except FileExistsError:
            mkdir_exclusive = True
        disk = shutil.disk_usage(directory)
        return {'directory': str(directory), 'device_id': directory.stat().st_dev,
                'exclusive_create': exclusive, 'atomic_rename_readback': content_ok,
                'exclusive_mkdir': mkdir_exclusive,
                'flock_excludes_second_process': blocked.returncode == 23,
                'flock_released': unlocked.returncode == 0,
                'free_bytes': disk.free,
                'passed': all((exclusive, content_ok, mkdir_exclusive,
                               blocked.returncode == 23, unlocked.returncode == 0)),
                'scope': 'Same-pod processes only; cross-node claim visibility must be checked by the batch coordinator.'}


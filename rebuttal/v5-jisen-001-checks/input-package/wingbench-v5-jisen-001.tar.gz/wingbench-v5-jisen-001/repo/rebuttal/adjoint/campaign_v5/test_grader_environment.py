"""Exercise the real controller-to-grader environment handoff, without CFD."""
import os
import sys
import types
import unittest
from unittest.mock import patch
from rebuttal.adjoint.campaign_v5.common import original_grader


class GraderEnvironmentTests(unittest.TestCase):
    def test_grader_controls_threads_and_other_overrides_stay_visible(self):
        parent=dict(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',
                    ADFLOW_USE_ANK='1',KEEP_ME='unchanged')
        observed={}
        def constructor(*args,**kwargs):
            observed.update(os.environ)
            return 'constructed'
        with patch.dict(os.environ,parent,clear=True),patch.dict(sys.modules,
                {'benchmark.grade_local':types.SimpleNamespace(LocalGrader=constructor)}):
            self.assertEqual(original_grader('task','out'),'constructed')
            self.assertEqual(dict(os.environ),parent)
        self.assertEqual(observed,dict(ADFLOW_USE_ANK='1',KEEP_ME='unchanged'))

    def test_constructor_error_restores_optimizer_threads(self):
        parent=dict(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
        def constructor(*args,**kwargs):
            self.assertNotIn('OMP_NUM_THREADS',os.environ)
            raise RuntimeError('original protocol rejected runtime')
        with patch.dict(os.environ,parent,clear=True),patch.dict(sys.modules,
                {'benchmark.grade_local':types.SimpleNamespace(LocalGrader=constructor)}):
            with self.assertRaisesRegex(RuntimeError,'original protocol'):
                original_grader('task','out')
            self.assertEqual(dict(os.environ),parent)

    def test_unexpected_thread_override_is_rejected(self):
        def constructor(*args,**kwargs):
            self.fail('must not hide unexpected overrides')
        parent=dict(OMP_NUM_THREADS='4')
        with patch.dict(os.environ,parent,clear=True),patch.dict(sys.modules,
                {'benchmark.grade_local':types.SimpleNamespace(LocalGrader=constructor)}):
            with self.assertRaisesRegex(ValueError,'Unexpected optimizer thread'):
                original_grader('task','out')
            self.assertEqual(dict(os.environ),parent)

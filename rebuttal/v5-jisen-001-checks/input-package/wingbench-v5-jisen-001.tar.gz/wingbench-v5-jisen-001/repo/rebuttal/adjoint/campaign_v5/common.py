"""Prospective conventional-adjoint campaign; never mutates older campaigns."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def write(path, value, exclusive=False):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n'
    if exclusive:
        with p.open('x') as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
    else:
        t = p.with_suffix(p.suffix + '.tmp')
        with t.open('w') as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
        t.replace(p)

def verify_release(path, expected):
    path = Path(path)
    if sha(path) != expected: raise ValueError('Release hash mismatch')
    d = json.loads(path.read_text())
    for rel, digest in d['source_sha256'].items():
        p = Path(rel)
        if p.is_absolute() or '..' in p.parts or sha(ROOT / p) != digest:
            raise ValueError('Source mismatch: ' + rel)
    return d

def require_approval(path, release_sha256, index=None):
    """Read an external, explicit approval; the draft cannot authorize work."""
    d = json.loads(Path(path).read_text())
    if (d.get('launch_authorized') is not True or
        d.get('release_sha256') != release_sha256 or
        d.get('pilot_indices') != list(range(6)) or
        d.get('search_attempt_limit') != 8 or not d.get('user_approval_reference')):
        raise ValueError('Explicit user approval for this exact six-episode release is required')
    if index is not None and index not in d['pilot_indices']:
        raise ValueError('Episode outside approved scope')
    return d

def require_runtime_check(path, release_sha256, runtime):
    d=json.loads(Path(path).read_text())
    if (d.get('schema')!='wingbench-v5-software-runtime-check' or d.get('passed') is not True or
        d.get('release_sha256')!=release_sha256 or d.get('runtime')!=runtime or
        d.get('scientific_calls')!=0 or d.get('optimizer_smoke_passed') is not True or
        d.get('mpi16_import_smoke_passed') is not True):
        raise ValueError('Matching software/runtime check required; no CFD qualification implied')
    evidence=Path(path).parent/d['evidence_file']
    if not evidence.resolve().is_relative_to(Path(path).parent.resolve()) or sha(evidence)!=d['evidence_sha256']:
        raise ValueError('Runtime-check evidence changed')
    return d


def require_check_approval(path, release_sha256):
    d=json.loads(Path(path).read_text())
    if (d.get('checks_authorized') is not True or d.get('release_sha256')!=release_sha256 or
        d.get('scope')!='software_runtime_only' or not d.get('user_approval_reference')):
        raise ValueError('Explicit software/runtime-check authorization required')
    return d


def runtime_binding(scientific, optimizer):
    # Host/container names and cgroup paths change between otherwise identical
    # fresh episodes. Keep full hardware provenance on disk, bind scientific
    # binaries/versions, optimizer libraries, CPU model and thread settings.
    scientific = dict(scientific)
    hardware = scientific.pop('hardware', {})
    scientific['hardware_class'] = {k:hardware.get(k) for k in ('machine','cpu_model')}
    return dict(scientific=scientific, optimizer=optimizer)


def original_grader(*args, **kwargs):
    """Let the original protocol set its own child environment.

    The optimizer controller pins BLAS/OpenMP to one thread. The original
    grader rejects those parent overrides and supplies its own frozen values.
    Remove only our known controller settings during construction, then restore
    them even if construction fails. Other forbidden overrides remain visible.
    """
    from benchmark.grade_local import LocalGrader
    keys=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')
    saved={key:os.environ[key] for key in keys if key in os.environ}
    if any(value!='1' for value in saved.values()):
        raise ValueError('Unexpected optimizer thread setting before original grader')
    try:
        for key in saved:del os.environ[key]
        return LocalGrader(*args, **kwargs)
    finally:
        os.environ.update(saved)

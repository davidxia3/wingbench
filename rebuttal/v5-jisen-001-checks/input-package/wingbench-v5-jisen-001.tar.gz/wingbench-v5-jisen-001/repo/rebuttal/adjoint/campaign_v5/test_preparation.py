import copy
import json
import unittest
from pathlib import Path
from unittest.mock import patch
from rebuttal.adjoint.campaign_v5.preflight import execution_allocation
from rebuttal.adjoint.campaign_v5.common import runtime_binding
from benchmark.common import geometry_sha256

class PreparationTests(unittest.TestCase):
    def test_starts_preserved_not_rerolled(self):
        p=Path(__file__).resolve().parent
        new=json.loads((p/'roster.json').read_text())['episodes']
        old=json.loads((p.parent/'campaign_v4/roster.json').read_text())['episodes']
        self.assertEqual(len(new),6)
        for a,b in zip(new,old):
            for k in ('geometry','geometry_sha256','task','mach','episode_index'):self.assertEqual(a[k],b[k])
            self.assertEqual(geometry_sha256(a['geometry']),a['geometry_sha256'])
    def test_jisen_allocation_requires_visible_capacity(self):
        hw=dict(affinity_logical_cpus=list(range(16)),affinity_physical_core_count=16,
                host_memory_bytes=512*1024**3,cgroup=dict(cpu_quota_units=16,memory_limit_bytes=384*1024**3))
        with patch('rebuttal.adjoint.campaign_v5.resources.hardware_record',return_value=hw):
            self.assertEqual(execution_allocation('jisen')['ranks'],16)
            with self.assertRaises(ValueError):execution_allocation('aws')
            hw['cgroup']['memory_limit_bytes']=288*1024**3
            with self.assertRaises(ValueError):execution_allocation('jisen')
            hw['cgroup']['memory_limit_bytes']=384*1024**3;hw['cgroup']['cpu_quota_units']=None
            with self.assertRaises(ValueError):execution_allocation('jisen')
    def test_runtime_binding_allows_new_host_but_not_new_binaries(self):
        a=dict(sha256={'solver':'pin'},hardware=dict(hostname='a',machine='x86_64',cpu_model='AMD'))
        b=copy.deepcopy(a);b['hardware']['hostname']='b'
        self.assertEqual(runtime_binding(a,{}),runtime_binding(b,{}))
        b['sha256']['solver']='changed';self.assertNotEqual(runtime_binding(a,{}),runtime_binding(b,{}))
    def test_benchmark_forward_threshold_unchanged(self):
        from scripts.cfd.grading_protocol import _FINAL_SOLVER
        from rebuttal.adjoint.campaign_v5.numerics import FORWARD_GATE
        self.assertEqual(FORWARD_GATE,_FINAL_SOLVER['l2_convergence'])

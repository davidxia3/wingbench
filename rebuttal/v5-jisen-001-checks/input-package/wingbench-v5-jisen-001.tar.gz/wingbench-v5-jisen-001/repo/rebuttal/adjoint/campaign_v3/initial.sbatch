#!/bin/bash
#SBATCH --account=p33116
#SBATCH --partition=normal
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --mem=96G
#SBATCH --time=12:00:00
#SBATCH --no-requeue
#SBATCH --job-name=wb-v3-initial
#SBATCH --output=/scratch/unk4211/wingbench-rebuttal-20261106/v3-initial-%A_%a.log
set -euo pipefail
module load singularityce/4.3.1-gcc-8.5.0
export LD_LIBRARY_PATH="/gpfs/software/2025/spack/opt/spack/linux-rhel8-x86_64/gcc-8.5.0/libfuse-3.16.2-cg5xbdf2pwgqhdwoaujsoqaw2mhvjb3t/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
RUN_ROOT=/scratch/unk4211/wingbench-rebuttal-20261106
RELEASE_REPO=${1:?immutable checkout}
RELEASE_SHA=${2:?release sha256}
INDEX=${SLURM_ARRAY_TASK_ID:-0}
EXTRA=()
if [[ ${3:-} == preflight ]]; then EXTRA=(--preflight); fi
singularity exec --userns --cleanenv --bind "$RUN_ROOT:/workspace" --bind "$RELEASE_REPO:/workspace/repo:ro" \
  "$RUN_ROOT/runtime/mdolab-recovered-20261107T072200Z" \
  bash --noprofile --norc /workspace/repo/rebuttal/container_entry.sh \
  python3 /workspace/repo/rebuttal/adjoint/campaign_v3/initial.py \
  --index "$INDEX" --release-sha256 "$RELEASE_SHA" \
  --out /workspace/adjoint/campaign-v3-pilot-20261107/initial "${EXTRA[@]}"

"""Reproduce proposal zero with the benchmark script, retaining the live solver.

The original initialization grader used subprocesses, so its flow state is no
longer live. This reproduction is explicit, costed, and never a cached L/D
substitute. No forward solve occurs between the verified handoff and gradient.
"""
import json
import os
from pathlib import Path
import runpy
import shutil
import time
import numpy as np
from rebuttal.adjoint.campaign_v5.common import write
from rebuttal.adjoint.campaign_v5.numerics import forward_valid, write_json
from rebuttal.adjoint.campaign_v5.trim_artifacts import checked_path, validate
from rebuttal.adjoint.campaign_v5.live_state import RetainSolver, attach_live_evaluator, snapshot


def require_proposal_zero(initial, x):
    x = np.asarray(x, dtype=float)
    if not np.array_equal(x, np.r_[np.zeros(38), initial['alphas']]):
        raise ValueError('Proposal-zero mode requires the exact supplied starting point')


def retain(initial_path, initial, mach, leaf, x, comm):
    import adflow
    from scripts.cfd.grading_protocol import load_protocol
    from scripts.cfd.grade_schema import classify_condition_attempt
    initial_path, leaf = Path(initial_path).resolve(), Path(leaf).resolve()
    require_proposal_zero(initial, x)
    trim = validate(initial, initial_path.parent)
    row = trim['conditions'][mach]
    protocol = load_protocol(verify_files=True)
    if protocol.sha256 != initial['original_protocol_sha256']:
        raise ValueError('Initial benchmark protocol changed')
    conds = json.loads(checked_path(initial_path.parent, row['conditions']).read_text())
    if conds['AA'] != protocol.seed_alpha0:
        raise ValueError('Proposal zero must start at the benchmark default angle')
    copy_error=None
    if comm.rank == 0:
        try:
            for name, record in [('wing_vol.cgns', initial['mesh']), ('input.json', trim['input'])]:
                source = checked_path(initial_path.parent, record)
                target = leaf.parent / name
                if not target.exists():
                    shutil.copy2(source, target)
                from rebuttal.adjoint.campaign_v5.common import sha
                if sha(target) != record['sha256']:
                    raise ValueError('Worker benchmark input changed')
            shutil.copy2(checked_path(initial_path.parent,row['conditions']),leaf/'conds.json')
            shutil.copy2(checked_path(initial_path.parent,row['solver_script']),leaf/'run-adflow.py')
        except Exception as exc:
            copy_error=f'{type(exc).__name__}: {exc}'
    copy_error=comm.bcast(copy_error,root=0)
    if copy_error:raise RuntimeError('Benchmark input staging failed: '+copy_error)
    comm.barrier()
    calls = []
    def observe(solver, ap, elapsed):
        norms = list(map(float,solver.getResNorms()))
        failed = bool(ap.solveFailed or ap.fatalFail)
        relative = norms[-1]/norms[0] if norms[0]>0 else float('nan')
        calls.append(dict(call=len(calls)+1, label='proposal-zero-benchmark-trim',
            alpha=float(ap.alpha),raw_norms=norms,relative_residual=relative,
            solve_failed=failed,wall_seconds=elapsed,forward_gate=1e-10,
            measurement_scope='Intermediate trim residual/flags; final coefficients checked separately'))
        if comm.rank == 0:write_json(leaf/'trim_forward_calls.json',calls)
    cwd = Path.cwd()
    began = time.monotonic()
    try:
        os.chdir(leaf)
        with RetainSolver(adflow,observe) as retained:
            runpy.run_path(str(leaf/'run-adflow.py'),run_name='__main__')
            comm.barrier()
            if len(retained.instances)!=1:raise RuntimeError('Expected exactly one benchmark solver')
            solver=retained.instances[0];ap=solver.curAP
        output=json.loads((leaf/'output.json').read_text())
        spec=dict(mach=initial['mach'][mach],cl_target=initial['target_cl'])
        grade=classify_condition_attempt(dict(termination_reason='completed',returncode=0,
            wall_seconds=time.monotonic()-began),output,spec,protocol.seed_alpha0,protocol)
        values=np.array([output['results']['wing_cl'],output['results']['wing_cd']])
        norms=list(map(float,solver.getResNorms()))
        valid=forward_valid(norms,values,ap.solveFailed or ap.fatalFail)
        if comm.rank==0:write_json(leaf/'benchmark-grade.json',grade)
        if not all(comm.allgather(grade['outcome_class']=='valid' and valid)):
            raise RuntimeError('Forward solve failed v5 numerical checks: benchmark trim')
        before,_=snapshot(solver,ap,comm)
        ev=attach_live_evaluator(solver,ap,comm,leaf,initial)
        after,_=snapshot(solver,ap,comm)
        y=np.r_[np.asarray(x)[:38],np.asarray(x)[38+mach]]
        state_same=before==after and np.array_equal(values,ev.last_values)
        request_matches=np.array_equal(y,ev.last_y)
        reference_matches=np.allclose(values,row['reference_cl_cd'],rtol=.005,atol=0)
        if comm.rank==0:
            write_json(leaf/'handoff.json',dict(before=before,after=after,
                same_live_state=state_same,request_matches=request_matches,
                reference_matches=reference_matches,CFD_calls=len(calls),extra_handoff_CFD_calls=0))
        if not all(comm.allgather(state_same)):
            raise RuntimeError('Live benchmark state changed during derivative setup')
        if not all(comm.allgather(request_matches and reference_matches)):
            raise RuntimeError('Forward solve failed v5 numerical checks: benchmark replay differs from requested proposal zero')
        ev.calls=calls
        ev.calls[-1].update(cl=float(values[0]),cd=float(values[1]),qualified=True,
            input=y.tolist(),measurement_scope='Final benchmark trim; complete forward gate passed')
        if comm.rank==0:
            write_json(leaf/'forward_calls.json',ev.calls)
            write(leaf/'setup.json',dict(initialization_source='Original benchmark trim in resident MPI worker',
                candidate_initialization='Live converged flow retained; no cold final-angle initialization',
                adjointSubspaceSize=200,forward_gate=1e-10,native_target=1e-12,native_gate=1.1e-9))
        return ev
    finally:
        os.chdir(cwd)

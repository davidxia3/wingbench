"""Run real pinned IPOPT on analytic functions only; zero CFD or adjoint solves."""
import json
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v5.core import optimize
from rebuttal.adjoint.campaign_v5.common import write

class Box:
    sd=np.ones(38)
    def to_standardized(self,x):return np.asarray(x)

class Synthetic:
    def __init__(self,failure=False,gradient_failure=False):
        self.calls=[];self.failures=0;self.failure=failure;self.gradient_failure=gradient_failure
    def __call__(self,op,x,reservation):
        self.calls.append((op,x.tolist()))
        if op=='forward' and self.failure and x[0]>.4:
            self.failures+=1;return dict(status='scientific_failure',error='Injected CFD failure',value=None)
        if op=='gradient' and self.gradient_failure:
            return dict(status='scientific_failure',error='Injected adjoint failure',value=None)
        v=np.empty((3,2));g=np.zeros((3,2,41))
        for m in range(3):
            v[m,0]=.41+.02*x[0]+.1*x[38+m]
            v[m,1]=.01+.004*(x[0]-1.4)**2+.003*(x[1]+.8)**2+.0001*np.dot(x[2:38],x[2:38])
            g[m,0,0]=.02;g[m,0,38+m]=.1
            g[m,1,0]=.008*(x[0]-1.4);g[m,1,1]=.006*(x[1]+.8);g[m,1,2:38]=.0002*x[2:38]
        return dict(status='ok',value=(v if op=='forward' else g).tolist())

def run(out):
    import cyipopt
    if cyipopt.__version__!='1.4.1' or list(cyipopt.IPOPT_VERSION)!=[3,13,4]:
        raise ValueError('Wrong IPOPT build')
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    initial=dict(geometry=[0.]*38,alphas=[0.]*3,target_cl=.41,initial_score=.01)
    results={}
    for mode,oracle in [('regular',Synthetic()),('failed_trial',Synthetic(failure=True)),
        ('failed_adjoint',Synthetic(gradient_failure=True))]:
        s=optimize(out/mode,initial,Box(),oracle,{'synthetic':True},8,cyipopt)
        if mode=='failed_adjoint':
            assert s['phase']=='adjoint_failure' and s['search_attempts']==0,s
        else:
            assert s['phase']=='budget_complete' and s['search_attempts']==8,s
            assert sum(op=='forward' for op,x in oracle.calls)==9
            if mode=='failed_trial':assert oracle.failures>0
        results[mode]=s
    from rebuttal.adjoint.campaign_v5.near_bound_smoke import run as near_bound
    near=near_bound(out/'near-bound',cyipopt)
    result=dict(passed=True,real_optimizer=True,CFD_calls=0,results=results,near_bound=near)
    write(out/'result.json',result,exclusive=True);return result

if __name__=='__main__':print(json.dumps(run(sys.argv[1]),indent=2))

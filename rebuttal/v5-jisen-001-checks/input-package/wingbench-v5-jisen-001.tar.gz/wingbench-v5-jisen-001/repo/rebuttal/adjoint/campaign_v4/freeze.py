"""Freeze a reviewable preparation package; this never approves or launches it."""
import json
from pathlib import Path
import shutil
import sys
import tarfile
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v4.common import HERE,sha,write,now


def main():
    previous=ROOT/'rebuttal/adjoint/campaign_v3/initial_release.json'
    base=json.loads(previous.read_text());sources=dict(base['source_sha256']);deltas=[]
    for rel,digest in list(sources.items()):
        actual=sha(ROOT/rel)
        if actual!=digest:
            # Existing user documentation edits do not alter numerical code.
            if rel!='data/README.md':raise ValueError('Inherited numerical dependency changed: '+rel)
            deltas.append(dict(path=rel,old_sha256=digest,new_sha256=actual,scope='pre-existing documentation edit'))
            sources[rel]=actual
    for p in HERE.glob('*.py'):sources[str(p.relative_to(ROOT))]=sha(p)
    for name in ('protocol.json','roster.json','eligibility.json','authorization.json','local-test-results.txt','REVIEW.txt','execution-plan.json'):
        p=HERE/name;sources[str(p.relative_to(ROOT))]=sha(p)
    tests=(HERE/'local-test-results.txt').read_text()
    if '\nOK\n' not in tests or 'FAILED' in tests or 'Ran 27 tests' not in tests:raise ValueError('Regression tests incomplete')
    release=dict(schema='wingbench-v4-preparation-release',created_at=now(),pilot_indices=list(range(6)),
        source_sha256=sources,runtime_expected_sha256=base['runtime_expected_sha256'],
        inherited_initial_release_sha256=sha(previous),inherited_non_numerical_deltas=deltas,
        launch_authorized=False,numerical_qualification='PENDING_FRESH_CHECK_AT_1e-10',
        local_test_scope='27 no-CFD tests; scripted optimizer and mock solver. Real pinned IPOPT smoke still pending.',
        no_scientific_runs_started=True)
    write(HERE/'release.json',release,exclusive=True)
    dest=HERE/'releases/preparation-001/repo';dest.mkdir(parents=True,exist_ok=False)
    for rel in list(sources)+[str((HERE/'release.json').relative_to(ROOT))]:
        p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,p)
    archive=HERE/'preparation-001.tar.gz'
    if archive.exists():raise ValueError('Archive already exists')
    with tarfile.open(archive,'w:gz') as tar:tar.add(dest,arcname='repo')
    result=dict(release_sha256=sha(HERE/'release.json'),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
        source_count=len(sources),checkout=str(dest),launch_authorized=False)
    write(HERE/'package.json',result,exclusive=True);print(json.dumps(result,indent=2))

if __name__=='__main__':main()

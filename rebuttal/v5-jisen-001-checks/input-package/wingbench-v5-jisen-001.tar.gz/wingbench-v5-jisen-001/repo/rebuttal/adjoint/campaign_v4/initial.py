"""One free, original-grader initialization for a fixed v4 episode."""
import argparse
import json
import math
import os
from pathlib import Path
import sys
import time
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v4.common import HERE,now,sha,write,verify_release,require_approval,original_grader
from rebuttal.adjoint.campaign_v1.run_initial_grade import (
    preflight_runtime,check_constructor_runtime,artifact,grade_costs)

def main(args):
    release=verify_release(HERE/'release.json',args.release_sha256)
    require_approval(args.approval,args.release_sha256,args.index)
    if args.index not in release['pilot_indices']: raise ValueError('Only six pilot initializations authorized')
    from benchmark.common import load_tasks,json_ready
    row=json.loads((HERE/'roster.json').read_text())['episodes'][args.index]
    task=load_tasks()[row['task']]
    if os.geteuid()==0: raise RuntimeError('Non-root grader required')
    runtime,log=preflight_runtime(release['runtime_expected_sha256'])
    out=args.out/row['episode_id']
    if args.preflight: out=args.out/('preflight-'+row['episode_id'])
    out.mkdir(parents=True,exist_ok=False)
    write(out/'runtime.json',runtime,exclusive=True)
    write(out/'runtime_probe_log.json',log,exclusive=True)
    grader=original_grader(task,out/'work',run_id=row['episode_id'])
    write(out/'constructor_check.json',check_constructor_runtime(grader),exclusive=True)
    if args.preflight:
        write(out/'complete.json',{'passed':True,'CFD_calls':0},exclusive=True);return 0
    write(out/'reservation.json',dict(episode=row,started_at=now(),phase='free_initialization',
        search_attempts=0,release_sha256=args.release_sha256,roster_sha256=sha(HERE/'roster.json')),
        exclusive=True)
    started=time.monotonic(); raw=None
    try:
        raw=json_ready(grader.grade(row['geometry'],row['episode_id']))
        write(out/'initial_grade.json',raw,exclusive=True)
        if raw['geometry']['sha256']!=row['geometry_sha256']: raise ValueError('Graded wrong geometry')
        if raw['protocol']['canonical_sha256']!=grader.protocol.sha256: raise ValueError('Wrong grading protocol')
        grade=raw['benchmark_grade']; initial=dict(row,delivered=grade['delivered'],
            initial_score=grade.get('ld'),alphas=[],mesh=None,search_attempts_consumed=0,
            remaining_search_attempts=8,initialization_free=True,grade_sha256=sha(out/'initial_grade.json'),
            roster_sha256=sha(HERE/'roster.json'),release_sha256=args.release_sha256,
            original_protocol_sha256=grader.protocol.sha256,finished_at=now(),
            phase='initialized' if grade['delivered'] else 'initial_nondelivery')
        if grade['delivered']:
            cc=sorted(raw['conditions'],key=lambda c:float(c['mach']))
            if len(cc)!=3 or [float(c['mach']) for c in cc]!=row['mach']: raise ValueError('Wrong Mach set')
            ratios=[]
            for c in cc:
                m=c['measurements'];cl,cd,ld,err=[float(m[k]) for k in ('cl','cd','ld','err_cl')]
                if (c['outcome_class']!='valid' or float(c['cl_target'])!=task.target_cl
                    or not all(math.isfinite(v) for v in (cl,cd,ld,err))
                    or min(cl,cd,ld)<=0 or ld>40 or abs(cl-task.target_cl)>.02
                    or not 0<=err<.0005 or not math.isclose(ld,cl/cd,rel_tol=1e-12)):
                    raise ValueError('Delivered initial condition fails original criteria')
                ratios.append(ld)
            if not math.isclose(float(grade['ld']),math.exp(sum(map(math.log,ratios))/3),rel_tol=1e-12):
                raise ValueError('Initial aggregate score mismatch')
            initial['alphas']=[float(c['measurements']['realized_aoa_deg']) for c in cc]
            if any(not math.isfinite(a) or not -10<=a<=25 for a in initial['alphas']): raise ValueError('Bad angles')
            grid=raw['mesh']['volume_grid_artifact'];initial['mesh']=artifact(grid['path'],out)
            if grid['sha256']!=initial['mesh']['sha256']:raise ValueError('Mesh changed')
        initial['costs']=grade_costs(raw,time.monotonic()-started,True)
        initial['costs']['joint_attempts_reserved']=0
        initial['costs']['free_initialization_calls']=1
        write(out/'initialization.json',initial,exclusive=True)
        print(json.dumps({k:initial[k] for k in ('episode_id','phase','initial_score')}),flush=True)
        return 0 if initial['delivered'] else 2
    except Exception as exc:
        write(out/'execution_error.json',dict(error=str(exc),type=type(exc).__name__,
            costs=grade_costs(raw,time.monotonic()-started,True),scientific_retry=False),exclusive=True)
        raise

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--release-sha256',required=True)
    p.add_argument('--approval',type=Path,required=True)
    p.add_argument('--preflight',action='store_true');sys.exit(main(p.parse_args()))

"""Validate scheduler and cloud allocation claims without launching a solver."""
import os
import unittest
from unittest.mock import patch
from rebuttal.adjoint.campaign_v4.preflight import execution_allocation


class ExecutionTargetTests(unittest.TestCase):
    def test_aws_records_assigned_instance_and_capacity(self):
        with patch.dict(os.environ,{'WINGBENCH_AWS_INSTANCE_ID':'i-0123456789abcdef0'},clear=True), \
             patch.object(os,'sched_getaffinity',return_value=set(range(16)),create=True):
            result=execution_allocation('aws')
        self.assertEqual(result['instance_id'],'i-0123456789abcdef0')
        self.assertEqual(result['ranks'],16)
        self.assertEqual(result['affinity_cpus'],list(range(16)))

    def test_aws_rejects_missing_id_or_insufficient_cpus(self):
        with patch.dict(os.environ,{},clear=True):
            with self.assertRaisesRegex(ValueError,'instance ID'):execution_allocation('aws')
        with patch.dict(os.environ,{'WINGBENCH_AWS_INSTANCE_ID':'i-0123456789abcdef0'},clear=True), \
             patch.object(os,'sched_getaffinity',return_value=set(range(15)),create=True):
            with self.assertRaisesRegex(ValueError,'16 available'):execution_allocation('aws')

    def test_quest_allocation_remains_explicit(self):
        with patch.dict(os.environ,{'SLURM_NTASKS':'16','SLURM_JOB_ID':'123'},clear=True):
            self.assertEqual(execution_allocation('quest')['job_id'],'123')
        with patch.dict(os.environ,{},clear=True):
            with self.assertRaisesRegex(ValueError,'Quest'):execution_allocation('quest')

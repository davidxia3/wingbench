"""Freeze outcome-independent selection and initialization-only source archive."""
import json
import hashlib
import shutil
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from rebuttal.adjoint.campaign_v3.common import HERE, sha, now, write
from benchmark.common import load_tasks, load_box, geometry_sha256

def build_roster():
    inventory = ROOT / 'rebuttal/adjoint/initialization_inventory_20261107'
    summary = json.loads((inventory / 'summary.json').read_text())
    if sha(inventory/'eligible_wings.json') != summary['candidate_file_sha256']:
        raise ValueError('Audited inventory changed')
    pool = json.loads((inventory/'eligible_wings.json').read_text())
    tasks = load_tasks(); used = set(); rows = []
    for seed in range(1, 11):
        for name in ('low', 'nominal', 'high'):
            def order(h):
                return hashlib.sha256(('wingbench-adjoint-v3|20261107|%s|%s|%s' % (seed,name,h)).encode()).hexdigest()
            h = min((h for h in pool[name] if h not in used), key=order)
            used.add(h); candidate = pool[name][h]; task = tasks[name]
            assert load_box().contains(candidate['geometry']) and geometry_sha256(candidate['geometry']) == h
            # Earliest evaluation by stable identifier, never select by score.
            proof = min(candidate['proofs'],key=lambda p:p['evaluation']['evaluation'])
            rows.append(dict(episode_id='adjoint-v3-s%02d-%s'%(seed,name),episode_index=len(rows),
                seed=seed,task=name,task_id=task.task_id,target_cl=task.target_cl,mach=list(task.mach),
                geometry=candidate['geometry'],geometry_sha256=h,
                historical_evaluation=proof['evaluation']['evaluation'],
                historical_method=proof['evaluation']['method'],
                historical_score=float(proof['evaluation']['ld']),
                original_aoa_seed_deg=task.aoa_seed_deg,
                source_scope='Non-agent online baseline outcomes; privileged initialization'))
    return dict(schema='wingbench-adjoint-roster-v3',selection_seed=20261107,
        selection='SHA256 pseudorandom ranking per seed/task; global geometry deduplication; no score ranking',
        inventory_sha256=summary['candidate_file_sha256'],episodes=rows,
        pilot_episode_indices=[0,1,2],pilot_attempts_after_initialization=4,
        eventual_attempts_after_initialization=32,initialization_free=True,
        private_grades_free=True,pilot_selection_not_conditioned_on_outcomes=True)

def main():
    roster = build_roster()
    write(HERE/'roster.json',roster,exclusive=True)
    basepath = ROOT/'rebuttal/adjoint/preparation/campaign-constructor-checks-20261107-v2/inputs/initial_phase_release.json'
    base = json.loads(basepath.read_text())
    sources = dict(base['source_sha256'])
    for rel,h in sources.items():
        if sha(ROOT/rel)!=h: raise ValueError('Original grader source changed: '+rel)
    for name in ('common.py','prepare_initial.py','initial.py','initial.sbatch','roster.json','protocol.json'):
        p=HERE/name; sources[str(p.relative_to(ROOT))]=sha(p)
    release=dict(schema='wingbench-adjoint-v3-initial-source',created_at_utc=now(),
        phase='initialization_only',optimization_authorized=False,
        source_sha256=sources,runtime_expected_sha256=base['runtime_expected_sha256'],
        pilot_indices=[0,1,2],roster_sha256=sha(HERE/'roster.json'))
    write(HERE/'initial_release.json',release,exclusive=True)
    destination=HERE/'releases'/'initial-20261107'/ 'repo'
    destination.mkdir(parents=True,exist_ok=False)
    for rel in list(sources)+[str((HERE/'initial_release.json').relative_to(ROOT))]:
        p=destination/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,p)
    print(json.dumps(dict(release_sha256=sha(HERE/'initial_release.json'),source_count=len(sources),
        checkout=str(destination),pilot=[(r['episode_id'],r['historical_evaluation']) for r in roster['episodes'][:3]]),indent=2))

if __name__=='__main__': main()

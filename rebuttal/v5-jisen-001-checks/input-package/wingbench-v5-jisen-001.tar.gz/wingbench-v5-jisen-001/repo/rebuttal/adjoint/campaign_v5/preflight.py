"""Jisen software/runtime checks only: no mesh, CFD, or physical adjoint solves."""
import argparse
import io
import json
import os
from pathlib import Path
import re
import sys
import time
import traceback
import unittest
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v5.common import HERE,sha,write,now,verify_release,require_check_approval,runtime_binding,original_grader


def execution_allocation(target):
    if target!='jisen':raise ValueError('This preparation targets Jisen compute only')
    from rebuttal.adjoint.campaign_v5.resources import hardware_record
    hw=hardware_record()
    if len(hw['affinity_logical_cpus'])<16 or (hw['affinity_physical_core_count'] or 0)<16:
        raise ValueError('At least 16 visible physical cores required')
    quota=hw['cgroup']['cpu_quota_units'];memory=hw['cgroup']['memory_limit_bytes']
    if quota is None or quota<16:raise ValueError('Finite CPU quota of at least16 required')
    if memory is None or min(memory,hw['host_memory_bytes'] or 0)<384*1024**3:
        raise ValueError('At least384 GiB verified memory required for larger-basis three-Mach worker')
    return dict(target='jisen',ranks=16,hardware=hw,
        node_name=os.environ.get('WINGBENCH_NODE_NAME'),run_id=os.environ.get('WINGBENCH_RUN_ID'),
        memory_request_gib=384,exclusivity_claimed=False)


def main(args):
    release=verify_release(HERE/'release.json',args.release_sha256)
    require_check_approval(args.check_approval,args.release_sha256)
    if os.geteuid()==0:raise ValueError('Non-root original runtime required')
    allocation=execution_allocation(args.execution_target)
    if any(os.environ.get(k)!='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')):
        raise ValueError('Single-threaded math environment required')
    args.out.mkdir(parents=True,exist_ok=False)
    write(args.out/'reservation.json',dict(phase='software_runtime_only',started_at=now(),
        allocation=allocation,release_sha256=args.release_sha256,scientific_calls=0),exclusive=True)
    began=time.monotonic();evidence=dict(passed=False,scientific_calls=0,phase='software_runtime_only')
    runtime=None;smoke=None;constructor=None;passed=False
    try:
        from rebuttal.adjoint.campaign_v1.run_initial_grade import preflight_runtime,check_constructor_runtime
        from rebuttal.adjoint.campaign_v5.run import optimizer_runtime
        scientific,probe_log=preflight_runtime(release['runtime_expected_sha256'])
        optimizer=optimizer_runtime();runtime=runtime_binding(scientific,optimizer)
        write(args.out/'runtime.json',dict(scientific=scientific,optimizer=optimizer),exclusive=True)
        write(args.out/'runtime-probe-log.json',probe_log,exclusive=True)
        stream=io.StringIO()
        suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py')
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        (args.out/'regression-tests.txt').write_text(stream.getvalue())
        evidence['regression_tests']=dict(run=result.testsRun,passed=result.wasSuccessful())
        if not result.wasSuccessful():raise RuntimeError('Regression suite failed')
        from rebuttal.adjoint.campaign_v5.optimizer_smoke import run as optimizer_smoke
        smoke=optimizer_smoke(args.out/'real-optimizer')
        if not smoke['passed'] or smoke['CFD_calls']!=0:raise ValueError('Real optimizer smoke failed')
        from benchmark.common import load_tasks
        # Constructor probes imports/MPI/environment only. Calling grade is forbidden here.
        grader=original_grader(load_tasks()['nominal'],args.out/'grader-constructor',run_id='v5-jisen-preflight')
        constructor=check_constructor_runtime(grader)
        from rebuttal.adjoint.campaign_v5.resources import filesystem_probe
        filesystem=filesystem_probe(args.out/'filesystem-probe')
        evidence['filesystem']=filesystem
        if not filesystem['passed']:raise ValueError('Output filesystem locking/atomic-write check failed')
        write(args.out/'constructor-check.json',constructor,exclusive=True)
        verify_release(HERE/'release.json',args.release_sha256)
        passed=True
    except Exception as exc:
        evidence['error']=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
    finally:
        evidence.update(passed=passed,runtime=runtime,optimizer_smoke=smoke,
            constructor=constructor,wall_seconds=time.monotonic()-began,finished_at=now(),
            allocation=allocation,numerical_gradient_qualification_claimed=False)
        write(args.out/'evidence.json',evidence,exclusive=True)
        certificate=dict(schema='wingbench-v5-software-runtime-check',passed=passed,
            release_sha256=args.release_sha256,runtime=runtime,scientific_calls=0,
            optimizer_smoke_passed=bool(smoke and smoke['passed']),
            mpi16_import_smoke_passed=constructor is not None,
            evidence_file='evidence.json',evidence_sha256=sha(args.out/'evidence.json'),
            numerical_gradient_qualification_claimed=False,finished_at=now())
        write(args.out/'certificate.json',certificate,exclusive=True)
    print(json.dumps(dict(passed=passed,scientific_calls=0,out=str(args.out),error=evidence.get('error')),indent=2))
    return 0 if passed else 3

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True)
    p.add_argument('--release-sha256',required=True);p.add_argument('--check-approval',type=Path,required=True)
    p.add_argument('--execution-target',choices=('jisen',),default='jisen')
    sys.exit(main(p.parse_args()))

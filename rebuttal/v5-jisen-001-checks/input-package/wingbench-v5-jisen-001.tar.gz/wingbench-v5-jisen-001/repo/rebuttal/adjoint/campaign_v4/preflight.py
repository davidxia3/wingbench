"""Quest software/runtime checks only: no mesh, CFD, or physical adjoint solves."""
import argparse
import io
import json
import os
from pathlib import Path
import re
import sys
import time
import traceback
import unittest
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v4.common import HERE,sha,write,now,verify_release,require_check_approval,runtime_binding,original_grader


def execution_allocation(target):
    if target=='quest':
        if int(os.environ.get('SLURM_NTASKS','0'))!=16:
            raise ValueError('Allocated Quest MPI16 check job required')
        return dict(target='quest',job_id=os.environ.get('SLURM_JOB_ID'),ranks=16)
    if target=='aws':
        instance=os.environ.get('WINGBENCH_AWS_INSTANCE_ID','')
        if not re.fullmatch(r'i-[0-9a-f]{17}',instance):
            raise ValueError('Verified assigned AWS instance ID required')
        affinity=sorted(os.sched_getaffinity(0))
        if len(affinity)<16:raise ValueError('At least 16 available AWS logical CPUs required')
        return dict(target='aws',instance_id=instance,ranks=16,affinity_cpus=affinity)
    raise ValueError('Unknown execution target')


def main(args):
    release=verify_release(HERE/'release.json',args.release_sha256)
    require_check_approval(args.check_approval,args.release_sha256)
    if os.geteuid()==0:raise ValueError('Non-root original runtime required')
    allocation=execution_allocation(args.execution_target)
    if any(os.environ.get(k)!='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')):
        raise ValueError('Single-threaded math environment required')
    args.out.mkdir(parents=True,exist_ok=False)
    write(args.out/'reservation.json',dict(phase='software_runtime_only',started_at=now(),
        allocation=allocation,release_sha256=args.release_sha256,scientific_calls=0),exclusive=True)
    began=time.monotonic();evidence=dict(passed=False,scientific_calls=0,phase='software_runtime_only')
    runtime=None;smoke=None;constructor=None;passed=False
    try:
        from rebuttal.adjoint.campaign_v1.run_initial_grade import preflight_runtime,check_constructor_runtime
        from rebuttal.adjoint.campaign_v4.run import optimizer_runtime
        scientific,probe_log=preflight_runtime(release['runtime_expected_sha256'])
        optimizer=optimizer_runtime();runtime=runtime_binding(scientific,optimizer)
        write(args.out/'runtime.json',dict(scientific=scientific,optimizer=optimizer),exclusive=True)
        write(args.out/'runtime-probe-log.json',probe_log,exclusive=True)
        stream=io.StringIO()
        suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py')
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        (args.out/'regression-tests.txt').write_text(stream.getvalue())
        evidence['regression_tests']=dict(run=result.testsRun,passed=result.wasSuccessful())
        if not result.wasSuccessful():raise RuntimeError('Regression suite failed')
        from rebuttal.adjoint.campaign_v4.optimizer_smoke import run as optimizer_smoke
        smoke=optimizer_smoke(args.out/'real-optimizer')
        if not smoke['passed'] or smoke['CFD_calls']!=0:raise ValueError('Real optimizer smoke failed')
        from benchmark.common import load_tasks
        # Constructor probes imports/MPI/environment only. Calling grade is forbidden here.
        grader=original_grader(load_tasks()['nominal'],args.out/'grader-constructor',run_id='v4-quest-preflight')
        constructor=check_constructor_runtime(grader)
        write(args.out/'constructor-check.json',constructor,exclusive=True)
        verify_release(HERE/'release.json',args.release_sha256)
        passed=True
    except Exception as exc:
        evidence['error']=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
    finally:
        evidence.update(passed=passed,runtime=runtime,optimizer_smoke=smoke,
            constructor=constructor,wall_seconds=time.monotonic()-began,finished_at=now(),
            allocation=allocation,numerical_gradient_qualification_claimed=False)
        write(args.out/'evidence.json',evidence,exclusive=True)
        certificate=dict(schema='wingbench-v4-software-runtime-check',passed=passed,
            release_sha256=args.release_sha256,runtime=runtime,scientific_calls=0,
            optimizer_smoke_passed=bool(smoke and smoke['passed']),
            mpi16_import_smoke_passed=constructor is not None,
            evidence_file='evidence.json',evidence_sha256=sha(args.out/'evidence.json'),
            numerical_gradient_qualification_claimed=False,finished_at=now())
        write(args.out/'certificate.json',certificate,exclusive=True)
    print(json.dumps(dict(passed=passed,scientific_calls=0,out=str(args.out),error=evidence.get('error')),indent=2))
    return 0 if passed else 3

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True)
    p.add_argument('--release-sha256',required=True);p.add_argument('--check-approval',type=Path,required=True)
    p.add_argument('--execution-target',choices=('quest','aws'),default='quest')
    sys.exit(main(p.parse_args()))

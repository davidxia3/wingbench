#!/bin/bash
#SBATCH --account=p33116
#SBATCH --partition=short
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --mem=16G
#SBATCH --time=00:10:00
#SBATCH --no-requeue
#SBATCH --job-name=wb-v4-checks
set -euo pipefail
RELEASE_REPO=${1:?immutable source checkout}
RELEASE_SHA=${2:?release SHA256}
CHECK_APPROVAL=${3:?authorization path inside workspace}
CHECK_OUT=${4:?new output path inside workspace}
[[ "$RELEASE_SHA" =~ ^[0-9a-f]{64}$ ]]
[[ "$RELEASE_REPO" == /scratch/unk4211/wingbench-rebuttal-20261106/adjoint/campaign-v4-quest-*/*/repo ]]
module --ignore_cache load singularityce/4.3.1-gcc-8.5.0
export LD_LIBRARY_PATH="/gpfs/software/2025/spack/opt/spack/linux-rhel8-x86_64/gcc-8.5.0/libfuse-3.16.2-cg5xbdf2pwgqhdwoaujsoqaw2mhvjb3t/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
RUN_ROOT=/scratch/unk4211/wingbench-rebuttal-20261106
singularity exec --userns --cleanenv \
 --env "SLURM_JOB_ID=$SLURM_JOB_ID" --env "SLURM_NTASKS=$SLURM_NTASKS" \
 --env "SLURM_JOB_NODELIST=$SLURM_JOB_NODELIST" \
 --bind "$RUN_ROOT:/workspace" --bind "$RELEASE_REPO:/workspace/repo:ro" \
 "$RUN_ROOT/runtime/mdolab-recovered-20261107T072200Z" \
 bash --noprofile --norc /workspace/repo/rebuttal/container_entry.sh \
 env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
 python3 /workspace/repo/rebuttal/adjoint/campaign_v4/preflight.py \
 --out "$CHECK_OUT" --release-sha256 "$RELEASE_SHA" --check-approval "$CHECK_APPROVAL"

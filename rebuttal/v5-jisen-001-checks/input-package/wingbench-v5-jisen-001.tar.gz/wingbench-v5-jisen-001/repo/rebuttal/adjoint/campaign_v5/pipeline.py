"""One fresh episode after software/runtime checks; writes only its new output root.

Host allocation, upload verification and safe shutdown are separate orchestration
steps. This driver never starts/stops a host or retries any scientific failure.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.campaign_v5.common import HERE,write,sha,now,verify_release,require_approval


def main(args):
    release=verify_release(HERE/'release.json',args.release_sha256)
    require_approval(args.approval,args.release_sha256,args.index)
    # Validate the complete certificate and this runtime before initial CFD,
    # rather than discovering a mismatch only when optimization starts.
    from rebuttal.adjoint.campaign_v5.common import require_runtime_check,runtime_binding
    from rebuttal.adjoint.campaign_v5.run import optimizer_runtime
    from rebuttal.adjoint.campaign_v5.preflight import execution_allocation
    from rebuttal.adjoint.campaign_v1.run_initial_grade import preflight_runtime
    execution_allocation('jisen')
    scientific,_=preflight_runtime(release['runtime_expected_sha256'])
    require_runtime_check(args.runtime_check,args.release_sha256,runtime_binding(scientific,optimizer_runtime()))
    row=json.loads((HERE/'roster.json').read_text())['episodes'][args.index]
    args.out.mkdir(parents=True,exist_ok=False)
    write(args.out/'reservation.json',dict(index=args.index,episode=row['episode_id'],
        started_at=now(),release_sha256=args.release_sha256,search_limit=8),exclusive=True)
    common=['--release-sha256',args.release_sha256,'--approval',str(args.approval)]
    def run(name,extra):
        return subprocess.run([sys.executable,str(HERE/(name+'.py'))]+common+extra,check=False).returncode
    initial=args.initial
    phase='blocked';error=None
    try:
        if initial is None:
            code=run('initial',['--index',str(args.index),'--out',str(args.out/'initial')])
            initial=args.out/'initial'/row['episode_id']/'initialization.json'
            if code==2:
                phase='initial_nondelivery';return 2
            if code:raise RuntimeError('Initialization failed operationally; retain evidence and do not retry automatically')
        data=json.loads(initial.read_text())
        if data['episode_index']!=args.index:raise ValueError('Wrong initialization index')
        code=run('run',['--initial',str(initial),'--out',str(args.out/'optimization'),
            '--runtime-check',str(args.runtime_check),'--stage-limit','8'])
        if code:raise RuntimeError('Search blocked; do not restart')
        stage=args.out/'optimization/stage-08.json'
        code=run('private',['--initial',str(initial),'--stage',str(stage),'--out',str(args.out/'private')])
        if code:raise RuntimeError('Private grade unresolved; preserve reservation and logs')
        phase='outcome_collected';return 0
    except Exception as exc:error=str(exc);raise
    finally:
        write(args.out/'pipeline-status.json',dict(phase=phase,error=error,
            episode_index=args.index,finished_at=now(),automatic_retry=False,
            initialization_path=str(initial) if initial else None),exclusive=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True)
    p.add_argument('--initial',type=Path);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--runtime-check',type=Path,required=True);p.add_argument('--approval',type=Path,required=True)
    p.add_argument('--release-sha256',required=True);sys.exit(main(p.parse_args()))

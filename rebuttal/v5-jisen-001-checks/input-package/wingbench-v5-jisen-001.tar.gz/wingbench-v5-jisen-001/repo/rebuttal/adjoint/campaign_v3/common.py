"""Prospective conventional-adjoint campaign; never mutates older campaigns."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def write(path, value, exclusive=False):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n'
    if exclusive:
        with p.open('x') as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
    else:
        t = p.with_suffix(p.suffix + '.tmp')
        with t.open('w') as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
        t.replace(p)

def verify_release(path, expected):
    path = Path(path)
    if sha(path) != expected: raise ValueError('Release hash mismatch')
    d = json.loads(path.read_text())
    for rel, digest in d['source_sha256'].items():
        p = Path(rel)
        if p.is_absolute() or '..' in p.parts or sha(ROOT / p) != digest:
            raise ValueError('Source mismatch: ' + rel)
    return d

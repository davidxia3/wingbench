"""Example optimizers."""

#!/usr/bin/env python3
"""Fast infrastructure/provenance checks; no CFD solves and no qualification.

Launch with the same 16-rank MPI command as the numerical tasks, setting the
three thread-count variables to 1 only in this child environment. Rank zero
writes --out atomically. All ranks return nonzero on any failed check.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib
import inspect
import json
import os
from pathlib import Path
import platform
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
COVERAGE = ROOT / 'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json'
COVERAGE_SHA256 = '52dc6c65fb29582c25108b78fd14536577cc8c02c0c2daa27ef5cebab7b927ee'
CST_COMMIT = '9500b19a732463c26b32f6860ac6c517c7d212a5'
THREAD_NAMES = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def checked_file(path, expected, errors, label):
    path = Path(path)
    actual = sha256(path) if path.is_file() else None
    if not re.fullmatch(r'[0-9a-f]{64}', str(expected)) or actual != expected:
        errors.append('Hash mismatch or missing file: ' + label)
    return {'path': str(path), 'expected_sha256': expected, 'actual_sha256': actual,
            'passed': actual == expected and actual is not None}


def atomic_report(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError('Refusing to replace prior preflight evidence: ' + str(path))
    temporary = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    with temporary.open('x') as stream:
        stream.write(json.dumps(payload, indent=2, allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    # Link is no-replace and atomic on the destination filesystem.
    os.link(str(temporary), str(path))
    temporary.unlink()


def read_text(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def cgroup_resources():
    """Read this process's v1/v2 leaf and visible ancestor limits, if exposed."""
    paths = []
    membership = read_text('/proc/self/cgroup') or ''
    for row in membership.splitlines():
        _, controllers, location = row.split(':', 2)
        if not controllers:
            paths.extend([Path('/sys/fs/cgroup') / location.lstrip('/'), Path('/sys/fs/cgroup')])
        for controller in controllers.split(','):
            if controller in ('cpu', 'cpuacct', 'memory', 'cpuset'):
                paths.extend([Path('/sys/fs/cgroup') / controller / location.lstrip('/'),
                              Path('/sys/fs/cgroup') / controller])
    paths.extend([Path('/sys/fs/cgroup'), Path('/sys/fs/cgroup/cpu'),
                  Path('/sys/fs/cgroup/cpu,cpuacct'), Path('/sys/fs/cgroup/memory')])
    expanded = set()
    for path in paths:
        if '..' in path.parts:
            continue
        while str(path).startswith('/sys/fs/cgroup'):
            expanded.add(path)
            if path == Path('/sys/fs/cgroup'):
                break
            path = path.parent
    records, cpu_limits, memory_limits = [], [], []
    for path in sorted(expanded):
        cpu_max = read_text(path / 'cpu.max')
        quota = read_text(path / 'cpu.cfs_quota_us')
        period = read_text(path / 'cpu.cfs_period_us')
        mem = read_text(path / 'memory.max') or read_text(path / 'memory.limit_in_bytes')
        cpuset = read_text(path / 'cpuset.cpus.effective') or read_text(path / 'cpuset.cpus')
        if not any((cpu_max, quota, period, mem, cpuset)):
            continue
        records.append({'path': str(path), 'cpu.max': cpu_max, 'cpu_quota_us': quota,
                        'cpu_period_us': period, 'memory_limit': mem, 'cpuset': cpuset})
        if cpu_max:
            q, p = cpu_max.split()
            if q != 'max' and int(q) >= 0:
                cpu_limits.append(int(q) / int(p))
        elif quota and period and int(quota) >= 0:
            cpu_limits.append(int(quota) / int(period))
        if mem and mem != 'max' and 0 < int(mem) < (1 << 60):
            memory_limits.append(int(mem))
    return {'records': records, 'cpu_quota_units': min(cpu_limits) if cpu_limits else None,
            'memory_limit_bytes': min(memory_limits) if memory_limits else None}


def hardware_record():
    affinity = sorted(os.sched_getaffinity(0))
    physical = set()
    for cpu in affinity:
        topology = Path('/sys/devices/system/cpu/cpu' + str(cpu)) / 'topology'
        package, core = read_text(topology / 'physical_package_id'), read_text(topology / 'core_id')
        if package is not None and core is not None:
            physical.add((package, core))
    info = read_text('/proc/cpuinfo') or ''
    model = next((line.split(':', 1)[1].strip() for line in info.splitlines()
                  if line.startswith('model name')), None)
    meminfo = read_text('/proc/meminfo') or ''
    memtotal = next((int(line.split()[1]) * 1024 for line in meminfo.splitlines()
                     if line.startswith('MemTotal:')), None)
    return {'hostname': socket.gethostname(), 'machine': platform.machine(),
            'platform': platform.platform(), 'kernel': platform.release(), 'cpu_model': model,
            'affinity_logical_cpus': affinity, 'affinity_physical_core_count': len(physical) or None,
            'host_memory_bytes': memtotal, 'cgroup': cgroup_resources(),
            'physical_core_exclusivity_verified': False,
            'physical_core_note': 'Visible topology and quota do not establish exclusive physical cores; Kubernetes CPU units may be hardware threads.'}


def filesystem_probe(directory):
    """Test rename, exclusive create, flock and MPI visibility separately."""
    directory.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.preflight-', dir=str(directory)) as temp:
        root = Path(temp)
        path = root / 'probe'
        with path.open('x') as stream:
            stream.write('wingbench-preflight\n')
            stream.flush()
            os.fsync(stream.fileno())
        exclusive = False
        try:
            path.open('x').close()
        except FileExistsError:
            exclusive = True
        renamed = root / 'renamed'
        path.rename(renamed)
        content_ok = renamed.read_text() == 'wingbench-preflight\n'
        lock = root / 'lock'
        child_code = ('import fcntl,sys; f=open(sys.argv[1],"a+"); '
                      '\ntry: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)'
                      '\nexcept BlockingIOError: sys.exit(23)'
                      '\nsys.exit(0)')
        with lock.open('a+') as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            blocked = subprocess.run([sys.executable, '-c', child_code, str(lock)],
                                     capture_output=True, text=True, timeout=20)
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        unlocked = subprocess.run([sys.executable, '-c', child_code, str(lock)],
                                  capture_output=True, text=True, timeout=20)
        claim = root / 'claim'
        claim.mkdir()
        mkdir_exclusive = False
        try:
            claim.mkdir()
        except FileExistsError:
            mkdir_exclusive = True
        disk = shutil.disk_usage(directory)
        return {'directory': str(directory), 'device_id': directory.stat().st_dev,
                'exclusive_create': exclusive, 'atomic_rename_readback': content_ok,
                'exclusive_mkdir': mkdir_exclusive,
                'flock_excludes_second_process': blocked.returncode == 23,
                'flock_released': unlocked.returncode == 0,
                'free_bytes': disk.free,
                'passed': all((exclusive, content_ok, mkdir_exclusive,
                               blocked.returncode == 23, unlocked.returncode == 0)),
                'scope': 'Same-pod processes only; cross-node claim visibility must be checked by the batch coordinator.'}


def runtime_record():
    modules = {}
    for name in ('numpy', 'scipy', 'mpi4py', 'petsc4py', 'adflow', 'idwarp',
                 'pyhyp', 'cgnsutilities', 'baseclasses', 'cst_modeling'):
        module = importlib.import_module(name)
        modules[name] = {'version': str(getattr(module, '__version__', 'not exposed')),
                         'path': str(getattr(module, '__file__', 'not exposed'))}
    from adflow import ADFLOW
    from idwarp import USMesh
    from cst_modeling import math as cst_math, basic as cst_basic, section as cst_section, io as cst_io
    adflow_path = Path(inspect.getfile(ADFLOW)).resolve()
    idwarp_path = Path(inspect.getfile(USMesh)).resolve()
    paths = {'adflow_python': adflow_path,
             'adflow_library': adflow_path.with_name('libadflow.so'),
             'idwarp_python': idwarp_path,
             'cst_math': Path(inspect.getfile(cst_math)).resolve(),
             'cst_basic': Path(inspect.getfile(cst_basic)).resolve(),
             'cst_section': Path(inspect.getfile(cst_section)).resolve(),
             'cst_io': Path(inspect.getfile(cst_io)).resolve()}
    # Extra provenance is reported even when not part of the older runtime pin.
    for library in sorted(idwarp_path.parent.glob('*.so')):
        paths['idwarp_binary_' + library.name] = library
    commit = subprocess.run(['git', '-C', str(paths['cst_math'].parent), 'rev-parse', 'HEAD'],
                            check=True, text=True, capture_output=True, timeout=10).stdout.strip()
    mpirun = shutil.which('mpirun')
    if not mpirun:
        raise RuntimeError('mpirun is absent')
    mpi_version = subprocess.run([mpirun, '--version'], check=True, text=True,
                                 capture_output=True, timeout=20).stdout.strip()
    # Do not initialize PETSc collectively from rank zero alone. The immutable
    # image supplies this header, and the loaded solver library is hashed above.
    petsc_header = Path(os.environ['PETSC_DIR']) / 'include/petscversion.h'
    petsc_text = petsc_header.read_text()
    petsc_version = [int(re.search(r'^\s*#\s*define\s+PETSC_VERSION_' + key + r'\s+(\d+)',
                                   petsc_text, re.MULTILINE).group(1))
                     for key in ('MAJOR', 'MINOR', 'SUBMINOR')]
    return {'python': platform.python_version(), 'executable': sys.executable,
            'modules': modules, 'petsc_version': petsc_version,
            'petsc_version_source': str(petsc_header), 'petsc_header_sha256': sha256(petsc_header),
            'cst_commit': commit, 'mpirun_path': mpirun, 'mpirun_sha256': sha256(mpirun),
            'mpirun_version': mpi_version,
            'sha256': {name: sha256(path) for name, path in paths.items()},
            'paths': {name: str(path) for name, path in paths.items()},
            'binary_hash_scope': 'Installed library files; preflight does not instantiate a CFD solver.'}


def provenance(errors, package_path):
    files = [checked_file(COVERAGE, COVERAGE_SHA256, errors, 'frozen coverage manifest')]
    coverage = json.loads(COVERAGE.read_text())
    for relative, expected in coverage['source_sha256'].items():
        files.append(checked_file(ROOT / relative, expected, errors, relative))
    files.append(checked_file(coverage['mesh']['container_path'], coverage['mesh']['sha256'],
                              errors, 'frozen V012 mesh'))
    package = json.loads(package_path.read_text())
    sources = package.get('source_sha256')
    if not isinstance(sources, dict) or not sources:
        raise ValueError('Package manifest requires a nonempty source_sha256 mapping')
    for relative, expected in sources.items():
        path = Path(relative)
        if path.is_absolute() or '..' in path.parts:
            raise ValueError('Package source path must be repo-relative: ' + relative)
        files.append(checked_file(ROOT / path, expected, errors, relative))
    if str(Path(__file__).resolve().relative_to(ROOT)) not in sources:
        errors.append('Package manifest does not pin preflight.py')
    for asset in package.get('assets', []):
        if not Path(asset['path']).is_absolute():
            raise ValueError('Package asset path must be container-absolute')
        files.append(checked_file(asset['path'], asset['sha256'], errors, asset['path']))
    expected_runtime = dict(coverage['expected_runtime_sha256'])
    for key, value in package.get('runtime_expected_sha256', {}).items():
        if key in expected_runtime and expected_runtime[key] != value:
            errors.append('Package changes frozen runtime pin: ' + key)
        expected_runtime[key] = value
    runtime = runtime_record()
    for key, expected in expected_runtime.items():
        if runtime['sha256'].get(key) != expected:
            errors.append('Runtime hash mismatch or unavailable key: ' + key)
    expected_versions = {'numpy': '1.21.5', 'scipy': '1.7.3', 'mpi4py': '3.1.5'}
    for name, version in expected_versions.items():
        if runtime['modules'][name]['version'] != version:
            errors.append('Pinned version mismatch: ' + name)
    if runtime['python'] != '3.9.12':
        errors.append('Pinned Python 3.9.12 required')
    if runtime['petsc_version'] != [3, 15, 5]:
        errors.append('Pinned PETSc 3.15.5 required')
    if 'Open MPI) 4.1.6' not in runtime['mpirun_version']:
        errors.append('Pinned Open MPI 4.1.6 required')
    if runtime['cst_commit'] != CST_COMMIT:
        errors.append('Pinned CST commit mismatch')
    return {'package_manifest': str(package_path), 'package_manifest_sha256': sha256(package_path),
            'protocol_sha256': package.get('protocol_sha256'), 'files': files, 'runtime': runtime}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--shared', type=Path, default=Path('/results'))
    p.add_argument('--package-manifest', type=Path, default=HERE / 'package_manifest.json')
    p.add_argument('--minimum-memory-gib', type=int,
                   default=int(os.environ.get('WINGBENCH_MEMORY_GIB', '96')))
    args = p.parse_args()
    from mpi4py import MPI
    comm = MPI.COMM_WORLD
    start = time.monotonic()
    local_errors = []
    rank_record = {'rank': comm.rank, 'world_size': comm.size, 'uid': os.getuid(),
                   'gid': os.getgid(), 'thread_environment': {k: os.environ.get(k) for k in THREAD_NAMES},
                   'mpi_library_version': MPI.Get_library_version()}
    try:
        rank_record['hardware'] = hardware_record()
        if comm.size != 16:
            local_errors.append('Exactly 16 MPI ranks required')
        if os.getuid() != 1000:
            local_errors.append('UID 1000 required')
        if platform.system() != 'Linux' or platform.machine() not in ('x86_64', 'amd64'):
            local_errors.append('Pinned runtime requires Linux amd64')
        if any(os.environ.get(k) != '1' for k in THREAD_NAMES):
            local_errors.append('Each BLAS/OMP thread variable must be 1 in the MPI child')
        hw = rank_record['hardware']
        if len(hw['affinity_logical_cpus']) < 16:
            local_errors.append('Rank affinity exposes fewer than 16 logical CPUs; hard binding or inadequate allocation')
        if hw['affinity_physical_core_count'] is None or hw['affinity_physical_core_count'] < 16:
            local_errors.append('Fewer than 16 physical cores visible in affinity topology')
        quota = hw['cgroup']['cpu_quota_units']
        if quota is None:
            local_errors.append('Cannot verify finite Kubernetes CPU quota')
        elif quota < 16:
            local_errors.append('Cgroup CPU quota is less than 16 CPU units')
        memory = hw['cgroup']['memory_limit_bytes']
        if memory is None:
            local_errors.append('Cannot verify finite Kubernetes memory limit')
        elif memory < args.minimum_memory_gib * 1024 ** 3:
            local_errors.append('Cgroup memory limit below requested preflight minimum')
        if 'Open MPI v4.1.6' not in rank_record['mpi_library_version']:
            local_errors.append('mpi4py is not using pinned Open MPI 4.1.6')
        # Every rank imports the stack; detailed file/version hashes are root-only.
        for name in ('numpy', 'scipy', 'adflow', 'idwarp', 'pyhyp', 'cgnsutilities', 'cst_modeling'):
            importlib.import_module(name)
    except Exception as exc:
        local_errors.append(type(exc).__name__ + ': ' + str(exc))
    rank_record['errors'] = local_errors
    ranks = comm.gather(rank_record, root=0)
    # A collective validates communication independently of the solver libraries.
    rank_sum = comm.allreduce(comm.rank, op=MPI.SUM)
    payload = None
    if comm.rank == 0:
        errors = ['Rank ' + str(r['rank']) + ': ' + e for r in ranks for e in r['errors']]
        payload = {'schema': 'wingbench-jisen-preflight-v1', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
                   'qualification_completed': False, 'can_release_pilot': False,
                   'scope': 'Infrastructure and frozen provenance only; numerical certification is separate.',
                   'ranks': ranks, 'rank_sum': rank_sum, 'requested_ranks': 16,
                   'minimum_memory_gib': args.minimum_memory_gib,
                   'image_declared': os.environ.get('WINGBENCH_IMAGE'),
                   'pod_name': os.environ.get('WINGBENCH_POD_NAME'),
                   'node_name': os.environ.get('WINGBENCH_NODE_NAME')}
        if rank_sum != 120 or sorted(r['rank'] for r in ranks) != list(range(16)):
            errors.append('MPI collective or rank inventory failed')
        if len({r.get('hardware', {}).get('hostname') for r in ranks}) != 1:
            errors.append('All 16 ranks must remain in one pod on one node')
        try:
            payload['provenance'] = provenance(errors, args.package_manifest)
            payload['filesystems'] = [filesystem_probe(Path('/workspace/.wingbench-locks')),
                                      filesystem_probe(args.shared)]
            for report in payload['filesystems']:
                if not report['passed']:
                    errors.append('Filesystem write/lock test failed: ' + report['directory'])
            payload['mountinfo'] = read_text('/proc/self/mountinfo')
        except Exception as exc:
            errors.append(type(exc).__name__ + ': ' + str(exc))
        payload['errors'] = errors
        payload['passed'] = not errors
        payload['wall_seconds'] = time.monotonic() - start
        try:
            atomic_report(args.out, payload)
        except Exception as exc:
            payload['passed'] = False
            payload['errors'].append('Could not preserve preflight report: ' + str(exc))
        print('JISEN_PREFLIGHT ' + json.dumps({'passed': payload['passed'], 'out': str(args.out),
                                             'errors': payload['errors'], 'wall_seconds': payload['wall_seconds']}), flush=True)
    passed = comm.bcast(payload['passed'] if comm.rank == 0 else None, root=0)
    comm.barrier()
    raise SystemExit(0 if passed else 2)


if __name__ == '__main__':
    main()

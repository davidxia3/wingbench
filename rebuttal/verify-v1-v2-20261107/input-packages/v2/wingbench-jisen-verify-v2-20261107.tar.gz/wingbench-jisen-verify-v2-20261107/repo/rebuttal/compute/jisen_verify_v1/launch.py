#!/usr/bin/env python3
"""Run exactly one frozen Jisen verification batch, retaining all evidence.

The operator host needs Python 3, kubectl, this unchanged bundle and a writable
mount of the same RWX PVC at --results-host. This can run overnight. There is no
automatic retry, deletion, numerical relaxation or baseline-campaign launch.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE))
import render_jobs


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, data, replace=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not replace:
        raise FileExistsError('Refusing to overwrite evidence: ' + str(path))
    temp = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    with temp.open('x') as stream:
        stream.write(json.dumps(data, indent=2, allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    if replace:
        temp.replace(path)
    else:
        os.link(str(temp), str(path))
        temp.unlink()


def read_json(path):
    return json.loads(Path(path).read_text())


def verify_bundle():
    manifest_path = HERE / 'package_manifest.json'
    protocol_path = HERE / 'numerical_protocol.json'
    manifest = read_json(manifest_path)
    sources = manifest.get('source_sha256')
    if not isinstance(sources, dict) or not sources:
        raise ValueError('Missing package source hash manifest')
    required = {str((HERE / name).relative_to(ROOT)) for name in
                ('launch.py', 'render_jobs.py', 'certify.py', 'numerical_protocol.json')}
    if not required.issubset(sources):
        raise ValueError('Package must pin launcher, renderer, certifier and numerical protocol')
    for relative, expected in sources.items():
        part = Path(relative)
        if part.is_absolute() or '..' in part.parts:
            raise ValueError('Unsafe package source path: ' + relative)
        path = ROOT / part
        if (not re.fullmatch(r'[0-9a-f]{64}', str(expected)) or
                not path.is_file() or sha(path) != expected):
            raise ValueError('Package file missing or changed: ' + relative)
    protocol_hash = sha(protocol_path)
    if manifest.get('protocol_sha256') != protocol_hash:
        raise ValueError('Package numerical protocol hash mismatch')
    return {'package_manifest_sha256': sha(manifest_path), 'protocol_sha256': protocol_hash,
            'verified_source_count': len(sources)}


class Kubectl:
    def __init__(self, args, out):
        self.args, self.out = args, out
        self.sequence = 0
        self.metrics_available = True
        self.sampled_peaks = {}

    def call(self, words, label, check=True, timeout=60):
        self.sequence += 1
        command = [self.args.kubectl, '--namespace', self.args.namespace] + list(words)
        started = now()
        try:
            completed = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
            record = {'command': command, 'started_at_utc': started, 'finished_at_utc': now(),
                      'return_code': completed.returncode, 'stdout': completed.stdout,
                      'stderr': completed.stderr}
        except (OSError, subprocess.TimeoutExpired) as exc:
            record = {'command': command, 'started_at_utc': started, 'finished_at_utc': now(),
                      'return_code': None, 'error': type(exc).__name__ + ': ' + str(exc)}
        write_json(self.out / 'kubectl' / ('{:06d}-{}.json'.format(self.sequence, label)), record)
        if check and record['return_code'] != 0:
            raise RuntimeError('kubectl {} failed; inspect retained command evidence'.format(label))
        return record

    def get(self, words, label):
        return json.loads(self.call(words + ['-o', 'json'], label)['stdout'])

    def submit(self, manifest, phase):
        names = [item['metadata']['name'] for item in manifest['items']]
        existing = self.get(['get', 'jobs'] + names + ['--ignore-not-found'], phase + '-check-names')
        if existing.get('items') or existing.get('kind') == 'Job':
            raise RuntimeError('A requested Job already exists; use a fresh run ID, never overwrite/retry it')
        path = self.out / (phase + '-jobs.json')
        write_json(path, manifest)
        # create is deliberate: apply could update a pre-existing Job in a race.
        self.call(['create', '-f', str(path)], phase + '-create', timeout=120)
        return names

    def sample_metrics(self, phase):
        if not self.metrics_available:
            return
        selector = 'wingbench-run={},wingbench-phase={}'.format(self.args.run_id, phase)
        result = self.call(['top', 'pods', '-l', selector, '--no-headers'], phase + '-metrics', check=False)
        if result['return_code'] != 0:
            text = (result.get('stderr', '') + result.get('stdout', '')).lower()
            if 'metrics api not available' in text or 'forbidden' in text or 'could not find' in text:
                self.metrics_available = False
            return
        for line in result.get('stdout', '').splitlines():
            fields = line.split()
            if len(fields) != 3:
                continue
            pod, cpu, memory = fields
            try:
                cpu_units = float(cpu[:-1]) / 1000 if cpu.endswith('m') else float(cpu)
                match = re.fullmatch(r'([0-9.]+)(Ki|Mi|Gi|Ti|K|M|G|T)?', memory)
                factors = {None: 1, 'Ki': 1024, 'Mi': 1024 ** 2, 'Gi': 1024 ** 3,
                           'Ti': 1024 ** 4, 'K': 1000, 'M': 1000 ** 2,
                           'G': 1000 ** 3, 'T': 1000 ** 4}
                memory_bytes = float(match.group(1)) * factors[match.group(2)]
            except (ValueError, AttributeError, KeyError):
                continue
            row = self.sampled_peaks.setdefault(pod, {'samples': 0, 'max_sampled_cpu_units': 0,
                                                     'max_sampled_memory_bytes': 0})
            row['samples'] += 1
            row['max_sampled_cpu_units'] = max(row['max_sampled_cpu_units'], cpu_units)
            row['max_sampled_memory_bytes'] = max(row['max_sampled_memory_bytes'], memory_bytes)
        write_json(self.out / 'sampled-resource-peaks.json',
                   {'pods': self.sampled_peaks, 'metrics_api_available': self.metrics_available,
                    'scope': 'Opportunistic 5-minute samples; not true peak RSS or a memory-sufficiency certificate.'}, replace=True)

    def collect_pods(self, phase, logs=False):
        selector = 'wingbench-run={},wingbench-phase={}'.format(self.args.run_id, phase)
        result = self.call(['get', 'pods', '-l', selector, '-o', 'json'], phase + '-pods', check=False)
        if result['return_code'] != 0:
            return
        pods = json.loads(result['stdout'])
        write_json(self.out / (phase + '-pod-status.json'), pods, replace=True)
        if logs:
            for pod in pods.get('items', []):
                name = pod['metadata']['name']
                result = self.call(['logs', name, '--all-containers=true', '--timestamps=true'],
                                   phase + '-pod-log', check=False, timeout=120)
                (self.out / (name + '.log')).write_text(result.get('stdout', ''))

    def wait(self, names, phase):
        previous, last_metrics = None, 0.0
        while True:
            result = self.get(['get', 'jobs'] + names, phase + '-status')
            jobs = result.get('items', [result] if result.get('kind') == 'Job' else [])
            by_name = {job['metadata']['name']: job for job in jobs}
            if set(by_name) != set(names):
                raise RuntimeError('Expected Job disappeared or unexpected Job returned')
            states = {}
            for name, job in by_name.items():
                status = job.get('status', {})
                conditions = {c.get('type'): c for c in status.get('conditions', [])
                              if c.get('status') == 'True'}
                if 'Failed' in conditions:
                    states[name] = 'failed'
                elif 'Complete' in conditions:
                    states[name] = 'complete'
                else:
                    states[name] = 'running' if status.get('active') else 'pending'
            if states != previous:
                print('{} {}: {}'.format(now(), phase, json.dumps(states, sort_keys=True)), flush=True)
                self.collect_pods(phase)
                previous = states
            if time.monotonic() - last_metrics >= 300:
                self.sample_metrics(phase)
                last_metrics = time.monotonic()
            if all(state in ('complete', 'failed') for state in states.values()):
                self.collect_pods(phase, logs=True)
                write_json(self.out / (phase + '-completion.json'),
                           {'finished_at_utc': now(), 'states': states, 'jobs': jobs})
                return all(state == 'complete' for state in states.values())
            time.sleep(30)


def match_preflight(path, bundle, image):
    record = read_json(path)
    provenance = record.get('provenance', {})
    if (record.get('passed') is not True or record.get('image_declared') != image or
            provenance.get('package_manifest_sha256') != bundle['package_manifest_sha256'] or
            provenance.get('protocol_sha256') != bundle['protocol_sha256']):
        raise RuntimeError('Preflight failed or differs from the host package/image: ' + str(path))


def run(args):
    bundle = verify_bundle()
    if args.phase != 'workers':
        raise ValueError('This launcher always starts a full verification batch; --phase must be workers')
    expected_shared = '/results/' + args.run_id
    if args.shared_dir not in (None, expected_shared):
        raise ValueError('Launcher --shared-dir must equal /results/RUN_ID')
    args.shared_dir = expected_shared
    # Validate all launch parameters and all phase manifests before any writes.
    manifests = {}
    for phase in ('workers', 'pilot', 'regrade'):
        args.phase = phase
        manifests[phase] = render_jobs.render(args)
    args.phase = 'workers'
    host_root = args.results_host.expanduser().resolve(strict=True)
    if not host_root.is_dir():
        raise ValueError('--results-host must be an existing mount/directory of the RWX PVC')
    if args.output and args.output.exists():
        raise FileExistsError('--output already exists; previous evidence will not be overwritten')
    shared = host_root / args.run_id
    shared.mkdir(exist_ok=False)
    output = shared / 'launcher'
    output.mkdir()
    plan = {'schema': 'wingbench-jisen-run-plan-v1', 'workers': args.workers,
            'run_campaign': False, 'run_id': args.run_id, 'image': args.image,
            'node_a': args.node_a, 'node_b': args.node_b, 'namespace': args.namespace,
            'protocol_sha256': bundle['protocol_sha256'],
            'package_manifest_sha256': bundle['package_manifest_sha256'],
            'container_shared_path': args.shared_dir, 'created_at_utc': now()}
    write_json(shared / 'run_plan.json', plan)
    summary = {'schema': 'wingbench-jisen-launch-result-v1', 'run_id': args.run_id,
               'started_at_utc': now(), 'validation_completed': False,
               'full_campaign_launched': False, 'can_launch_campaign': False,
               'competitive_baseline_result': False, 'strict_host_qualification_passed': False,
               'pilot_completed': False, 'independent_regrade_passed': False,
               'protocol_sha256': bundle['protocol_sha256'],
               'package_manifest_sha256': bundle['package_manifest_sha256'],
               'host_results': str(shared), 'container_results': args.shared_dir,
               'jobs_retained': True, 'automatic_retry': False}
    client = Kubectl(args, output)
    code = 2
    try:
        print('Starting one frozen verification batch. It may run overnight; keep this launcher alive. '
              'No baseline campaign or automatic retries will run. Results: ' + str(shared), flush=True)
        names = client.submit(manifests['workers'], 'workers')
        workers_ok = client.wait(names, 'workers')
        summary['worker_jobs_completed_successfully'] = workers_ok
        # Always attempt certification after the worker phase, including failed
        # processes, to retain a useful explicit scientific failure report.
        command = [sys.executable, str(HERE / 'certify.py'), '--shared', str(shared)]
        with (output / 'certify.log').open('x') as stream:
            cert = subprocess.run(command, cwd=str(ROOT), stdout=stream, stderr=subprocess.STDOUT)
        summary['certify_return_code'] = cert.returncode
        certificate_path = shared / 'qualification/certificate.json'
        certificate = read_json(certificate_path) if certificate_path.is_file() else {}
        strict = (workers_ok and cert.returncode == 0 and
                  certificate.get('strict_host_qualification_passed') is True and
                  certificate.get('protocol_sha256') == bundle['protocol_sha256'])
        if not strict:
            summary['status'] = 'stopped_after_failed_or_incomplete_qualification'
        else:
            for worker in range(args.workers):
                match_preflight(shared / 'workers' / ('worker-' + str(worker)) / 'preflight.json', bundle, args.image)
            summary['strict_host_qualification_passed'] = True
            names = client.submit(manifests['pilot'], 'pilot')
            pilot_ok = client.wait(names, 'pilot')
            status_path = shared / 'pilot/pilot_status.json'
            status = read_json(status_path) if status_path.is_file() else {}
            recommendation_path = shared / 'pilot/recommendation.json'
            if (not pilot_ok or status.get('exit_code') != 0 or
                    status.get('status') != 'integration_pilot_finished' or not recommendation_path.is_file()):
                summary['status'] = 'stopped_after_failed_or_incomplete_pilot'
            else:
                match_preflight(shared / 'workers/pilot-0/preflight.json', bundle, args.image)
                recommendation = read_json(recommendation_path)
                summary['pilot_completed'] = True
                summary['optimizer_success'] = recommendation.get('optimization', {}).get('success')
                summary['optimizer_status'] = recommendation.get('optimization')
                summary['pilot_scope'] = 'Bounded integration pilot; an iteration/evaluation limit is not optimizer convergence or a competitive baseline.'
                names = client.submit(manifests['regrade'], 'regrade')
                regrade_ok = client.wait(names, 'regrade')
                result_path = shared / 'regrade/verification_result.json'
                result = read_json(result_path) if result_path.is_file() else {}
                if regrade_ok:
                    match_preflight(shared / 'workers/regrade-0/preflight.json', bundle, args.image)
                summary['independent_regrade'] = result
                summary['independent_regrade_passed'] = bool(regrade_ok and result.get('passed') is True and
                                                             result.get('delivered') is True)
                if summary['independent_regrade_passed']:
                    summary['validation_completed'] = True
                    summary['status'] = 'bounded_validation_completed_no_campaign_launched'
                    code = 0
                else:
                    summary['status'] = 'stopped_after_failed_or_incomplete_regrade'
    except KeyboardInterrupt:
        summary['status'] = 'launcher_interrupted'
        summary['error'] = 'Jobs were not deleted or retried and may still be running. Inspect retained Jobs and results before any further action.'
        code = 130
    except Exception as exc:
        summary['status'] = 'launcher_or_infrastructure_failure'
        summary['error'] = type(exc).__name__ + ': ' + str(exc)
        summary['active_jobs_note'] = 'Submitted Jobs are retained and may still be running; no cancellation or retry was performed.'
    finally:
        summary['finished_at_utc'] = now()
        summary['exit_code'] = code
        summary['sampled_resource_peaks'] = client.sampled_peaks
        summary['resource_metrics_scope'] = 'Samples may miss peaks; absent metrics are unavailable, not zero usage.'
        if args.output and args.output.resolve() != (shared / 'final_summary.json').resolve():
            try:
                write_json(args.output, summary)
            except Exception as exc:
                summary['additional_summary_copy_error'] = type(exc).__name__ + ': ' + str(exc)
        write_json(shared / 'final_summary.json', summary)
        print(json.dumps(summary, indent=2, allow_nan=False), flush=True)
    return code


def main():
    p = render_jobs.parser()
    p.description = __doc__
    p.add_argument('--results-host', type=Path, required=True,
                   help='Existing operator-host mount of the same RWX PVC mounted at /results in pods')
    p.add_argument('--kubectl', default='kubectl', help='Path to kubectl executable')
    # Retain the shared renderer CLI, but clarify this option's launcher meaning.
    for action in p._actions:
        if action.dest == 'output':
            action.help = 'Optional additional final-summary JSON; must not already exist'
    args = p.parse_args()
    try:
        return run(args)
    except Exception as exc:
        print('Launcher stopped: {}: {}. Existing Jobs and evidence are never deleted or retried.'.format(
              type(exc).__name__, exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())

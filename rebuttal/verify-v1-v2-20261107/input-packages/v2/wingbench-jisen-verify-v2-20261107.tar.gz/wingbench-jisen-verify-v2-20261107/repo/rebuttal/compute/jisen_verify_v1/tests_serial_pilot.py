"""Local algebra/gating/control-flow tests. No real CFD or MPI job is run."""
from pathlib import Path
import ast
import copy
import importlib.util
import json
import sys
import tempfile
import types

import numpy as np

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('serial_pilot',HERE/'serial_pilot.py')
pilot=importlib.util.module_from_spec(spec);spec.loader.exec_module(pilot)


def fixtures(checks,refs):
    from rebuttal.adjoint.geometry import directions
    expected_sources={name:pilot.sha256(pilot.ROOT/'rebuttal/adjoint'/name)
                      for name in ('check_refined.py','geometry.py')}
    for mach,ref in enumerate(refs):
        leaf=checks/'mach_{}'.format(mach);leaf.mkdir(parents=True)
        initial=np.r_[np.zeros(38),float(ref['realized_aoa_deg'])]
        value=np.array([float(ref['cl']),float(ref['cd'])])
        gradient=np.array([[.001*(i+1) for i in range(39)],[.00001*(i+1) for i in range(39)]])
        def call(y,label,values):return {'call':len(calls)+1,'label':label,'input':y.tolist(),
            'cl':float(values[0]),'cd':float(values[1]),'solve_failed':False,'relative_residual':1e-13}
        calls=[];calls.append(call(initial,'anchor',value));checks_rows=[]
        for name in ('airfoil','twist','mixed_all_coordinates_and_alpha'):
            direction=directions()[name];predicted=gradient@direction
            for step in (.002,.001):
                pair=[]
                for sign,label in ((1,'plus'),(-1,'minus')):
                    y=initial+sign*step*direction;values=value+sign*step*predicted
                    pair.append(values);calls.append(call(y,'{}_{}_{}'.format(name,label,step),values))
                measured=(pair[0]-pair[1])/(2*step)
                allowed=.02*np.maximum(np.abs(predicted),np.abs(measured))+np.array([2e-5,2e-6])
                checks_rows.append({'direction':name,'step':step,'predicted':predicted.tolist(),
                    'measured':measured.tolist(),'allowed_error':allowed.tolist(),'passed':True})
        native=[{'function':f,'rhs_norm':1.,'starting_residual_norm':1.,'final_residual_norm':1e-13,
                 'relative_residual':1e-13,'failed':False,'qualified':True} for f in ('cl','cd')]
        docs={'completed.json':{'passed':True,'checks':checks_rows,'forward_calls':13,'adjoint_calls':2},
            'setup.json':{'mach_index':mach,'reference':ref,'code_sha256':expected_sources,
                'adjoint_true_relative_residual_gate':1.1e-11,'forward_tolerance':1e-12,'adjoint_tolerance':1e-12},
            'gradient.json':{'input':initial.tolist(),'values':value.tolist(),'gradient_cl_cd':gradient.tolist()},
            'adjoint_calls.json':native,'forward_calls.json':calls,'reproduction.json':{'passed':True}}
        for name,data in docs.items():pilot.write_json(leaf/name,data)


def main():
    cases=[]
    # Compare against the original function itself, extracted without imports.
    source=ast.parse((pilot.ROOT/'rebuttal/adjoint/pilot_refined.py').read_text())
    node=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='aggregate')
    namespace={'np':np};exec(compile(ast.Module(body=[node],type_ignores=[]),'original_aggregate','exec'),namespace)
    rng=np.random.default_rng(230912)
    values=np.column_stack((rng.uniform(.38,.44,3),rng.uniform(.015,.025,3)))
    gradients=rng.normal(size=(3,2,41))*.001
    for derivative in (None,gradients):
        expected=namespace['aggregate'](values,derivative);actual=pilot.aggregate(values,derivative)
        for a,e in zip(actual,expected):assert np.array_equal(a,e)
    cases.append('objective_constraint_and_gradient_bitwise_equal_to_original_algebra')

    class Box:
        sd=np.ones(38)
        def to_standardized(self,x):return np.asarray(x)
        def contains(self,x):return bool(np.all(np.abs(x)<=3.5))
    geometry=np.zeros(38);geometry[:2]=[3.48,-3.48]
    row={'geometry':geometry.tolist()};refs=[{'realized_aoa_deg':a} for a in (-9.8,7.,24.8)]
    initial,bounds=pilot.make_bounds(row,refs,Box())
    assert bounds[0]==(-.1,3.5-3.48) and bounds[1]==(-3.5+3.48,.1)
    assert bounds[38:]==[(-10.,-9.3),(6.5,7.5),(24.3,25.)]
    cases.append('same_normalized_physical_and_alpha_bounds')

    log=[]
    class Eval:
        def __init__(self,k):self.k,self.last_y=k,None
        def forward(self,y,label):
            log.append(('forward',self.k));self.last_y=y.copy()
            return np.array([.41+.02*y[38]+.001*np.sum(y[:38]),.02+.0001*self.k+.0002*np.dot(y[:38],y[:38])])
        def gradient(self,y,values):
            log.append(('gradient',self.k));assert np.array_equal(y,self.last_y)
            g=np.zeros((2,39));g[0,:38]=.001;g[0,38]=.02;g[1,:38]=.0004*y[:38]
            return g
    evaluators=[Eval(k) for k in range(3)];x=rng.normal(size=41)*.02
    val=pilot.execute_serial(evaluators,{'op':'forward','x':x.tolist(),'call':1})
    grad=pilot.execute_serial(evaluators,{'op':'gradient','x':x.tolist(),'values':val.tolist()})
    assert log==[('forward',0),('forward',1),('forward',2),('gradient',0),('gradient',1),('gradient',2)]
    for k in range(3):
        assert grad[k,0,38+k]==.02
        assert np.count_nonzero(grad[k,:,38:])==1
    derivative=pilot.aggregate(val,grad)[0]
    for k in (0,17,37,38,39,40):
        d=np.zeros(41);d[k]=1e-6
        plus=pilot.execute_serial(evaluators,{'op':'forward','x':(x+d).tolist(),'call':2})
        minus=pilot.execute_serial(evaluators,{'op':'forward','x':(x-d).tolist(),'call':3})
        finite=(pilot.aggregate(plus)[0]-pilot.aggregate(minus)[0])/(2e-6)
        assert abs(finite-derivative[k])<1e-8
    cases.append('sequential_mach_order_independent_histories_and_39_to_41_embedding')
    cases.append('joint_objective_gradient_matches_synthetic_finite_differences')

    from rebuttal.adjoint.check_refined import control
    _,real_refs=control()
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary);checks=root/'checks';fixtures(checks,real_refs)
        # A new host certificate is always recomputed from raw evidence; its
        # stored boolean alone cannot qualify anything or override a stale hash.
        host_checks=root/'host'/'qualification';host_checks.mkdir(parents=True)
        certificate=host_checks/'certificate.json'
        manifest=json.loads((pilot.ROOT/'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json').read_text())
        mesh=root/'frozen_mesh.cgns';mesh.write_text('mock only')
        package=root/'package.json';package.write_text('{}')
        runtime={'sha256':{'adflow_library':'c'*64}}
        valid={'strict_host_qualification_passed':True,
               'evidence_sha256':{'coverage/anchor_0/coverage_result.json':'a'*64},
               'protocol_sha256':'b'*64,'coverage_summary':{'comparison_count':18},
               'mesh_sha256':manifest['mesh']['sha256'],'mesh_container_path':manifest['mesh']['container_path'],
               'runtime_expected_sha256':runtime['sha256'],'package_manifest_sha256':pilot.sha256(package)}
        preflight=root/'pilot_preflight.json'
        pilot.write_json(preflight,{'passed':True,'requested_ranks':16,
            'ranks':[{'hardware':{'hostname':pilot.socket.gethostname()}} for _ in range(16)],
            'provenance':{'package_manifest':str(package),'package_manifest_sha256':pilot.sha256(package),
                          'protocol_sha256':'b'*64,'runtime':runtime}})
        actual=copy.deepcopy(valid);invocations=[]
        def certify(shared,emit=False):
            invocations.append((shared,emit));return copy.deepcopy(actual)
        old_certifier=pilot.host_certifier
        old_runtime,old_sha=pilot.pilot_runtime_record,pilot.sha256
        reported_mesh=manifest['mesh']['sha256']
        pilot.sha256=lambda p:reported_mesh if Path(p)==mesh else old_sha(p)
        pilot.pilot_runtime_record=lambda:copy.deepcopy(runtime)
        pilot.host_certifier=lambda:types.SimpleNamespace(certify=certify)
        def certificate_blocked():
            try:pilot.qualification_evidence(host_checks,real_refs,mesh,preflight)
            except pilot.QualificationBlocked:return
            raise AssertionError('Invalid/newly mutated host evidence released pilot')
        try:
            pilot.write_json(certificate,valid)
            record=pilot.qualification_evidence(host_checks,real_refs,mesh,preflight)
            assert record['kind']=='strict_new_host_certification'
            assert record['strict_host_qualification_passed'] is True
            assert invocations==[(host_checks.parent,False)]
            cases.append('new_host_certificate_recomputed_from_shared_parent_without_emit')
            wrong=copy.deepcopy(valid);wrong['evidence_sha256']={'wrong':'c'*64}
            pilot.write_json(certificate,wrong);certificate_blocked()
            cases.append('wrong_certificate_evidence_hash_rejected')
            wrong=copy.deepcopy(valid);wrong['protocol_sha256']='d'*64
            pilot.write_json(certificate,wrong);certificate_blocked()
            cases.append('wrong_certificate_protocol_hash_rejected')
            pilot.write_json(certificate,valid)
            actual['evidence_sha256']['coverage/anchor_0/coverage_result.json']='e'*64
            certificate_blocked()
            cases.append('post_certification_raw_evidence_mutation_rejected')
            actual=copy.deepcopy(valid);actual['strict_host_qualification_passed']=False
            certificate_blocked()
            cases.append('fresh_strict_native_failure_rejected_despite_saved_pass')
            actual=copy.deepcopy(valid)
            pilot.write_json(certificate,{'strict_host_qualification_passed':True});certificate_blocked()
            cases.append('certificate_boolean_without_hashes_rejected')
            wrong=copy.deepcopy(valid);wrong['strict_host_qualification_passed']=False
            pilot.write_json(certificate,wrong);certificate_blocked()
            cases.append('saved_failed_certificate_requires_explicit_fresh_certification')
            pilot.write_json(certificate,valid)
            reported_mesh='f'*64;certificate_blocked();reported_mesh=manifest['mesh']['sha256']
            cases.append('actual_mesh_hash_mismatch_rejected')
            runtime['sha256']['adflow_library']='f'*64;certificate_blocked()
            runtime['sha256']['adflow_library']='c'*64
            cases.append('installed_runtime_mutation_rejected_before_evaluator')
            package.write_text('{"changed":true}');certificate_blocked()
            cases.append('installed_package_manifest_mutation_rejected')
        finally:
            pilot.host_certifier=old_certifier;pilot.pilot_runtime_record=old_runtime;pilot.sha256=old_sha
        assert len(pilot.qualification_evidence(checks,real_refs))==3
        cases.append('valid_strict_qualification_fixture_accepted')
        p=checks/'mach_1/adjoint_calls.json';original=json.loads(p.read_text());bad=copy.deepcopy(original)
        bad[0].update(final_residual_norm=3e-11,relative_residual=3e-11,qualified=False);pilot.write_json(p,bad)
        try:pilot.qualification_evidence(checks,real_refs)
        except pilot.QualificationBlocked:pass
        else:raise AssertionError('Strict native gate bypass')
        cases.append('current_native_residual_floor_blocks_even_if_completed_passed_true')
        # Actual main preflight must return2 before constructing any Evaluator.
        import rebuttal.adjoint.check_refined as refined
        old_eval=refined.Evaluator;old_mpi=sys.modules.get('mpi4py')
        refined.Evaluator=lambda *a,**k:(_ for _ in ()).throw(AssertionError('Evaluator created despite gate failure'))
        comm=types.SimpleNamespace(size=16,rank=0,bcast=lambda value,root=0:value)
        sys.modules['mpi4py']=types.SimpleNamespace(MPI=types.SimpleNamespace(COMM_WORLD=comm))
        try:
            code=pilot.main(types.SimpleNamespace(dry_run=False,out=root/'blocked',checks=checks,
                mesh=root/'unused_mesh.cgns',requested_memory_gib=288.))
            assert code==2
            status=json.loads((root/'blocked/pilot_status.json').read_text())
            assert not status['optimizer_started'] and status['evaluators_created']==0
        finally:
            refined.Evaluator=old_eval
            if old_mpi is None:sys.modules.pop('mpi4py',None)
            else:sys.modules['mpi4py']=old_mpi
        cases.append('real_preflight_exit2_before_solver_or_optimizer')
        pilot.write_json(p,original)
        p=checks/'mach_0/setup.json';original=json.loads(p.read_text());bad=copy.deepcopy(original)
        bad['diagnostic_only']=True;pilot.write_json(p,bad)
        try:pilot.qualification_evidence(checks,real_refs)
        except pilot.QualificationBlocked:pass
        else:raise AssertionError('Observational qualification bypass')
        cases.append('observational_reports_cannot_release_pilot')
        pilot.write_json(p,original)
        bad=copy.deepcopy(original);bad['adjoint_true_relative_residual_gate']=1.1e-9;pilot.write_json(p,bad)
        try:pilot.qualification_evidence(checks,real_refs)
        except pilot.QualificationBlocked:pass
        else:raise AssertionError('Old v1 native criterion accepted')
        cases.append('old_looser_native_gate_rejected')
        pilot.write_json(p,original)
        # Budget exhaustion is integration completion, never convergence.
        count={'forward':0};zero=np.zeros(41);bounds=[(-.1,.1)]*41
        def rpc(command):
            assert command['op']=='forward';count['forward']+=1
            return np.tile([.41,.02],(3,1))
        def force_budget(fun,x0,**kwargs):
            assert kwargs['options']['maxiter']==4 and kwargs['options']['ftol']==1e-6
            for i in range(11):
                x=x0.copy();x[0]=i*.001;fun(x)
            raise AssertionError('Forward budget not enforced')
        budget=root/'budget';budget.mkdir()
        outcome=pilot.optimize(rpc,zero,bounds,{'geometry':[0.]*38},Box(),budget,force_budget,dry_run=True)
        assert count['forward']==10 and outcome['joint_forward_evaluations']==10
        assert outcome['individual_condition_forwards']==30 and not outcome['optimization']['success']
        assert not (budget/'recommendation.json').exists()
        cases.append('max10_joint_forwards_enforced_and_not_convergence')
        # Propagate strict runtime derivative errors, never switch to observed gradients.
        def fail_gradient(command):
            if command['op']=='gradient':raise RuntimeError('native residual3e-11 exceeds1.1e-11')
            return np.tile([.41,.02],(3,1))
        def need_gradient(fun,x0,**kwargs):fun(x0);kwargs['jac'](x0)
        failed=root/'failed';failed.mkdir()
        try:pilot.optimize(fail_gradient,zero,bounds,{'geometry':[0.]*38},Box(),failed,need_gradient)
        except RuntimeError:pass
        else:raise AssertionError('Runtime native gate bypass')
        assert not (failed/'recommendation.json').exists()
        cases.append('runtime_strict_gradient_failure_propagates_no_recommendation')
        code=pilot.cli(['--dry-run','--out',str(root/'dry'),'--requested-memory-gib','288'])
        assert code==0 and (root/'dry/mock_result.json').exists() and not (root/'dry/recommendation.json').exists()
        plan=json.loads((root/'dry/plan.json').read_text())
        assert not plan['real_CFD'] and not plan['qualification_passed'] and not plan['memory_sufficiency_confirmed']
        assert pilot.cli(['--dry-run','--out',str(root/'dry')])==3
        cases.append('dryrun_exit0_mock_only_and_existing_output_exit3')
    print(json.dumps({'scope':'Synthetic local tests only; no real CFD, MPI job, hardware memory validation or qualification',
        'passed_cases':len(cases),'all_passed':True,'cases':cases,
        'source_sha256':{p.name:pilot.sha256(p) for p in (HERE/'serial_pilot.py',Path(__file__).resolve())}},indent=2))


if __name__=='__main__':main()

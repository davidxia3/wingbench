"""Independent prospective-v2 audit of all39 fresh qualification jobs.

Original reports are never changed or reused as v2 jobs. A successful certificate
can release only the bounded pilot; production still needs pilot and regrade.
"""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import json
import math
import sys

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OLD_MANIFEST = 'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json'
OLD_SHA = '52dc6c65fb29582c25108b78fd14536577cc8c02c0c2daa27ef5cebab7b927ee'
JOB_SCHEMA = 'wingbench-adjoint-qualification-job-v2'
NAMES = ('airfoil', 'twist', 'mixed_all_coordinates_and_alpha')
FORWARD_GATE, NATIVE_GATE = 1.1e-12, 1.1e-9


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4*1024*1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def finite(value):
    if isinstance(value, float): return math.isfinite(value)
    if isinstance(value, dict): return all(finite(v) for v in value.values())
    if isinstance(value, list): return all(finite(v) for v in value)
    return True


def require(condition, message):
    if not condition: raise ValueError(message)


def number(value):
    return type(value) in (int, float) and math.isfinite(value)


def timestamp(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None, 'Timestamp has no timezone')
    return result.timestamp()


def certify(root, manifest_path, manifest_sha256=None, emit=False):
    root, manifest_path = Path(root).resolve(), Path(manifest_path).resolve()
    files, errors, missing, failed_jobs, comparisons, native_finals = {}, [], [], [], [], []
    valid = {'anchor': {}, 'point': {}}
    runtime_signature, manifest, protocol_hash = None, {}, None

    def read(path):
        path = Path(path)
        try:
            raw = path.read_bytes()
            value = json.loads(raw)
            require(finite(value), 'Nonfinite JSON numbers')
            try: key = str(path.relative_to(root))
            except ValueError:
                try: key = 'source/'+str(path.relative_to(ROOT))
                except ValueError: key = 'external/'+str(path)
            files[key] = hashlib.sha256(raw).hexdigest()
            return value
        except FileNotFoundError:
            missing.append(str(path)); return None
        except (OSError, ValueError, TypeError) as exc:
            errors.append('{}: {}'.format(path, exc)); return None

    def source_path(relative):
        path = Path(relative)
        require(not path.is_absolute() and '..' not in path.parts, 'Unsafe source path')
        return ROOT/path

    manifest = read(manifest_path)
    actual_manifest_hash = sha(manifest_path) if manifest_path.is_file() else None
    try:
        require(isinstance(manifest, dict), 'Missing v2 manifest')
        require(manifest_sha256 is not None and actual_manifest_hash == manifest_sha256,
                'Explicit frozen v2 manifest hash is required and must match')
        require(manifest['schema'] == 'wingbench-adjoint-qualification-v2', 'Not a prospective v2 manifest')
        require(manifest['ranks'] == 16 and manifest['anchor_jobs'] == 3
                and manifest['cold_point_jobs'] == 36, 'Job/rank contract changed')
        require(manifest['forward_target'] == 1e-12 and manifest['forward_gate'] == FORWARD_GATE
                and manifest['native_target'] == 1e-12 and manifest['native_gate'] == NATIVE_GATE
                and manifest['max_native_attempts'] == 3 and manifest['reference_relative_gate'] == .005,
                'Numerical criteria differ from approved v2')
        require(manifest['directional_rule'] == {'relative':.02,'absolute_cl':2e-5,'absolute_cd':2e-6},
                'Directional comparison criteria changed')
        require(sha(ROOT/OLD_MANIFEST) == OLD_SHA, 'Frozen original point specification changed')
        original = read(ROOT/OLD_MANIFEST)
        for key in ('geometry','normalization_scales','directions','anchors','points','mesh'):
            require(manifest[key] == original[key], 'Original scientific specification changed: '+key)
        require(len(manifest['anchors']) == 3 and len(manifest['points']) == 36,
                'Incomplete point specification')
        sources = manifest['source_sha256']
        required_sources = ('protocol.json','evaluator.py','worker.py','build_manifest.py','certify.py','run_process.py')
        for name in required_sources:
            require('rebuttal/adjoint/qualification_v2/'+name in sources, 'Missing v2 source pin: '+name)
        for relative, digest in sources.items():
            path = source_path(relative)
            require(isinstance(digest, str) and len(digest) == 64 and sha(path) == digest,
                    'Frozen source hash mismatch: '+relative)
            files['source/'+relative] = digest
        protocol_path = source_path(manifest['protocol']['path'])
        require(protocol_path == ROOT/'rebuttal/adjoint/qualification_v2/protocol.json',
                'Unexpected v2 protocol path')
        protocol_hash = sha(protocol_path)
        require(protocol_hash == manifest['protocol']['sha256'], 'V2 protocol hash mismatch')
        protocol = read(protocol_path)
        original_protocol = read(ROOT/'rebuttal/compute/jisen_verify_v1/numerical_protocol.json')
        expected_method = dict(original_protocol['method'],native_adjoint_relative_gate=NATIVE_GATE)
        require(protocol['schema'] == 'wingbench-adjoint-numerical-freeze-v2'
                and protocol['method'] == expected_method,
                'V2 changed a method field beyond approved native acceptance')
        require(protocol['method']['native_adjoint_relative_gate'] == NATIVE_GATE
                and protocol['method']['adjoint_internal_target'] == 1e-12
                and protocol['method']['primal_relative_gate'] == FORWARD_GATE
                and protocol['method']['primal_target'] == 1e-12,
                'Protocol numerical criteria mismatch')
        package = read(ROOT/'rebuttal/compute/jisen_verify_v1/package_manifest.json')
        require(manifest['expected_runtime_sha256'] == package['runtime_expected_sha256']
                and len(manifest['expected_runtime_sha256']) == 9, 'Full frozen runtime mapping changed')
        created = timestamp(manifest['created_at_utc'])
    except (KeyError, TypeError, ValueError, OSError, IndexError) as exc:
        errors.append('Manifest: '+str(exc)); created = None

    if not errors and not missing:
        for mode, specs in (('anchor',manifest['anchors']),('point',manifest['points'])):
            for index, spec in enumerate(specs):
                leaf = root/('{}_{}'.format(mode,index))
                job, meta, setup, calls, process = [read(leaf/name) for name in
                    ('coverage_result.json','coverage_metadata.json','setup.json','forward_calls.json','process.json')]
                if any(doc is None for doc in (job,meta,setup,calls,process)): continue
                try:
                    for doc in (job,meta):
                        require(doc['schema'] == JOB_SCHEMA and doc['mode'] == mode and doc['index'] == index
                                and doc['spec'] == spec and doc['manifest_sha256'] == actual_manifest_hash
                                and doc['protocol_sha256'] == protocol_hash,
                                'Job identity/protocol/manifest differs')
                        require(doc.get('qualification_completed') is False and doc.get('can_release_pilot') is False
                                and doc.get('diagnostic_only') is not True, 'Wrong v1/v2 release flags')
                    require(job['coverage_job_completed'] is True and job['job_passed'] is True,
                            'Fresh v2 job did not pass')
                    require(meta['ranks'] == 16 and meta['forward_gate'] == FORWARD_GATE
                            and meta['native_gate'] == NATIVE_GATE, 'Worker numerical criteria changed')
                    require(meta['mesh_sha256'] == manifest['mesh']['sha256']
                            and meta['source_sha256'] == manifest['source_sha256']
                            and meta['code_sha256'] == manifest['source_sha256'], 'Source/mesh provenance differs')
                    hashes = meta['runtime']['sha256']
                    require(hashes == manifest['expected_runtime_sha256'], 'Runtime pin set differs')
                    if runtime_signature is None: runtime_signature = hashes
                    require(hashes == runtime_signature, 'Runtime differs across jobs')
                    require(timestamp(meta['created_at_utc']) >= created, 'Worker evidence predates frozen v2 manifest')
                    require(process['mode'] == mode and process['index'] == index
                            and process['manifest_sha256'] == actual_manifest_hash
                            and process['return_code'] == 0 and process['timed_out'] is False,
                            'External process did not finish the declared fresh v2 job')
                    require(number(process['wall_seconds']) and process['wall_seconds'] >= 0
                            and timestamp(process['started_at_utc']) >= created,
                            'Invalid/future-vs-process timing')
                    if 'finished_at_utc' in process:
                        require(timestamp(process['finished_at_utc']) >= timestamp(meta['created_at_utc']),
                                'Process finished before worker metadata was recorded')
                    command = process['command']
                    require(isinstance(command, list) and any(str(c).endswith('/qualification_v2/worker.py') for c in command),
                            'Process did not invoke the new v2 worker')
                    for flag, expected in (('--mode',mode),('--index',str(index)),('--manifest-sha256',actual_manifest_hash)):
                        require(flag in command and command[command.index(flag)+1] == expected,
                                'Process arguments differ: '+flag)
                    if meta.get('slurm_job_id') is not None:
                        require(str(process.get('slurm_job_id')) == str(meta['slurm_job_id']),
                                'External process and worker Slurm identity differ')
                    require(setup['schema'] == 'wingbench-adjoint-evaluator-v2'
                            and setup['mach_index'] == spec['mach_index'] and setup['ranks'] == 16
                            and setup['geometry'] == manifest['geometry']
                            and setup['reference'] == manifest['anchors'][spec['mach_index']]['reference']
                            and setup['forward_tolerance'] == 1e-12 and setup['adjoint_tolerance'] == 1e-12
                            and setup['forward_relative_residual_gate'] == FORWARD_GATE
                            and setup['adjoint_true_relative_residual_gate'] == NATIVE_GATE,
                            'Evaluator setup differs from manifest/v2 numerics')
                    require(job['forward_calls'] == 1 and len(calls) == 1 and calls[0] == job['forward'],
                            'Exactly one fresh cold forward required')
                    forward = job['forward']
                    label = 'anchor' if mode == 'anchor' else spec['label']
                    require(forward['call'] == 1 and forward['input'] == spec['input'] and forward['label'] == label
                            and forward['solve_failed'] is False and forward['qualified'] is True
                            and forward['forward_gate'] == FORWARD_GATE, 'Forward identity/gate changed')
                    values, norms = job['values'], job['forward_norms']
                    require(len(values) == 2 and all(number(v) for v in values)
                            and values == [forward['cl'],forward['cd']], 'Forward coefficients differ')
                    require(len(norms) == 3 and all(number(v) for v in norms)
                            and norms[0] > 0 and min(norms[1:]) >= 0
                            and norms[-1]/norms[0] <= FORWARD_GATE
                            and forward['relative_residual'] == norms[-1]/norms[0]
                            and forward['raw_norms'] == norms, 'Strict finite forward residual gate failed')
                    require(forward['finite_flags'] == {'norms':True,'values':True}, 'Forward finite flags disagree')
                    if mode == 'point':
                        require(job['gradient_usable'] is False and job['native_attempts'] == []
                                and job['native_finals'] == [] and job['failed_native_gates'] == [],
                                'Cold point ran adjoints or claims a gradient')
                    else:
                        gradient = job['gradient_cl_cd']
                        require(job['gradient_usable'] is True and len(gradient) == 2
                                and all(len(g) == 39 and all(number(v) for v in g) for g in gradient),
                                'Finite CL/CD gradients missing')
                        reference = [float(spec['reference'][k]) for k in ('cl','cd')]
                        relative = [abs(v-r)/abs(r) for v,r in zip(values,reference)]
                        reproduction = read(leaf/'reproduction.json')
                        require(reproduction == job['reproduction'] and reproduction['values'] == values
                                and reproduction['reference'] == reference and reproduction['relative_errors'] == relative
                                and reproduction['within_reference_limit'] is True and all(v <= .005 for v in relative),
                                'Reference reproduction failed or report differs')
                        attempts = read(leaf/'native_attempts.json')
                        finals = read(leaf/'native_finals.json')
                        require(attempts == job['native_attempts'] and finals == job['native_finals'],
                                'Raw native attempts/finals differ from job result')
                        expected_finals, flat = [], []
                        for function in ('cl','cd'):
                            rows = [r for r in attempts if r['function'] == function]
                            require(1 <= len(rows) <= 3, 'Wrong bounded native attempt count')
                            for n, item in enumerate(rows,1):
                                require(item['attempt'] == n and item['solver_failed'] is False and item['failed'] is False
                                        and item['native_gate'] == NATIVE_GATE and item['strict_native_gate'] == NATIVE_GATE
                                        and item['finite_norms'] is True, 'Native attempt solver/settings/finite failure')
                                nums = [item[k] for k in ('rhs_norm','starting_residual_norm','final_residual_norm')]
                                require(all(number(v) and v >= 0 for v in nums) and nums[0] > 0
                                        and item['relative_residual'] == nums[2]/nums[0], 'Native norm/normalization mismatch')
                                require(item['qualified'] is (nums[2]/nums[0] <= NATIVE_GATE), 'Native acceptance relabeled')
                                require(n == len(rows) or item['qualified'] is False, 'Refinement continued after passing')
                            require(rows[-1]['qualified'] is True, 'Final native residual fails approved v2')
                            expected_finals.append(rows[-1]); flat.extend(rows)
                        require(flat == attempts and expected_finals == finals and job['failed_native_gates'] == [],
                                'Native order/final/failure accounting differs')
                        native_finals.extend(dict(item,mach_index=spec['mach_index']) for item in finals)
                    valid[mode][index] = job
                except (KeyError, TypeError, ValueError, OSError, IndexError, ZeroDivisionError) as exc:
                    failed_jobs.append({'mode':mode,'index':index,'error':str(exc)})

        for mach in range(3):
            anchor = valid['anchor'].get(mach)
            if anchor is None: continue
            for name in NAMES:
                direction = manifest['directions'][name]
                predicted = [math.fsum(v*d for v,d in zip(g,direction)) for g in anchor['gradient_cl_cd']]
                for step in (.002,.001):
                    specs = [p for p in manifest['points'] if p['mach_index'] == mach
                             and p['direction'] == name and p['step'] == step]
                    plus = valid['point'].get(next(p['point_index'] for p in specs if p['sign'] == 1))
                    minus = valid['point'].get(next(p['point_index'] for p in specs if p['sign'] == -1))
                    if plus is None or minus is None: continue
                    measured = [(p-m)/(2*step) for p,m in zip(plus['values'],minus['values'])]
                    error = [abs(p-m) for p,m in zip(predicted,measured)]
                    allowed = [.02*max(abs(p),abs(m))+floor for p,m,floor in zip(predicted,measured,(2e-5,2e-6))]
                    components = [number(e) and number(a) and e <= a for e,a in zip(error,allowed)]
                    comparisons.append({'mach_index':mach,'direction':name,'step':step,
                        'predicted_cl_cd':predicted,'measured_cl_cd':measured,
                        'absolute_error_cl_cd':error,'allowed_error_cl_cd':allowed,
                        'components_passed':components,'passed':all(components)})

    passed = bool(not errors and not missing and not failed_jobs
                  and len(valid['anchor']) == 3 and len(valid['point']) == 36
                  and len(native_finals) == 6 and len(comparisons) == 18
                  and all(c['passed'] for c in comparisons))
    result = {'schema':'wingbench-adjoint-qualification-certificate-v2',
        'passed':passed,'qualification_passed':passed,'can_release_pilot':passed,
        'can_release_campaign':False,'status':'passed' if passed else 'blocked',
        'manifest_sha256':actual_manifest_hash,'protocol_sha256':protocol_hash,
        'mesh_sha256':manifest.get('mesh',{}).get('sha256') if isinstance(manifest,dict) else None,
        'runtime_expected_sha256':manifest.get('expected_runtime_sha256') if isinstance(manifest,dict) else None,
        'runtime_observed_sha256':runtime_signature,'files_sha256':files,'evidence_sha256':canonical(files),
        'missing':missing,'errors':errors,'failed_jobs':failed_jobs,
        'valid_anchor_jobs':len(valid['anchor']),'valid_point_jobs':len(valid['point']),
        'native_final_count':len(native_finals),'native_finals':native_finals,
        'comparison_count':len(comparisons),'scalar_comparison_count':2*len(comparisons),
        'comparisons':comparisons,'native_gate':NATIVE_GATE,'forward_gate':FORWARD_GATE,
        'interpretation':'Prospective v2 evidence only. Old strict failures remain failed. Passing permits only bounded integration testing, not production or competitive claims.'}
    if emit:
        output = root/'certificate.json'
        temporary = output.with_suffix('.tmp')
        temporary.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
        temporary.replace(output)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--output',type=Path)
    args = parser.parse_args()
    result = certify(args.root,args.manifest,args.manifest_sha256,emit=args.output is None)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'passed':result['passed'],'valid_anchors':result['valid_anchor_jobs'],
                      'valid_points':result['valid_point_jobs'],'comparisons':result['comparison_count'],
                      'errors':result['errors'],'missing_count':len(result['missing'])},indent=2))
    return 0 if result['passed'] else 2


if __name__=='__main__':sys.exit(main())

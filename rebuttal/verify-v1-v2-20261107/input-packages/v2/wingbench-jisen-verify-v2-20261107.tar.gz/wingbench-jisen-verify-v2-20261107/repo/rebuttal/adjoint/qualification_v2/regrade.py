"""Independent original-grader check of a successfully audited v2 pilot."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import sys

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition,message):
    if not condition:raise ValueError(message)


def number(value):
    return type(value) in (int,float) and math.isfinite(value)


def close(a,b):
    return number(a) and number(b) and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)


def argument(command,flag):
    require(command.count(flag)==1 and command.index(flag)+1<len(command),'Missing/duplicate process argument: '+flag)
    return command[command.index(flag)+1]


def audit_trace(args,manifest,fresh):
    """Independent replay of saved trace algebra; no optimizer/CFD calls.

    Requiring at least two distinct evaluated trials is an integration-coverage
    check: a one-point run does not demonstrate an optimizer update. It changes
    neither the flow physics nor any frozen convergence/eligibility threshold.
    """
    from benchmark.common import load_box
    def read(path):return json.loads(Path(path).read_text())
    status=read(args.pilot/'pilot_status.json');process=read(args.pilot/'process.json')
    plan=read(args.pilot/'plan.json');rec=read(args.pilot/'recommendation.json')
    history=read(args.pilot/'history.json');stored=read(args.checks/'certificate.json')
    require(status.get('status')=='integration_pilot_finished' and status.get('exit_code')==0,
            'Pilot did not finish successfully')
    require(process.get('schema')=='wingbench-adjoint-integration-process-v2' and process.get('mode')=='pilot'
            and process.get('return_code')==0 and process.get('timed_out') is False
            and process.get('manifest_sha256')==args.manifest_sha256,'Pilot process identity/completion differs')
    command=process.get('command',[])
    require(isinstance(command,list) and all(isinstance(x,str) for x in command) and
            sum(x.endswith('/qualification_v2/serial_pilot.py') for x in command)==1 and
            '--dry-run' not in command and argument(command,'-np')=='16', 'Wrong pilot executable/ranks')
    require(argument(command,'--manifest-sha256')==args.manifest_sha256 and
            sha(Path(argument(command,'--manifest')))==args.manifest_sha256,'Pilot command manifest differs')
    require(Path(argument(command,'--out')).resolve()==args.pilot.resolve() and
            Path(argument(command,'--checks')).resolve()==args.checks.resolve(), 'Pilot command output/check paths differ')
    require(argument(command,'--mesh')==manifest['mesh']['container_path'],'Pilot command mesh differs')
    require(plan.get('dry_run') is False and plan.get('max_iterations')==4 and
            plan.get('max_joint_forward_evaluations')==10 and plan.get('mpi_ranks')==16 and
            plan.get('mach_execution_order')==[0,1,2] and plan.get('resident_evaluators')==3 and
            plan.get('strict_native_gate')==1.1e-9 and plan.get('forward_gate')==1.1e-12 and
            plan.get('lift_equalities')==[.41]*3 and plan.get('mesh_sha256')==manifest['mesh']['sha256'],
            'Pilot plan limits, mesh or numerical gates differ')
    required_sources=('serial_pilot.py','evaluator.py','protocol.json','run_integration.py','regrade.py')
    for name in required_sources:
        require('rebuttal/adjoint/qualification_v2/'+name in manifest['source_sha256'], 'Missing pilot source pin: '+name)
    for name in ('serial_pilot.py','evaluator.py','protocol.json'):
        path='rebuttal/adjoint/qualification_v2/'+name
        require(plan['source_sha256'].get(path)==manifest['source_sha256'][path],'Pilot plan source differs: '+name)
    for path,digest in plan['source_sha256'].items():
        require(manifest['source_sha256'].get(path)==digest,'Unpinned/different pilot plan source: '+path)
    evidence=plan['qualification']['evidence']
    require(plan['qualification']['allowed'] is True and evidence.get('can_release_pilot') is True and
            evidence.get('kind')=='fresh_v2_raw_qualification','Pilot qualification was not authorized')
    for key in ('evidence_sha256','manifest_sha256','protocol_sha256'):
        require(evidence.get(key)==fresh.get(key)==stored.get(key),'Qualification evidence changed: '+key)
    require(stored.get('can_release_pilot') is True and
            evidence.get('certificate_sha256')==sha(args.checks/'certificate.json') and
            Path(evidence['certificate_path']).resolve()==(args.checks/'certificate.json').resolve() and
            evidence.get('actual_mesh_sha256')==manifest['mesh']['sha256'] and
            evidence.get('actual_runtime_sha256')==manifest['expected_runtime_sha256'],
            'Pilot certificate/runtime/mesh provenance differs')
    require(rec.get('dry_run') is False and rec.get('competitive_baseline_result') is False and
            isinstance(history,list) and 2<=len(history)<=10 and
            rec.get('joint_forward_evaluations')==len(history) and
            rec.get('individual_condition_forwards')==3*len(history), 'Real pilot requires2..10 recorded joint trials')
    box=load_box();geometry=manifest['geometry']['geometry'];scales=manifest['normalization_scales']
    require(list(box.sd)==scales,'Pilot normalization differs')
    z0=box.to_standardized(geometry)
    alphas=[float(a['reference']['realized_aoa_deg']) for a in manifest['anchors']]
    bounds=[[max(-.1,-3.5-z),min(.1,3.5-z)] for z in z0]+[[max(-10.,a-.5),min(25.,a+.5)] for a in alphas]
    require(plan['bounds']==bounds,'Pilot bounds differ from frozen control/global intersection')
    require(history[0]['x']==[0.]*38+alphas,'Pilot first trial is not its frozen anchor')
    for item in history:
        x=item['x'];values=item['cl_cd']
        require(len(x)==41 and all(number(v) for v in x) and
                all(lo<=v<=hi for v,(lo,hi) in zip(x,bounds)), 'Pilot trial violates finite41-vector/bounds')
        require(len(values)==3 and all(len(pair)==2 and all(number(v) and v>0 for v in pair) for pair in values),
                'Pilot trial lacks finite positive CL/CD')
        ratios=[cl/cd for cl,cd in values];score=math.exp(sum(math.log(v) for v in ratios)/3)
        lift=max(abs(cl-.41) for cl,cd in values)
        eligible=lift<=.001 and all(0<ld<=40 for ld in ratios)
        require(close(item['score'],score) and close(item['max_lift_error'],lift) and item['eligible'] is eligible,
                'Pilot score/lift/eligibility differs from recorded coefficients')
    require(len({tuple(row['x']) for row in history})>=2,'Pilot did not evaluate two distinct trial vectors')
    eligible=[row for row in history if row['eligible']]
    require(bool(eligible),'Pilot has no eligible recommendation')
    selected=max(eligible,key=lambda row:row['score'])
    require(rec['warped_mesh_result']==selected,'Recommendation is not best eligible recorded history row')
    expected_geometry=[g+s*z for g,s,z in zip(geometry,scales,selected['x'][:38])]
    require(len(rec['geometry'])==38 and all(close(a,b) for a,b in zip(rec['geometry'],expected_geometry)) and
            box.contains(rec['geometry']) and close(rec['initial_score'],history[0]['score']),
            'Recommendation geometry/initial score differs from recorded trial')
    optimization=rec['optimization']
    require(type(optimization.get('success')) is bool and status.get('optimizer_success') is optimization['success'],
            'Optimizer success reporting differs')
    if 'iterations' in optimization:
        require(type(optimization['iterations']) is int and 0<=optimization['iterations']<=4,'SLSQP iteration limit exceeded')
    else:
        require(optimization['success'] is False and optimization.get('message')=='Diagnostic forward budget reached' and len(history)==10,
                'Missing iteration count without exhausted bounded forward budget')
    counts=[]
    for mach in range(3):
        leaf=args.pilot/('mach_'+str(mach));forwards=read(leaf/'forward_calls.json')
        attempts=read(leaf/'native_attempts.json');finals=read(leaf/'native_finals.json')
        setup=read(leaf/'setup.json')
        require(setup['schema']=='wingbench-adjoint-evaluator-v2' and setup['mach_index']==mach and
                setup['ranks']==16 and setup['geometry']==manifest['geometry'] and
                setup['reference']==manifest['anchors'][mach]['reference'] and
                setup['forward_tolerance']==1e-12 and setup['adjoint_tolerance']==1e-12 and
                setup['forward_relative_residual_gate']==1.1e-12 and
                setup['adjoint_true_relative_residual_gate']==1.1e-9,'Pilot evaluator setup differs')
        require(len(forwards)==len(history),'Pilot forward count differs from history')
        for index,(row,item) in enumerate(zip(forwards,history),1):
            require(row['call']==index and row['label']=='pilot_'+str(index) and
                    row['input']==item['x'][:38]+[item['x'][38+mach]] and
                    [row['cl'],row['cd']]==item['cl_cd'][mach], 'Pilot Mach forward identity/values differ from joint trial')
            norms=row['raw_norms']
            require(len(norms)==3 and all(number(v) for v in norms) and norms[0]>0 and min(norms[1:])>=0 and
                    norms[-1]/norms[0]<=1.1e-12 and row['relative_residual']==norms[-1]/norms[0] and
                    row['qualified'] is True and row['solve_failed'] is False and row['forward_gate']==1.1e-12 and
                    row['finite_flags']=={'norms':True,'values':True},'Pilot raw forward convergence failed')
        require(2<=len(finals)<=2*len(history) and len(finals)%2==0,'Pilot adjoint count is inconsistent')
        position=0
        for index,final in enumerate(finals):
            function=('cl','cd')[index%2];rows=[]
            while position<len(attempts):
                row=attempts[position];position+=1;rows.append(row)
                require(row['function']==function and row['attempt']==len(rows)<=3,
                        'Pilot native sequence/refinement bound differs')
                norms=[row[k] for k in ('rhs_norm','starting_residual_norm','final_residual_norm')]
                require(all(number(v) for v in norms) and norms[0]>0 and min(norms[1:])>=0 and
                        row['relative_residual']==norms[-1]/norms[0] and row['failed'] is False and
                        row['solver_failed'] is False and row['finite_norms'] is True and
                        row['native_gate']==1.1e-9 and row['strict_native_gate']==1.1e-9,
                        'Pilot native raw residual/settings/flags invalid')
                accepted=norms[-1]/norms[0]<=1.1e-9
                require(row['qualified'] is accepted,'Pilot native acceptance was relabeled')
                if accepted:break
            require(bool(rows) and rows[-1]==final and final['qualified'] is True,
                    'Pilot native final differs from bounded accepted attempt')
        require(position==len(attempts),'Pilot has unaccounted native attempts')
        require(read(leaf/'adjoint_calls.json')==finals,'Pilot adjoint final files disagree')
        counts.append(len(finals)//2)
    require(len(set(counts))==1,'Three Mach solvers received different gradient call counts')
    return {'joint_trials':len(history),'gradient_calls_per_mach':counts[0],
            'integration_coverage_note':'At least two distinct trials required to demonstrate optimizer integration; no numerical gate changed.'}


def audit_pilot(args):
    from rebuttal.adjoint.qualification_v2.certify import certify
    if sha(args.manifest)!=args.manifest_sha256:
        raise ValueError('Manifest external pin differs')
    manifest=json.loads(args.manifest.read_text())
    for path,digest in manifest['source_sha256'].items():
        relative=Path(path)
        if relative.is_absolute() or '..' in relative.parts or sha(ROOT/relative)!=digest:
            raise ValueError('Frozen source differs: '+path)
    if str(Path(__file__).resolve().relative_to(ROOT)) not in manifest['source_sha256']:
        raise ValueError('Regrade bridge is not pinned')
    fresh=certify(args.checks,args.manifest,manifest_sha256=args.manifest_sha256,emit=False)
    if fresh.get('can_release_pilot') is not True:
        raise ValueError('Fresh qualification no longer passes')
    trace=audit_trace(args,manifest,fresh)
    rec=json.loads((args.pilot/'recommendation.json').read_text())
    return {'manifest_sha256':args.manifest_sha256,'qualification_evidence_sha256':fresh['evidence_sha256'],
        'recommendation_sha256':sha(args.pilot/'recommendation.json'),
        'pilot_process_sha256':sha(args.pilot/'process.json'),'passed':True,
        'optimizer_converged':rec['optimization']['success'],'competitive_baseline_result':False,
        'trace_audit':trace}


def main(args):
    # Audit before the original grader initializes or any extra CFD is incurred.
    audit=audit_pilot(args)
    module_path=ROOT/'rebuttal/compute/jisen_verify_v1/run_grade.py'
    spec=importlib.util.spec_from_file_location('original_frozen_grade',str(module_path))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    result=module.main(argparse.Namespace(out=args.out,pilot=args.pilot))
    (args.out/'v2_pilot_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('manifest','checks','pilot','out'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--manifest-sha256',required=True)
    sys.exit(main(p.parse_args()))

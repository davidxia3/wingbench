"""Freeze a prospective v2 qualification; preserve every frozen v1 source."""
from pathlib import Path
import argparse
import copy
from datetime import datetime,timezone
import hashlib
import json

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json'
PACKAGE=ROOT/'rebuttal/compute/jisen_verify_v1/package_manifest.json'


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def build(protocol_path,extras=()):
    base=json.loads(BASE.read_text());package=json.loads(PACKAGE.read_text())
    sources=dict(package['source_sha256'])
    sources[str(PACKAGE.relative_to(ROOT))]=sha(PACKAGE)
    for relative,expected in sources.items():
        if sha(ROOT/relative)!=expected:raise ValueError('Frozen v1 source differs: '+relative)
    protocol=json.loads(protocol_path.read_text())
    if (protocol['method']['native_adjoint_relative_gate']!=1.1e-9 or
            protocol['method']['adjoint_internal_target']!=1e-12 or
            protocol['method']['primal_target']!=1e-12 or protocol['method']['primal_relative_gate']!=1.1e-12 or
            protocol['method']['max_native_attempts_per_function']!=3):
        raise ValueError('Protocol does not match approved v2 numerical settings')
    owned=['evaluator.py','worker.py','run_process.py','build_manifest.py','anchors.sbatch','points.sbatch','certify.py']
    for name in owned:
        if not (HERE/name).is_file():raise ValueError('Required v2 source is missing: '+name)
    files=[path for path in HERE.iterdir() if path.suffix in ('.py','.json','.sbatch') and
           not (path.suffix=='.json' and ('manifest' in path.stem or 'release' in path.stem))]
    for path in files+[protocol_path]+[ROOT/name for name in extras]:
        resolved=path.resolve()
        if ROOT.resolve() not in resolved.parents:raise ValueError('Source outside repository')
        sources[str(resolved.relative_to(ROOT))]=sha(resolved)
    result=copy.deepcopy(base)
    result.update(schema='wingbench-adjoint-qualification-v2',diagnostic_only=False,
        phase='fresh_qualification_only',qualification_completed=False,can_release_pilot=False,
        created_at_utc=datetime.now(timezone.utc).isoformat(),
        purpose='Fresh prospective v2 qualification; independent certification required before pilot',
        native_gate=1.1e-9,source_sha256=sources,
        expected_runtime_sha256=package['runtime_expected_sha256'],
        protocol={'path':str(protocol_path.resolve().relative_to(ROOT)),'sha256':sha(protocol_path)},
        parent_coverage={'path':str(BASE.relative_to(ROOT)),'sha256':sha(BASE)},
        numerical_change={'authorized_native_gate':{'old':1.1e-11,'new':1.1e-9},
                          'finite_value_guards':'Explicit rejection of nonfinite residuals, values and gradients'},
        native_policy='Same bounded evalFunctionsSens refinements and internal1e-12 target; every accepted function must meet native1.1e-9 within at most3 attempts. A gate miss aborts that anchor; no diagnostic-gradient bypass.',
        historical_evidence='All v1 results and failed gates remain unchanged. None of the39 required v2 jobs may reuse old results.',
        limitations='Three directions do not verify every coordinate. Passing39jobs requires independent audit and does not by itself authorize optimization.')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--extra',action='append',default=[])
    args=parser.parse_args();result=build(args.protocol,args.extra)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x') as stream:stream.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'manifest':str(args.output),'sha256':sha(args.output),'source_files':len(result['source_sha256'])}))

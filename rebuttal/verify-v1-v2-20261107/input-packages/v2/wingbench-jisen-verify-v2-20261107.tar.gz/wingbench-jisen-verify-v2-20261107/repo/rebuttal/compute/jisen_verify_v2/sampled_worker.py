"""Wrap one immutable verification worker with observational memory sampling."""
from pathlib import Path
import argparse
import sys
from resource_sampler import run
HERE=Path(__file__).resolve().parent
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--shared',type=Path,required=True)
 p.add_argument('--worker-id',type=int,required=True);p.add_argument('--node',required=True)
 p.add_argument('--mode',choices=['worker','pilot','regrade'],default='worker')
 args=p.parse_args()
 path=args.shared/'resource_samples'/('{}-{}.jsonl'.format(args.mode,args.worker_id))
 sys.exit(run(path,[sys.executable,str(HERE/'worker.py')]+sys.argv[1:]))

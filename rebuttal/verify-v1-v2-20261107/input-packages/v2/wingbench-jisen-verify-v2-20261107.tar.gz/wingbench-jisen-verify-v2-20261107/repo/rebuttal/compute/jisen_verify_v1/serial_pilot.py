"""Strict-gated, 16-rank sequential three-Mach SLSQP integration pilot.

The algebra and limits match rebuttal/adjoint/pilot_refined.py. Three independent
Evaluator instances remain resident on the same communicator; Mach conditions
execute sequentially. This reduces rank count, NOT a verified memory reduction.
Dry runs use synthetic coefficients and never produce a recommendation file.
Exit codes: 0 integration/dry-run finished (not optimizer convergence),
2 missing/failed qualification or CLI usage, 3 execution failure.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import os
import resource
import socket
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
NATIVE_GATE = 1.1e-11
FORWARD_GATE = 1.1e-12
MAX_ITERATIONS = 4
MAX_JOINT_FORWARDS = 10


def write_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def aggregate(values, gradients=None):
    """Exactly the objective/constraint algebra used by pilot_refined."""
    values = np.asarray(values)
    if np.any(values <= 0) or not np.isfinite(values).all():
        raise ValueError('Nonpositive or nonfinite aerodynamic coefficients')
    objective = -np.mean(np.log(values[:, 0] / values[:, 1]))
    constraints = values[:, 0] - .41
    if gradients is None:
        return float(objective), constraints
    gradients = np.asarray(gradients)
    obj_grad = -np.mean(gradients[:, 0] / values[:, 0, None]
                       - gradients[:, 1] / values[:, 1, None], axis=0)
    return obj_grad, gradients[:, 0]


def make_bounds(row, refs, box):
    initial = np.r_[np.zeros(38), [float(r['realized_aoa_deg']) for r in refs]]
    z0 = np.asarray(box.to_standardized(row['geometry']))
    lower = np.maximum(-.1, -3.5-z0)
    upper = np.minimum(.1, 3.5-z0)
    bounds = list(zip(lower, upper)) + [(max(-10., a-.5), min(25., a+.5)) for a in initial[38:]]
    return initial, bounds


def embed_gradient(local, mach):
    local = np.asarray(local, dtype=float)
    if local.shape != (2, 39) or not np.isfinite(local).all():
        raise ValueError('Invalid per-Mach derivative')
    result = np.zeros((2, 41))
    result[:, :38] = local[:, :38]
    result[:, 38+mach] = local[:, 38]
    return result


def execute_serial(evaluators, command):
    """All 16 ranks call each condition in the same order; no summed replicas."""
    x = np.asarray(command['x'], dtype=float)
    if x.shape != (41,) or not np.isfinite(x).all() or len(evaluators) != 3:
        raise ValueError('Invalid joint command')
    results = []
    for mach, evaluator in enumerate(evaluators):
        y = np.r_[x[:38], x[38+mach]]
        if command['op'] == 'forward':
            result = evaluator.forward(y, 'pilot_{}'.format(command['call']))
        elif command['op'] == 'gradient':
            # Strict Evaluator.gradient raises if the native gate is missed.
            result = embed_gradient(evaluator.gradient(y, np.asarray(command['values'][mach])), mach)
        else:
            raise ValueError('Unknown command')
        results.append(result)
    return np.asarray(results)


class QualificationBlocked(RuntimeError):
    pass


def package_module(name):
    """Load the named package source, never an unrelated sys.path module."""
    path = Path(__file__).resolve().with_name(name+'.py')
    spec = importlib.util.spec_from_file_location('jisen_'+name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def host_certifier():
    return package_module('certify')


def pilot_runtime_record():
    return package_module('preflight').runtime_record()


def qualification_evidence(checks, refs, mesh=None, preflight_report=None):
    """Require actual strict reports, not observational coverage or v1 gates."""
    certificate = checks/'certificate.json'
    if certificate.is_file():
        try:
            stored = json.loads(certificate.read_text())
            fresh = host_certifier().certify(checks.parent, emit=False)
            if (stored.get('strict_host_qualification_passed') is not True or
                    fresh.get('strict_host_qualification_passed') is not True):
                raise ValueError('New-host raw evidence does not satisfy every strict qualification gate')
            for key in ('evidence_sha256', 'protocol_sha256'):
                if not stored.get(key) or stored[key] != fresh.get(key):
                    raise ValueError('New-host certificate is missing or stale: {}'.format(key))
            for key in ('mesh_sha256','mesh_container_path','runtime_expected_sha256','package_manifest_sha256'):
                if not fresh.get(key) or stored.get(key)!=fresh[key]:
                    raise ValueError('Missing or changed new-host provenance: '+key)
            manifest=json.loads((ROOT/'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json').read_text())
            if (mesh is None or sha256(mesh)!=fresh['mesh_sha256'] or
                    fresh['mesh_sha256']!=manifest['mesh']['sha256'] or
                    fresh['mesh_container_path']!=manifest['mesh']['container_path']):
                raise ValueError('Actual pilot mesh differs from certified frozen mesh')
            if preflight_report is None:
                raise ValueError('A fresh pilot-pod --preflight-report is required')
            pre=json.loads(preflight_report.read_text()); provenance=pre['provenance']
            if (pre.get('passed') is not True or pre.get('requested_ranks')!=16 or
                    len(pre.get('ranks',[]))!=16 or
                    any(r['hardware']['hostname']!=socket.gethostname() for r in pre['ranks']) or
                    provenance['package_manifest_sha256']!=fresh['package_manifest_sha256'] or
                    sha256(Path(provenance['package_manifest']))!=fresh['package_manifest_sha256'] or
                    provenance.get('protocol_sha256')!=fresh['protocol_sha256']):
                raise ValueError('Pilot preflight host/package/protocol differs from certification')
            current=pilot_runtime_record()
            if current['sha256']!=provenance['runtime']['sha256']:
                raise ValueError('Installed runtime changed since pilot preflight')
            for key,digest in fresh['runtime_expected_sha256'].items():
                if current['sha256'].get(key)!=digest:
                    raise ValueError('Pilot runtime differs from certified pin: '+key)
            return {'kind':'strict_new_host_certification',
                    'certificate_path':str(certificate),
                    'certificate_sha256':sha256(certificate),
                    'certifier_sha256':sha256(Path(__file__).resolve().with_name('certify.py')),
                    'strict_host_qualification_passed':True,
                    'evidence_sha256':fresh['evidence_sha256'],
                    'protocol_sha256':fresh['protocol_sha256'],
                    'actual_mesh_sha256':sha256(mesh),
                    'pilot_preflight_sha256':sha256(preflight_report),
                    'actual_runtime_sha256':current['sha256'],
                    'package_manifest_sha256':fresh['package_manifest_sha256'],
                    'coverage_summary':fresh.get('coverage_summary'),
                    'interpretation':'Fresh strict certification of this host batch; old observational records are not relabeled.'}
        except (OSError, ImportError, KeyError, TypeError, ValueError, RuntimeError) as exc:
            raise QualificationBlocked('New-host certification: {}'.format(exc)) from exc
    from rebuttal.adjoint.geometry import directions
    expected_sources = {name: sha256(ROOT/'rebuttal/adjoint'/name)
                        for name in ('check_refined.py', 'geometry.py')}
    evidence = []
    required = ('completed.json', 'setup.json', 'gradient.json', 'adjoint_calls.json',
                'forward_calls.json', 'reproduction.json')
    for mach in range(3):
        leaf = checks/'mach_{}'.format(mach)
        try:
            docs = {name: json.loads((leaf/name).read_text()) for name in required}
            complete, setup = docs['completed.json'], docs['setup.json']
            if complete.get('passed') is not True or len(complete.get('checks', [])) != 6:
                raise ValueError('Six successful directional reports required')
            if setup.get('diagnostic_only') or setup.get('is_adjoint_qualification') is False:
                raise ValueError('Observational evidence cannot qualify the pilot')
            if (setup.get('adjoint_true_relative_residual_gate') != NATIVE_GATE or
                    setup.get('forward_tolerance') != 1e-12 or setup.get('adjoint_tolerance') != 1e-12):
                raise ValueError('Qualification did not use the unchanged strict numerical gates')
            if setup.get('mach_index') != mach or setup.get('reference') != refs[mach]:
                raise ValueError('Qualification reference/Mach mismatch')
            if setup.get('code_sha256') != expected_sources:
                raise ValueError('Qualification geometry/evaluator source differs from this pilot')
            native = docs['adjoint_calls.json']
            if len(native) != 2 or [n['function'] for n in native] != ['cl', 'cd']:
                raise ValueError('Both final CL/CD native reports required')
            for row in native:
                numbers = [row[k] for k in ('rhs_norm', 'starting_residual_norm', 'final_residual_norm', 'relative_residual')]
                if (not all(math.isfinite(v) for v in numbers) or numbers[0] <= 0 or
                        min(numbers[1:]) < 0 or row['failed'] is not False or row.get('qualified') is not True or
                        numbers[2]/numbers[0] > NATIVE_GATE or numbers[3] != numbers[2]/numbers[0]):
                    raise ValueError('Native CL/CD residual remains unqualified')
            calls = docs['forward_calls.json']
            if len(calls) != 13 or complete.get('forward_calls') != 13 or complete.get('adjoint_calls') != 2:
                raise ValueError('Original anchor plus twelve endpoints required')
            for call in calls:
                if (call['solve_failed'] is not False or not math.isfinite(call['relative_residual']) or
                        not 0 <= call['relative_residual'] <= FORWARD_GATE or
                        not all(math.isfinite(call[k]) for k in ('cl','cd'))):
                    raise ValueError('Strict forward gate failed')
            grad = docs['gradient.json']
            matrix = np.asarray(grad['gradient_cl_cd'], dtype=float)
            initial = np.r_[np.zeros(38), float(refs[mach]['realized_aoa_deg'])]
            if matrix.shape != (2,39) or not np.isfinite(matrix).all() or grad['input'] != initial.tolist():
                raise ValueError('Invalid anchor gradient')
            if calls[0]['label'] != 'anchor' or calls[0]['input'] != initial.tolist():
                raise ValueError('Invalid anchor forward record')
            values = np.array([calls[0]['cl'], calls[0]['cd']])
            reference = np.array([float(refs[mach]['cl']), float(refs[mach]['cd'])])
            if grad['values'] != values.tolist() or np.any(np.abs(values-reference)/np.abs(reference) > .005):
                raise ValueError('Reference reproduction failed')
            if docs['reproduction.json'].get('passed') is not True:
                raise ValueError('Reference reproduction report is not successful')
            seen = set()
            for check in complete['checks']:
                name, step = check['direction'], check['step']
                if (name,step) in seen or name not in directions() or step not in (.002,.001):
                    raise ValueError('Directional coverage changed')
                seen.add((name,step))
                vector = directions()[name]
                pair = []
                for sign, label in ((1,'plus'),(-1,'minus')):
                    label = '{}_{}_{}'.format(name,label,step)
                    matching = [c for c in calls if c['label']==label]
                    if len(matching)!=1 or matching[0]['input']!=(initial+sign*step*vector).tolist():
                        raise ValueError('Directional endpoint input mismatch')
                    pair.append(np.array([matching[0]['cl'],matching[0]['cd']]))
                predicted, measured = matrix@vector, (pair[0]-pair[1])/(2*step)
                allowed = .02*np.maximum(np.abs(predicted),np.abs(measured))+np.array([2e-5,2e-6])
                # Report consistency only: allow near-roundoff BLAS/FMA differences.
                # The scientific pass test below uses freshly recomputed values,
                # without adding this metadata tolerance to the directional gate.
                if (check['passed'] is not True or
                        not np.allclose(check['predicted'],predicted,rtol=1e-12,atol=1e-14) or
                        not np.allclose(check['measured'],measured,rtol=1e-12,atol=1e-14) or
                        not np.allclose(check['allowed_error'],allowed,rtol=1e-12,atol=1e-14) or
                        np.any(np.abs(predicted-measured)>allowed)):
                    raise ValueError('Original directional tolerance not satisfied')
            evidence.append({'mach_index':mach,'files_sha256':{name:sha256(leaf/name) for name in required},
                             'strict_native_residuals':[n['relative_residual'] for n in native]})
        except (OSError, KeyError, TypeError, ValueError) as exc:
            raise QualificationBlocked('Mach {}: {}'.format(mach,exc)) from exc
    return evidence


def memory_record(comm, stage):
    highwater = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    highwater_bytes = int(highwater if sys.platform == 'darwin' else highwater*1024)
    return {'stage':stage,'per_rank_process_highwater_bytes':comm.gather(highwater_bytes,root=0),
            'interpretation':'Process RSS high-water, not Slurm node peak; shared mappings may be counted repeatedly. No memory-sufficiency claim.'}


def optimize(rpc, initial, bounds, row, box, out, minimize_fn, dry_run=False):
    """Rank-zero optimizer, same cache/budget/eligibility as parallel pilot."""
    started, history, cache = time.time(), [], {}
    class BudgetReached(Exception):
        pass
    def values(x):
        if 'x' not in cache or not np.array_equal(x,cache['x']):
            if len(history)>=MAX_JOINT_FORWARDS:
                raise BudgetReached()
            val=rpc({'op':'forward','x':x.tolist(),'call':len(history)+1})
            cache.clear();cache.update(x=x.copy(),values=val)
            obj,con=aggregate(val)
            history.append({'x':x.tolist(),'cl_cd':val.tolist(),'score':float(np.exp(-obj)),
                'max_lift_error':float(np.max(np.abs(con))),
                'eligible':bool(np.max(np.abs(con))<=.001 and np.all((val[:,0]/val[:,1]>0)&(val[:,0]/val[:,1]<=40))),
                'elapsed_seconds':time.time()-started})
            write_json(out/('mock_history.json' if dry_run else 'history.json'),history)
        return cache['values']
    def derivatives(x):
        val=values(x)
        if 'gradient' not in cache:
            cache['gradient']=rpc({'op':'gradient','x':x.tolist(),'values':val.tolist()})
        return aggregate(val,cache['gradient'])
    try:
        result=minimize_fn(lambda x:aggregate(values(x))[0],initial,
            jac=lambda x:derivatives(x)[0],method='SLSQP',bounds=bounds,
            constraints={'type':'eq','fun':lambda x:aggregate(values(x))[1],
                         'jac':lambda x:derivatives(x)[1]},
            options={'maxiter':MAX_ITERATIONS,'ftol':1e-6,'disp':True})
        status={'success':bool(result.success),'message':str(result.message),
                'status':int(result.status),'iterations':int(result.nit)}
    except BudgetReached:
        status={'success':False,'message':'Diagnostic forward budget reached'}
    eligible=[r for r in history if r['eligible']]
    if not eligible:
        raise RuntimeError('No eligible recommendation from pilot')
    best=max(eligible,key=lambda r:r['score'])
    geometry=(np.asarray(row['geometry'])+np.asarray(box.sd)*np.asarray(best['x'][:38])).tolist()
    if not box.contains(geometry):
        raise RuntimeError('Recommendation outside frozen physical design box')
    record={'geometry':geometry,'optimization':status,'warped_mesh_result':best,
        'initial_score':history[0]['score'],'joint_forward_evaluations':len(history),
        'individual_condition_forwards':3*len(history),'wall_seconds':time.time()-started,
        'dry_run':dry_run,'competitive_baseline_result':False,
        'interpretation':'Requires independent original-grader evaluation. Iteration limit is not convergence.'}
    write_json(out/('mock_result.json' if dry_run else 'recommendation.json'),record)
    return record


def dry_run(out, requested_memory_gib=None):
    """Local synthetic harness. No qualification, ADflow imports or real design."""
    from scipy.optimize import minimize
    out.mkdir(parents=True,exist_ok=False)
    class Box:
        sd=np.ones(38)
        def to_standardized(self,x):return np.asarray(x)
        def contains(self,x):return bool(np.all(np.abs(x)<=3.5))
    class MockEvaluator:
        def __init__(self,mach):self.mach,self.last_y=mach,None
        def forward(self,y,label):
            self.last_y=y.copy()
            return np.array([.41+.02*y[38], .02+.001*np.sum((y[:38]-.02)**2)+.0001*self.mach])
        def gradient(self,y,values):
            if self.last_y is None or not np.array_equal(y,self.last_y):raise RuntimeError('Mock state mismatch')
            g=np.zeros((2,39));g[0,38]=.02;g[1,:38]=.002*(y[:38]-.02)
            return g
    box=Box();row={'geometry':[0.]*38};refs=[{'realized_aoa_deg':0.}]*3
    initial,bounds=make_bounds(row,refs,box)
    write_json(out/'plan.json',{'dry_run':True,'real_CFD':False,'qualification_passed':False,
        'requested_memory_gib':requested_memory_gib,'memory_sufficiency_confirmed':False,
        'purpose':'Synthetic algebra/control-flow smoke only; does not unlock real pilot',
        'max_iterations':4,'max_joint_forward_evaluations':10,'bounds':bounds})
    evaluators=[MockEvaluator(i) for i in range(3)]
    optimize(lambda command:execute_serial(evaluators,command),initial,bounds,row,box,out,minimize,dry_run=True)
    return 0


def main(args):
    args._created_output=False
    if args.dry_run:
        return dry_run(args.out,args.requested_memory_gib)
    from mpi4py import MPI
    from scipy.optimize import minimize
    from benchmark.common import load_box
    from rebuttal.adjoint.check_refined import Evaluator, control
    world=MPI.COMM_WORLD
    if world.size!=16:
        raise ValueError('Real serial pilot requires exactly 16 MPI ranks')
    row,refs=control();box=load_box();initial,bounds=make_bounds(row,refs,box)
    gate=None
    if world.rank==0:
        args.out.mkdir(parents=True,exist_ok=False)
        args._created_output=True
        try:
            gate={'allowed':True,'evidence':qualification_evidence(args.checks,refs,args.mesh,
                getattr(args,'preflight_report',None))}
        except QualificationBlocked as exc:
            gate={'allowed':False,'error':str(exc)}
        write_json(args.out/'plan.json',{
            'purpose':'Strict-gated bounded integration pilot; not a benchmark episode',
            'dry_run':False,'method':'SLSQP, strict ADflow coupled adjoints and IDWarp',
            'geometry_variables':38,'internal_alpha_variables':3,
            'objective':'negative mean log(CL/CD)','lift_equalities':[.41]*3,
            'bounds':bounds,'max_iterations':4,'max_joint_forward_evaluations':10,
            'mpi_ranks':16,'mach_execution_order':[0,1,2],'resident_evaluators':3,
            'requested_memory_gib':args.requested_memory_gib,'memory_sufficiency_confirmed':False,
            'memory_note':'Three independent solvers remain resident. The separate288GiB pilot allocation is unverified capacity, not a memory guarantee. Measure scheduler/node peak before estimating concurrent adjoint episodes;96GiB worker load tests do not validate this pilot footprint.',
            'derivative_reports':str(args.checks),'strict_native_gate':NATIVE_GATE,
            'forward_gate':FORWARD_GATE,'qualification':gate,
            'warm_start_CFD_labels':'Known-pass diagnostic control; not zero-information initialization',
            'source_sha256':{str(p.relative_to(ROOT)):sha256(p) for p in
                [Path(__file__).resolve(),ROOT/'rebuttal/adjoint/check_refined.py',
                 ROOT/'rebuttal/adjoint/geometry.py',ROOT/'rebuttal/adjoint/pilot_refined.py']},
            'mesh_sha256':sha256(args.mesh) if args.mesh.is_file() else None})
    gate=world.bcast(gate,root=0)
    if not gate['allowed']:
        if world.rank==0:
            write_json(args.out/'pilot_status.json',{'status':'blocked_by_qualification',
                'exit_code':2,'error':gate['error'],'optimizer_started':False,'evaluators_created':0})
        return 2
    evaluators,memory=[],[]
    for mach in range(3):
        point_out=args.out/'mach_{}'.format(mach)
        if world.rank==0:point_out.mkdir()
        world.barrier()
        evaluators.append(Evaluator(world,args.mesh,point_out,mach))
        memory.append(memory_record(world,'after_evaluator_{}'.format(mach)))
        if world.rank==0:write_json(args.out/'memory_observations.json',memory)
    if len({id(e.solver.adflow) for e in evaluators})!=3:
        raise RuntimeError('Three independent ADflow module instances required')
    def execute(command):
        result=execute_serial(evaluators,command)
        memory.append(memory_record(world,'{}_{}'.format(command['op'],command.get('call','cached'))))
        if world.rank==0:write_json(args.out/'memory_observations.json',memory)
        return result
    if world.rank:
        while True:
            command=world.bcast(None,root=0)
            if command['op']=='stop':return 0
            execute(command)
    else:
        def rpc(command):
            world.bcast(command,root=0)
            return execute(command)
        result=optimize(rpc,initial,bounds,row,box,args.out,minimize)
        write_json(args.out/'pilot_status.json',{'status':'integration_pilot_finished',
            'exit_code':0,'optimizer_success':result['optimization']['success'],
            'requires_independent_regrade':True,'competitive_baseline_result':False})
        world.bcast({'op':'stop'},root=0)
        return 0


def cli(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mesh',type=Path)
    parser.add_argument('--checks',type=Path)
    parser.add_argument('--preflight-report',type=Path,
                        help='Fresh pilot-pod preflight, required for new-host certificate path')
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--requested-memory-gib',type=float,default=288.)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args(argv)
    if not math.isfinite(args.requested_memory_gib) or args.requested_memory_gib<=0:
        parser.error('--requested-memory-gib must be finite and positive')
    if not args.dry_run and (args.mesh is None or args.checks is None):
        parser.error('--mesh and --checks are required for a real pilot')
    try:
        return main(args)
    except BaseException as exc:
        if args.dry_run:
            print('Dry-run failed: {}'.format(exc),file=sys.stderr)
            return 3
        import traceback
        traceback.print_exc()
        from mpi4py import MPI
        if MPI.COMM_WORLD.rank==0 and getattr(args,'_created_output',False):
            write_json(args.out/'pilot_status.json',{'status':'execution_failed','exit_code':3,
                'error_type':type(exc).__name__,'error':str(exc),'competitive_baseline_result':False})
        MPI.COMM_WORLD.Abort(3)
        return 3


if __name__=='__main__':
    sys.exit(cli())

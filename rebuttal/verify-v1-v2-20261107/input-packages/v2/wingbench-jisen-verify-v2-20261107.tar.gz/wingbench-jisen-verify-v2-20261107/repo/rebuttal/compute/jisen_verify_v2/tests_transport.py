import copy,importlib.util,json,subprocess,sys,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import render_jobs,resource_sampler

class TransportTests(unittest.TestCase):
 def args(self,extra=()):
  return render_jobs.parser().parse_args(['--image','registry/test@sha256:'+'a'*64,'--pvc','rwx','--node-a','node-a','--node-b','node-b','--run-id','wb-test']+list(extra))
 def test_requested_taint_all_phases(self):
  a=self.args(['--toleration','capacity.together.ai/pool=single-node-only:NoSchedule'])
  expected=[{'key':'capacity.together.ai/pool','operator':'Equal','value':'single-node-only','effect':'NoSchedule'}]
  for phase,count in [('workers',8),('pilot',1),('regrade',1)]:
   a.phase=phase;result=render_jobs.render(a);self.assertEqual(len(result['items']),count)
   for j in result['items']:
    spec=j['spec']['template']['spec'];self.assertEqual(spec['tolerations'],expected)
    self.assertFalse(spec['automountServiceAccountToken']);self.assertEqual(j['spec']['backoffLimit'],0)
 def test_no_default_toleration(self):
  self.assertNotIn('tolerations',render_jobs.render(self.args())['items'][0]['spec']['template']['spec'])
 def test_only_pod_toleration_changes(self):
  a=self.args();before=render_jobs.render(a);a.toleration=['capacity.together.ai/pool=single-node-only:NoSchedule'];after=render_jobs.render(a)
  for j in after['items']:del j['spec']['template']['spec']['tolerations']
  self.assertEqual(before,after)
 def test_repeated_option(self):
  a=self.args(['--toleration','one=x:NoSchedule','--toleration','two=y:NoExecute'])
  self.assertEqual(len(render_jobs.render(a)['items'][0]['spec']['template']['spec']['tolerations']),2)
 def test_invalid_tolerations(self):
  for bad in ['x','x=y:Bad','a/b/c=x:NoSchedule','UPPER.com/key=x:NoSchedule','a='+'z'*64+':NoSchedule','a/=x:NoSchedule','=x:NoSchedule','x=y:NoSchedule:10']:
   with self.subTest(bad=bad),self.assertRaises(ValueError):render_jobs.parse_tolerations([bad])
 def test_duplicate_refused(self):
  with self.assertRaises(ValueError):render_jobs.parse_tolerations(['x=y:NoSchedule']*2)
 def test_launcher_accepts_option_without_run(self):
  result=subprocess.run([sys.executable,str(HERE/'launch.py'),'--help'],capture_output=True,text=True)
  self.assertEqual(result.returncode,0,result.stderr);self.assertIn('--toleration',result.stdout)
 def test_samples_not_peak(self):
  samples=[{'cgroups':[{'path':'a','values':{'memory.current':'10','memory.peak':'100'}}]}, {'cgroups':[{'path':'a','values':{'memory.current':'20'}}]}]
  result=resource_sampler.summarize(samples);self.assertEqual(result['max_sampled_memory_current_bytes_by_cgroup'],{'a':20})
  self.assertIn('lower bounds',result['scope'])
 def test_missing_memory_not_zero(self):
  r=resource_sampler.summarize([{'cgroups':[]}]);self.assertFalse(r['memory_samples_available']);self.assertEqual(r['max_sampled_memory_current_bytes_by_cgroup'],{})
 def test_raw_oom_preserved(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'memory.events').write_text('oom 1\noom_kill 1\n');(p/'memory.current').write_text('13')
   self.assertIn('oom_kill 1',resource_sampler.snapshot([p])['cgroups'][0]['values']['memory.events'])
 def test_child_failure_preserved(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'samples.jsonl';self.assertEqual(resource_sampler.run(p,[sys.executable,'-c','raise SystemExit(7)']),7)
   s=json.loads(p.with_suffix('.summary.json').read_text());self.assertEqual(s['child_return_code'],7);self.assertEqual(s['sample_count'],2)
   with self.assertRaises(FileExistsError):resource_sampler.run(p,[sys.executable,'-c','raise SystemExit(0)'])

if __name__=='__main__':unittest.main()

"""Read-only summary of observational coverage. Missing/failed jobs are explicit.

This never writes qualification artifacts, releases optimization, or substitutes
derivative agreement for the separately required native-residual gate.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math

FLAGS = {'diagnostic_only': True, 'qualification_completed': False, 'can_release_pilot': False}
NAMES = ('airfoil', 'twist', 'mixed_all_coordinates_and_alpha')


def finite_json(value):
    if isinstance(value, float):
        return math.isfinite(value)
    if isinstance(value, dict):
        return all(finite_json(v) for v in value.values())
    if isinstance(value, list):
        return all(finite_json(v) for v in value)
    return True


def summarize(root, manifest_path):
    missing, errors, failures, evidence, failed_native = [], [], [], {}, []
    valid = {'anchor': {}, 'point': {}}
    runtime_signature = None

    def read(path):
        try:
            raw = path.read_bytes()
            value = json.loads(raw)
            if not finite_json(value):
                raise ValueError('Nonfinite JSON number')
            evidence[str(path)] = hashlib.sha256(raw).hexdigest()
            return value
        except FileNotFoundError:
            missing.append(str(path))
        except (OSError, ValueError) as exc:
            errors.append('{}: {}'.format(path, exc))
        return None

    def require(condition, text):
        if not condition:
            raise ValueError(text)

    manifest = read(manifest_path)
    result = dict(FLAGS, summary_status='incomplete', comparisons=[],
        missing=missing, evidence_errors=errors, failed_jobs=failures,
        failed_native_gates=failed_native, evidence_sha256=evidence,
        scientific_qualification_status='Not qualified by this observational diagnostic',
        interpretation='Componentwise agreement does not override native gate failures. Prior failed qualifications remain unchanged.')
    if manifest is None:
        return result
    manifest_hash = evidence[str(manifest_path)]
    result['manifest_sha256'] = manifest_hash
    try:
        require(manifest['schema'] == 'wingbench-observed-derivative-coverage-v1', 'Unknown manifest schema')
        require(all(manifest.get(k) == v for k, v in FLAGS.items()), 'Manifest diagnostic flags changed')
        require(manifest['ranks'] == 16 and manifest['anchor_jobs'] == 3 and manifest['cold_point_jobs'] == 36,
                'Job-count/rank contract changed')
        require(manifest['forward_target'] == 1e-12 and manifest['forward_gate'] == 1.1e-12 and
                manifest['native_target'] == 1e-12 and manifest['native_gate'] == 1.1e-11 and
                manifest['max_native_attempts'] == 3 and manifest['reference_relative_gate'] == .005,
                'Frozen numerical criteria changed')
        require(manifest['directional_rule'] == {'relative': .02, 'absolute_cl': 2e-5, 'absolute_cd': 2e-6},
                'Directional criteria changed')
        require(len(manifest['anchors']) == 3 and len(manifest['points']) == 36, 'Incomplete point manifest')
        for name in NAMES:
            vector = manifest['directions'][name]
            require(len(vector) == 39 and abs(sum(x*x for x in vector)-1.) < 1e-12, 'Invalid direction vector')
            if name != NAMES[-1]:
                coordinate = 17 if name == 'airfoil' else 13
                require(vector == [float(i == coordinate) for i in range(39)], 'Pure direction changed')
        index = 0
        for mach, anchor in enumerate(manifest['anchors']):
            require(anchor['mach_index'] == mach and len(anchor['input']) == 39 and
                    anchor['input'][:38] == [0.]*38 and
                    anchor['input'][38] == float(anchor['reference']['realized_aoa_deg']), 'Invalid anchor')
            for name in NAMES:
                for step in (.002, .001):
                    for sign in (1, -1):
                        point = manifest['points'][index]
                        expected = [a + sign*step*d for a, d in zip(anchor['input'], manifest['directions'][name])]
                        require(point == {'point_index': index, 'mach_index': mach, 'direction': name,
                            'step': step, 'sign': sign,
                            'label': '{}_{}_{}'.format(name, 'plus' if sign == 1 else 'minus', step),
                            'input': expected}, 'Point mapping or input changed at {}'.format(index))
                        index += 1
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        errors.append('Manifest: ' + str(exc))
        result['summary_status'] = 'invalid_evidence'
        return result

    for mode, specs in (('anchor', manifest['anchors']), ('point', manifest['points'])):
        for index, spec in enumerate(specs):
            leaf = root / ('{}_{}'.format(mode, index))
            job = read(leaf / 'coverage_result.json')
            if job is not None and job.get('coverage_job_completed') is False:
                failures.append({'mode': mode, 'index': index, 'failed_stage': job.get('failed_stage'),
                                 'error': job.get('error'), 'gradient_usable': False})
                # Native evidence persists separately even when a solver failure
                # prevented completing a gradient/result bundle.
                attempts_path = leaf / 'native_attempts.json'
                if attempts_path.exists():
                    attempts = read(attempts_path)
                    if isinstance(attempts, list):
                        for row in attempts:
                            if row.get('qualified') is False:
                                failed_native.append(dict(row, mach_index=spec['mach_index'], job_incomplete=True))
                continue
            meta = read(leaf / 'coverage_metadata.json')
            calls = read(leaf / 'forward_calls.json')
            setup = read(leaf / 'setup.json')
            if any(x is None for x in (job, meta, calls, setup)):
                continue
            try:
                for doc in (job, meta, setup):
                    require(all(doc.get(k) == v for k, v in FLAGS.items()), 'Diagnostic flags changed')
                for doc in (job, meta):
                    require(doc['mode'] == mode and doc['index'] == index and doc['spec'] == spec,
                            'Job identity/input differs from manifest')
                    require(doc['manifest_sha256'] == manifest_hash, 'Manifest hash mismatch')
                require(job['coverage_job_completed'] is True, 'Job incomplete')
                require(meta['ranks'] == 16 and meta['forward_gate'] == 1.1e-12 and
                        meta['strict_native_gate'] == 1.1e-11, 'Metadata numerical contract changed')
                require(meta['mesh_sha256'] == manifest['mesh']['sha256'] and
                        meta['code_sha256'] == manifest['source_sha256'], 'Mesh/code hash mismatch')
                hashes = meta['runtime']['sha256']
                for key, expected in manifest['expected_runtime_sha256'].items():
                    require(hashes.get(key) == expected, 'Runtime pin mismatch: ' + key)
                if runtime_signature is None:
                    runtime_signature = hashes
                require(hashes == runtime_signature, 'Runtime varies across coverage jobs')
                require(setup['mach_index'] == spec['mach_index'] and setup['ranks'] == 16 and
                        setup['geometry'] == manifest['geometry'] and
                        setup['reference'] == manifest['anchors'][spec['mach_index']]['reference'], 'Setup mismatch')
                require(job['forward_calls'] == 1 and len(calls) == 1 and calls[0] == job['forward'],
                        'Forward call-count/evidence mismatch')
                forward = job['forward']
                expected_label = 'anchor' if mode == 'anchor' else spec['label']
                require(forward['call'] == 1 and forward['input'] == spec['input'] and
                        forward['label'] == expected_label and forward['solve_failed'] is False,
                        'Forward point or failure mismatch')
                require(job['values'] == [forward['cl'], forward['cd']], 'Forward values mismatch')
                norms = job['forward_norms']
                require(len(norms) == 3 and norms[0] > 0 and norms[-1] >= 0 and
                        norms[-1]/norms[0] <= 1.1e-12 and
                        forward['relative_residual'] == norms[-1]/max(norms[0], 1e-300),
                        'Strict forward gate or norm consistency failed')
                if mode == 'point':
                    require(job['gradient_usable'] is False and not job['native_attempts'] and
                            not job['native_finals'] and not job['failed_native_gates'], 'Point job ran adjoints')
                else:
                    require(job['gradient_usable'] is True, 'Gradient unusable')
                    gradient = job['gradient_cl_cd']
                    require(len(gradient) == 2 and all(len(g) == 39 for g in gradient), 'Gradient shape wrong')
                    ref = spec['reference']
                    reference_error = [abs(v-float(ref[k]))/abs(float(ref[k])) for v,k in zip(job['values'],('cl','cd'))]
                    require(job['reproduction']['relative_errors'] == reference_error and
                            all(x <= .005 for x in reference_error) and
                            job['reproduction']['within_reference_limit'] is True, 'Reference reproduction mismatch')
                    finals, flat = [], []
                    for function in ('cl', 'cd'):
                        attempts = [r for r in job['native_attempts'] if r['function'] == function]
                        require(1 <= len(attempts) <= 3, 'Native attempt count wrong')
                        for number, row in enumerate(attempts, 1):
                            require(row['attempt'] == number and row['solver_failed'] is False and
                                    row['strict_native_gate'] == 1.1e-11 and row['diagnostic_only'] is True,
                                    'Native attempt identity/failure mismatch')
                            require(row['rhs_norm'] > 0 and row['starting_residual_norm'] >= 0 and
                                    row['final_residual_norm'] >= 0 and
                                    row['relative_residual'] == row['final_residual_norm']/row['rhs_norm'],
                                    'Native residual normalization mismatch')
                            require(row['qualified'] is (row['relative_residual'] <= 1.1e-11),
                                    'Native gate relabeled')
                            require(number == len(attempts) or not row['qualified'], 'Attempt continued after success')
                        require(attempts[-1]['qualified'] or len(attempts) == 3, 'Failed native solve not bounded as declared')
                        finals.append(attempts[-1])
                        flat.extend(attempts)
                    require(flat == job['native_attempts'] and finals == job['native_finals'], 'Native ordering/final evidence mismatch')
                    require(job['failed_native_gates'] == [r for r in finals if not r['qualified']], 'Native failures omitted')
                    failed_native.extend(dict(r, mach_index=spec['mach_index']) for r in finals if not r['qualified'])
                valid[mode][index] = job
            except (KeyError, TypeError, ValueError, IndexError, ZeroDivisionError) as exc:
                errors.append('{} {}: {}'.format(mode, index, exc))

    for mach in range(3):
        anchor = valid['anchor'].get(mach)
        if anchor is None:
            continue
        for name in NAMES:
            vector = manifest['directions'][name]
            predicted = [sum(x*d for x,d in zip(g,vector)) for g in anchor['gradient_cl_cd']]
            for step in (.002, .001):
                specs = [p for p in manifest['points'] if p['mach_index'] == mach and p['direction'] == name and p['step'] == step]
                plus = valid['point'].get(specs[0]['point_index'])
                minus = valid['point'].get(specs[1]['point_index'])
                if plus is None or minus is None:
                    continue
                difference = [p-m for p,m in zip(plus['values'],minus['values'])]
                measured = [d/(2*step) for d in difference]
                error = [abs(p-m) for p,m in zip(predicted,measured)]
                allowed = [.02*max(abs(p),abs(m))+floor for p,m,floor in zip(predicted,measured,(2e-5,2e-6))]
                result['comparisons'].append({'mach_index': mach, 'direction': name, 'step': step,
                    'predicted_cl_cd': predicted, 'measured_cl_cd': measured,
                    'plus_minus_difference_cl_cd': difference,
                    'plus_values_17g': [format(v,'.17g') for v in plus['values']],
                    'minus_values_17g': [format(v,'.17g') for v in minus['values']],
                    'absolute_error_cl_cd': error, 'original_allowed_error_cl_cd': allowed,
                    'within_original_limits_cl_cd': [e <= a for e,a in zip(error,allowed)],
                    'native_qualified_cl_cd': [r['qualified'] for r in anchor['native_finals']],
                    'diagnostic_only': True, 'qualification_completed': False, 'can_release_pilot': False})
    result['valid_anchor_jobs'] = len(valid['anchor'])
    result['valid_point_jobs'] = len(valid['point'])
    result['comparison_count'] = len(result['comparisons'])
    result['runtime_sha256'] = runtime_signature
    if errors:
        result['summary_status'] = 'invalid_evidence'
    elif failures:
        result['summary_status'] = 'observations_blocked_by_failed_jobs'
    elif missing or len(result['comparisons']) != 18:
        result['summary_status'] = 'incomplete'
    else:
        result['summary_status'] = 'observations_complete'
        result['all_components_within_original_limits'] = all(all(c['within_original_limits_cl_cd']) for c in result['comparisons'])
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(summarize(args.root, args.manifest), indent=2, allow_nan=False))

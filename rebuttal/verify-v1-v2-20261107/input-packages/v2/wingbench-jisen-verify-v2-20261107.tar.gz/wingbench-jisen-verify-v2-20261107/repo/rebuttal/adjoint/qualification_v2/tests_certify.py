"""Synthetic fail-closed prospective-v2 certification tests; no CFD or MPI."""
from pathlib import Path
import copy
import json
import math
import shutil
import tempfile
import unittest
from unittest.mock import patch

from rebuttal.adjoint.qualification_v2 import certify as c

REAL_ROOT = c.ROOT


def write(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,allow_nan=True))


class CertificationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)/'repo';self.out=Path(self.tmp.name)/'jobs'
        self.out.mkdir();self.root.mkdir()
        old=REAL_ROOT/c.OLD_MANIFEST
        target=self.root/c.OLD_MANIFEST;target.parent.mkdir(parents=True);shutil.copyfile(old,target)
        base=json.loads(old.read_text())
        paths=['rebuttal/compute/jisen_verify_v1/package_manifest.json',
               'rebuttal/compute/jisen_verify_v1/numerical_protocol.json',
               'rebuttal/adjoint/qualification_v2/protocol.json']
        for relative in paths:
            target=self.root/relative;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(REAL_ROOT/relative,target)
        sources={}
        for name in ('protocol.json','evaluator.py','worker.py','build_manifest.py','certify.py','run_process.py'):
            relative='rebuttal/adjoint/qualification_v2/'+name
            target=self.root/relative;target.parent.mkdir(parents=True,exist_ok=True)
            if not target.exists():
                source=REAL_ROOT/relative
                if source.exists():shutil.copyfile(source,target)
                else:target.write_text('# synthetic source fixture\n')
            sources[relative]=c.sha(target)
        package=json.loads((self.root/paths[0]).read_text())
        self.runtime=package['runtime_expected_sha256']
        self.protocol_hash=c.sha(self.root/paths[-1])
        self.manifest=copy.deepcopy(base)
        self.manifest.update(schema='wingbench-adjoint-qualification-v2',native_gate=1.1e-9,
            created_at_utc='2026-11-07T08:00:00+00:00',source_sha256=sources,
            expected_runtime_sha256=self.runtime,
            protocol={'path':paths[-1],'sha256':self.protocol_hash})
        self.manifest_path=self.root/'rebuttal/adjoint/qualification_v2/coverage_manifest.json'
        write(self.manifest_path,self.manifest);self.manifest_hash=c.sha(self.manifest_path)
        self.gradient=[[.0001*(i+1) for i in range(39)], [.00001*(i+1) for i in range(39)]]
        for mode,specs in (('anchor',base['anchors']),('point',base['points'])):
            for index,spec in enumerate(specs):self.make_job(mode,index,spec)

    def tearDown(self):self.tmp.cleanup()

    def make_job(self,mode,index,spec):
        leaf=self.out/('{}_{}'.format(mode,index));leaf.mkdir()
        anchor=self.manifest['anchors'][spec['mach_index']]
        values=[float(anchor['reference'][key]) for key in ('cl','cd')]
        if mode=='point':
            direction=self.manifest['directions'][spec['direction']]
            values=[v+spec['sign']*spec['step']*math.fsum(x*d for x,d in zip(g,direction))
                    for v,g in zip(values,self.gradient)]
        flags={'schema':c.JOB_SCHEMA,'qualification_completed':False,'can_release_pilot':False,
            'diagnostic_only':False,'mode':mode,'index':index,'spec':spec,
            'manifest_sha256':self.manifest_hash,'protocol_sha256':self.protocol_hash}
        metadata=dict(flags,ranks=16,forward_gate=1.1e-12,native_gate=1.1e-9,
            mesh_sha256=self.manifest['mesh']['sha256'],source_sha256=self.manifest['source_sha256'],
            code_sha256=self.manifest['source_sha256'],runtime={'sha256':self.runtime},
            created_at_utc='2026-11-07T08:01:00+00:00',slurm_job_id=str(100+index))
        write(leaf/'coverage_metadata.json',metadata)
        write(leaf/'setup.json',{'schema':'wingbench-adjoint-evaluator-v2','mach_index':spec['mach_index'],
            'ranks':16,'geometry':self.manifest['geometry'],'reference':anchor['reference'],
            'forward_tolerance':1e-12,'adjoint_tolerance':1e-12,
            'forward_relative_residual_gate':1.1e-12,'adjoint_true_relative_residual_gate':1.1e-9})
        forward={'call':1,'input':spec['input'],'label':'anchor' if mode=='anchor' else spec['label'],
            'solve_failed':False,'qualified':True,'forward_gate':1.1e-12,'cl':values[0],'cd':values[1],
            'raw_norms':[1.,1e-8,1e-13],'relative_residual':1e-13,
            'finite_flags':{'norms':True,'values':True}}
        write(leaf/'forward_calls.json',[forward])
        result=dict(flags,coverage_job_completed=True,job_passed=True,forward_calls=1,
            forward=forward,forward_norms=forward['raw_norms'],values=values,gradient_usable=mode=='anchor',
            native_attempts=[],native_finals=[],failed_native_gates=[])
        if mode=='anchor':
            reproduction={'values':values,'reference':values,'relative_errors':[0.,0.],
                          'within_reference_limit':True}
            native=[{'function':f,'attempt':1,'solver_failed':False,'failed':False,'native_gate':1.1e-9,
                     'strict_native_gate':1.1e-9,'finite_norms':True,'rhs_norm':1.,
                     'starting_residual_norm':1e-7,'final_residual_norm':3e-11,
                     'relative_residual':3e-11,'qualified':True} for f in ('cl','cd')]
            result.update(gradient_cl_cd=self.gradient,reproduction=reproduction,
                          native_attempts=native,native_finals=native)
            write(leaf/'reproduction.json',reproduction)
            write(leaf/'native_attempts.json',native);write(leaf/'native_finals.json',native)
        write(leaf/'coverage_result.json',result)
        command=['mpirun','-np','16','python3','/workspace/repo/rebuttal/adjoint/qualification_v2/worker.py',
                 '--mode',mode,'--index',str(index),'--manifest-sha256',self.manifest_hash]
        write(leaf/'process.json',{'mode':mode,'index':index,'manifest_sha256':self.manifest_hash,
            'return_code':0,'timed_out':False,'started_at_utc':'2026-11-07T08:00:30+00:00',
            'finished_at_utc':'2026-11-07T09:00:00+00:00','wall_seconds':3570.,
            'command':command,'slurm_job_id':str(100+index)})

    def result(self):
        with patch.object(c,'ROOT',self.root):return c.certify(self.out,self.manifest_path,self.manifest_hash)

    def change(self,relative,edit):
        path=self.out/relative;value=json.loads(path.read_text());edit(value);write(path,value)

    def blocked(self):
        result=self.result();self.assertFalse(result['passed'],result)
        self.assertFalse(result['can_release_pilot']);self.assertFalse(result['can_release_campaign'])
        return result

    def test_full39_fresh_jobs_pass36scalar_gates_only_release_pilot(self):
        result=self.result();self.assertTrue(result['passed'],result)
        self.assertEqual(result['valid_anchor_jobs'],3);self.assertEqual(result['valid_point_jobs'],36)
        self.assertEqual(result['scalar_comparison_count'],36);self.assertEqual(result['native_final_count'],6)
        self.assertFalse(result['can_release_campaign'])

    def test_v1_schema_rejected(self):
        self.change('anchor_0/coverage_result.json',lambda x:x.update(schema='wingbench-observed-derivative-coverage-v1'))
        self.blocked()

    def test_missing_endpoint_process_blocks(self):
        (self.out/'point_35/process.json').unlink();self.blocked()

    def test_failed_external_process_blocks_success_result(self):
        self.change('point_2/process.json',lambda x:x.update(return_code=1));self.blocked()

    def test_wrong_worker_command_blocks(self):
        self.change('point_2/process.json',lambda x:x.update(command=['python','old_worker.py']));self.blocked()

    def test_process_before_manifest_blocks(self):
        self.change('point_2/process.json',lambda x:x.update(started_at_utc='2026-11-06T08:00:00+00:00'));self.blocked()

    def test_wrong_manifest_hash_blocks(self):
        self.change('anchor_1/coverage_metadata.json',lambda x:x.update(manifest_sha256='wrong'));self.blocked()

    def test_changed_runtime_blocks(self):
        self.change('point_1/coverage_metadata.json',lambda x:x['runtime']['sha256'].update(adflow_library='wrong'));self.blocked()

    def test_changed_source_bytes_blocks(self):
        (self.root/'rebuttal/adjoint/qualification_v2/evaluator.py').write_text('changed');self.blocked()

    def test_changed_mesh_binding_blocks(self):
        self.change('point_1/coverage_metadata.json',lambda x:x.update(mesh_sha256='wrong'));self.blocked()

    def test_forged_native_qualified_true_blocks(self):
        for name in ('native_attempts.json','native_finals.json'):
            self.change('anchor_0/'+name,lambda a:a[0].update(final_residual_norm=3e-9,relative_residual=3e-9))
        def edit(x):
            for name in ('native_attempts','native_finals'):x[name][0].update(final_residual_norm=3e-9,relative_residual=3e-9)
        self.change('anchor_0/coverage_result.json',edit);self.blocked()

    def test_null_norm_cannot_hide_nonfinite(self):
        self.change('anchor_0/coverage_result.json',lambda x:x['native_attempts'][0].update(rhs_norm=None));self.blocked()

    def test_nonfinite_json_blocks(self):
        self.change('point_1/coverage_result.json',lambda x:x['values'].__setitem__(0,float('nan')));self.blocked()

    def test_forward_ratio_too_large_blocks(self):
        self.change('point_1/coverage_result.json',lambda x:x.update(forward_norms=[1.,1e-8,2e-12]));self.blocked()

    def test_missing_native_final_blocks(self):
        (self.out/'anchor_2/native_finals.json').unlink();self.blocked()

    def test_single_CL_directional_failure_blocks(self):
        def edit(x):
            x['values'][0]+=.0001;x['forward']['cl']=x['values'][0]
        self.change('point_0/coverage_result.json',edit)
        raw=json.loads((self.out/'point_0/coverage_result.json').read_text())
        write(self.out/'point_0/forward_calls.json',[raw['forward']])
        result=self.blocked();self.assertEqual(result['valid_point_jobs'],36)
        self.assertTrue(any(not all(item['components_passed']) for item in result['comparisons']))

    def test_boolean_only_reproduction_cannot_override_coefficients(self):
        self.change('anchor_0/coverage_result.json',lambda x:x['reproduction'].update(relative_errors=[0.01,0.]));self.blocked()

    def test_hash_changes_with_raw_process_metadata(self):
        before=self.result();self.assertTrue(before['passed'])
        self.change('point_0/process.json',lambda x:x.update(extra_observation='new'))
        after=self.result();self.assertTrue(after['passed'])
        self.assertNotEqual(before['evidence_sha256'],after['evidence_sha256'])

    def test_explicit_manifest_hash_required(self):
        with patch.object(c,'ROOT',self.root):result=c.certify(self.out,self.manifest_path)
        self.assertFalse(result['passed'])


if __name__=='__main__':unittest.main()

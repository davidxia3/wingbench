"""Original-grader controls/regrade. Write PASS only after all comparisons."""
from pathlib import Path
import argparse
import json
import math
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from benchmark.common import load_tasks, json_ready
from benchmark.grade_local import LocalGrader
from rebuttal.adjoint.check_refined import control


def main(args):
    args.out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    row, refs = control()
    geometry = row['geometry']
    predicted = None
    if args.pilot:
        rec = json.loads((args.pilot / 'recommendation.json').read_text())
        geometry = rec['geometry']
        predicted = rec['warped_mesh_result']['score']
    report = {'passed': False, 'kind': 'pilot_regrade' if args.pilot else 'original_grader_control',
              'grading_mode': 'local', 'official_sealed_grade': False,
              'relative_gate': .005, 'can_launch_campaign': False}
    try:
        result = LocalGrader(load_tasks()['nominal'], args.out / 'work',
                             run_id=args.out.name).grade(geometry, args.out.name)
        (args.out / 'grade.json').write_text(json.dumps(json_ready(result), indent=2) + '\n')
        grade = result['benchmark_grade']
        report['delivered'] = grade['delivered']
        if grade['delivered'] is not True:
            raise RuntimeError('Original grader did not deliver a valid wing')
        score = float(grade['ld'])
        if not math.isfinite(score) or score <= 0:
            raise RuntimeError('Invalid original-grader score')
        if args.pilot:
            error = abs(score-predicted)/predicted
            report.update(warped_score=predicted, original_score=score, relative_error=error)
            if not math.isfinite(error) or error > .005:
                raise RuntimeError('Independent regrade exceeds unchanged 0.5% agreement gate')
        else:
            conditions = sorted(result['conditions'], key=lambda c: float(c['mach']))
            if len(conditions) != 3:
                raise RuntimeError('Expected all three original-grader conditions')
            checks = []
            for condition, ref in zip(conditions, refs):
                if float(condition['mach']) != float(ref['mach']):
                    raise RuntimeError('Mach identity mismatch')
                values = condition['measurements']
                errors = {k: abs(float(values[k])-float(ref[k]))/abs(float(ref[k]))
                          for k in ('cl', 'cd')}
                checks.append({'mach': float(ref['mach']), 'relative_errors': errors,
                               'within_limit': all(math.isfinite(e) and e <= .005 for e in errors.values())})
            report.update(original_score=score, comparisons=checks)
            if not all(c['within_limit'] for c in checks):
                raise RuntimeError('Original-grader control differs from recorded coefficients by over0.5%')
        report['passed'] = True
    except Exception as exc:
        report.update(error_type=type(exc).__name__, error=str(exc))
    report['wall_seconds'] = time.monotonic()-started
    (args.out / 'verification_result.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(report), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--pilot', type=Path)
    sys.exit(main(p.parse_args()))

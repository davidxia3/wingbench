"""Geometry-only Jacobian for the unchanged SuperWing surface construction.

Finite differences here evaluate inexpensive geometry, NOT CFD. Flow and mesh
sensitivities are computed by ADflow's discrete adjoint and IDWarp respectively.
"""
from pathlib import Path
import ast
import contextlib
import io
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
local_cst = ROOT / 'rebuttal/vendor/cst-modeling3d'
if local_cst.exists():
    sys.path.insert(0, str(local_cst))
from scripts.cfd.prepare_superwing_cases import geom_to_wing_coefs


class Surface:
    def __init__(self, anchor, scale):
        self.anchor = np.asarray(anchor, dtype=float)
        self.scale = np.asarray(scale, dtype=float)
        vendor = ROOT / 'scripts/cfd/aerotransformer/gen-mesh.superwing.py'
        nodes = []
        for n in ast.parse(vendor.read_text()).body:
            if isinstance(n, ast.ImportFrom) and n.module in ('pyhyp', 'mpi4py', 'cgnsutilities.cgnsutilities'):
                continue
            if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'comm' for t in n.targets):
                continue
            if isinstance(n, ast.If):
                continue
            nodes.append(n)
        self.ns = {}
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(vendor), 'exec'), self.ns)
        self.ns['tip_path'] = str(vendor.parent / 'original_tip.xyz')
        tip = self.ns['read_plot3d'](self.ns['tip_path'])
        self.ns['read_plot3d'] = lambda path: [b.copy() for b in tip]
        self.blocks = []
        self.ns['output_plot3d_concat'] = lambda blocks, **kw: self.blocks.extend(blocks)
        self.root_z = -0.1 * self.anchor[3] * (1 + self.anchor[4]) / 4

    def evaluate(self, z):
        x = self.anchor + self.scale * np.asarray(z)
        coefs = geom_to_wing_coefs(x)
        coefs['half_span'] = coefs['AR'] * (1 + coefs['TR']) / 4
        coefs['ref_area'] = (1 + coefs['TR']) * coefs['half_span'] / 2
        self.blocks.clear()
        with contextlib.redirect_stdout(io.StringIO()):
            coefs = self.ns['surface_meshing'](coefs)
        pts = np.concatenate([b.reshape(-1, 3) for b in self.blocks])
        # A rigid translation keeps the root on the reference symmetry plane.
        # It preserves wing shape; the finite-domain effect is checked by fresh
        # grading of recommendations. No rotation, rescaling or smoothing here.
        pts[:, 2] += self.root_z + 0.1 * coefs['half_span']
        area = float(coefs['surface_area'])
        if not np.all(np.isfinite(pts)) or not np.isfinite(area) or area <= 0:
            raise ValueError('Invalid surface or reference area')
        return pts, area

    def jacobian(self, z, indices=None, h=1e-5):
        z = np.asarray(z, dtype=float)
        pts, _ = self.evaluate(z)
        if indices is None:
            indices = np.arange(len(pts))
        jac = np.empty((len(indices), 3, 38))
        area_jac = np.empty(38)
        for k in range(38):
            d = np.zeros(38)
            d[k] = h
            plus, ap = self.evaluate(z + d)
            minus, am = self.evaluate(z - d)
            if plus.shape != pts.shape or minus.shape != pts.shape:
                raise ValueError('Surface topology changed')
            jac[:, :, k] = (plus[indices] - minus[indices]) / (2 * h)
            area_jac[k] = (ap - am) / (2 * h)
        return jac, area_jac


def directions():
    twist = np.zeros(39); twist[13] = 1
    cst = np.zeros(39); cst[17] = 1
    mixed = np.random.default_rng(790107).normal(size=39)
    mixed /= np.linalg.norm(mixed)
    return {'twist': twist, 'airfoil': cst, 'mixed_all_coordinates_and_alpha': mixed}

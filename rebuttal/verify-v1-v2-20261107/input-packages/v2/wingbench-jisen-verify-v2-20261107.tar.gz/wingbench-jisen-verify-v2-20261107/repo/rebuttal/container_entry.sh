#!/bin/bash
set -o pipefail
# The base image's pyenv initialization attempts a rehash in its read-only
# shim directory. The reference entrypoint also permits that harmless failure.
# Check the scientific imports explicitly in setup before marking READY.
source /home/mdolabuser/.bashrc_mdolab
set -e
export PYTHONPATH="/workspace/repo:/workspace/runtime/cst-modeling3d${PYTHONPATH:+:$PYTHONPATH}"
unset ADFLOW_USE_ANK ADFLOW_USE_NK ADFLOW_NK_SWITCH OMP_NUM_THREADS OPENBLAS_NUM_THREADS MKL_NUM_THREADS
cd /workspace/repo
exec "$@"

"""Private observational derivative coverage; never qualifies or releases a pilot.

Freeze a manifest before submission. Three anchor jobs each obtain CL/CD
gradients; 36 independent cold point jobs form the original 18 comparisons.
Native gate misses remain failures. No optimization or qualification artifact.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import inspect
import json
import math
import re
import sys
import time
from datetime import datetime, timezone

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
FORWARD_GATE = 1.1e-12
NATIVE_GATE = 1.1e-11
STEPS = (.002, .001)
NAMES = ('airfoil', 'twist', 'mixed_all_coordinates_and_alpha')
FLAGS = {'diagnostic_only': True, 'qualification_completed': False,
         'can_release_pilot': False}


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def records():
    from rebuttal.adjoint.check_refined import control
    from rebuttal.adjoint.geometry import directions
    from benchmark.common import load_box
    row, refs = control()
    vectors = {name: directions()[name].tolist() for name in NAMES}
    anchors, points = [], []
    for mach, ref in enumerate(refs):
        anchor = np.zeros(39)
        anchor[38] = float(ref['realized_aoa_deg'])
        anchors.append({'mach_index': mach, 'reference': ref, 'input': anchor.tolist()})
        for name in NAMES:
            for step in STEPS:
                for sign in (1, -1):
                    points.append({'point_index': len(points), 'mach_index': mach,
                        'direction': name, 'step': step, 'sign': sign,
                        'label': '{}_{}_{}'.format(name, 'plus' if sign == 1 else 'minus', step),
                        'input': (anchor + sign * step * np.asarray(vectors[name])).tolist()})
    return row, list(load_box().sd), vectors, anchors, points


def make_manifest(args):
    if not re.fullmatch(r'[0-9a-f]{64}', args.mesh_sha256):
        raise ValueError('Explicit SHA256 of the shared mesh is required')
    row, scales, vectors, anchors, points = records()
    sources = [
        'rebuttal/adjoint/coverage_observed_run.py',
        'rebuttal/adjoint/coverage_observed_summary.py',
        'rebuttal/adjoint/coverage_observed_anchors.sbatch',
        'rebuttal/adjoint/coverage_observed_points.sbatch',
        'rebuttal/adjoint/check_refined.py', 'rebuttal/adjoint/geometry.py',
        'rebuttal/container_entry.sh', 'benchmark/common.py',
        'scripts/cfd/prepare_superwing_cases.py',
        'scripts/cfd/aerotransformer/gen-mesh.superwing.py',
        'scripts/cfd/aerotransformer/original_tip.xyz',
        'rebuttal/flow_validation_manifest.json', 'data/cfd_conditions.csv',
    ]
    manifest = dict(FLAGS, schema='wingbench-observed-derivative-coverage-v1',
        created_at_utc=datetime.now(timezone.utc).isoformat(),
        purpose='Derivative evidence only; independent of unresolved strict native qualification',
        mesh={'container_path': args.mesh, 'sha256': args.mesh_sha256},
        ranks=16, anchor_jobs=3, cold_point_jobs=36, point_concurrency=8,
        geometry=row, normalization_scales=scales, directions=vectors,
        anchors=anchors, points=points,
        forward_target=1e-12, forward_gate=FORWARD_GATE,
        native_target=1e-12, native_gate=NATIVE_GATE, max_native_attempts=3,
        reference_relative_gate=.005,
        directional_rule={'relative': .02, 'absolute_cl': 2e-5, 'absolute_cd': 2e-6},
        initialization='Each of 39 jobs has a new solver, no restart file, exactly one forward solve',
        native_policy='Same bounded evalFunctionsSens refinements as check_refined; a finite true-residual miss stays failed but allows diagnostic extraction. Actual solver failure or invalid derivative aborts.',
        source_sha256={p: file_hash(ROOT / p) for p in sources},
        expected_runtime_sha256={
            'adflow_python': '790f3f6353fc8501d256f5d78c32c9aeb59ee522e0f92814666c4135028b8425',
            'adflow_library': 'a4c9da4969963fe397f3d8db6477ad8cf5c5b898c7b5c6b89ec52613ee91c02b',
            'cst_math': '9d0e7b8b3106c75fa78a6d6bb1dd45dc2c7deab35836bf6f8ac7cde2dcab30c3'},
        historical_evidence='Prior qualification failures remain unchanged. Four old Mach0 airfoil cold points are independent replication only and are not reused in these 18 comparisons.',
        limitations='Three directions do not verify every coordinate; gradient stability/agreement cannot override failed native gates or qualify optimization.')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        stream.write(json.dumps(manifest, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'manifest': str(args.output), 'sha256': file_hash(args.output),
                      'anchor_jobs': 3, 'cold_point_jobs': 36, 'comparisons': 18}))


def runtime_hashes(ev):
    import adflow
    import idwarp
    import cst_modeling.basic as cst_basic
    import cst_modeling.section as cst_section
    import cst_modeling.io as cst_io
    import cst_modeling.math as cst_math
    solver_file = Path(inspect.getfile(type(ev.solver))).resolve()
    reported = Path(ev.solver.adflow.__file__)
    library = reported if reported.is_file() else solver_file.with_name('libadflow.so')
    paths = {'adflow_python': solver_file, 'adflow_library': library,
             'idwarp_python': Path(inspect.getfile(type(ev.mesh))),
             'cst_math': Path(inspect.getfile(cst_math)),
             'cst_basic': Path(inspect.getfile(cst_basic)),
             'cst_section': Path(inspect.getfile(cst_section)),
             'cst_io': Path(inspect.getfile(cst_io))}
    return {'sha256': {key: file_hash(path) for key, path in paths.items()},
            'paths': {key: str(path) for key, path in paths.items()},
            'binary_provenance': 'Installed MExt library copy source is hashed if its temporary loaded file has been unlinked; not a hash of the in-memory mapping.',
            'python': sys.version, 'numpy': np.__version__}


def observed_gradient(ev, y, values):
    """Unchanged derivative chain; native misses are recorded, never approved."""
    from mpi4py import MPI
    if ev.last_y is None or not np.array_equal(y, ev.last_y):
        raise ValueError('Gradient requires its own anchor forward solve')
    surface_jac, area_jac = ev.surface.jacobian(y[:38], ev.indices)
    _, area = ev.surface.evaluate(y[:38])
    gradient = np.empty((2, 39))
    attempts, finals = [], []
    for index, function in enumerate(('cl', 'cd')):
        for attempt in range(1, 4):
            start = time.monotonic()
            sens = {}
            ev.solver.evalFunctionsSens(ev.ap, sens, evalFuncs=[function])
            initial, starting, final, failed = ev.solver.getAdjointResNorms()
            norms = np.asarray([initial, starting, final], dtype=float)
            if not np.isfinite(norms).all() or initial <= 0 or min(starting, final) < 0:
                raise RuntimeError('Invalid native residual tuple')
            record = {'function': function, 'attempt': attempt,
                'rhs_norm': float(initial), 'starting_residual_norm': float(starting),
                'final_residual_norm': float(final), 'relative_residual': float(final / initial),
                'solver_failed': bool(failed or ev.ap.adjointFailed),
                'strict_native_gate': NATIVE_GATE,
                'qualified': bool(not (failed or ev.ap.adjointFailed) and final / initial <= NATIVE_GATE),
                'diagnostic_only': True, 'wall_seconds': time.monotonic() - start}
            attempts.append(record)
            if ev.comm.rank == 0:
                write_json(ev.out / 'native_attempts.json', attempts)
                print('OBSERVED_NATIVE', json.dumps(record), flush=True)
            ev.comm.barrier()
            if record['solver_failed']:
                raise RuntimeError('Native solver failure; diagnostic gradient is unusable')
            if record['qualified']:
                break
        psi = np.asarray(ev.solver.getAdjoint(function))
        if not np.isfinite(psi).all():
            raise RuntimeError('Nonfinite adjoint; diagnostic gradient is unusable')
        xsbar = ev.solver.computeJacobianVectorProductBwd(
            resBar=-psi, funcsBar={function: 1.}, xSDeriv=True)
        local = np.einsum('ij,ijk->k', xsbar, surface_jac)
        gradient[index, :38] = ev.comm.allreduce(local, op=MPI.SUM) - values[index] / area * area_jac
        gradient[index, 38] = float(np.asarray(sens[ev.ap.name + '_' + function]['alpha']).ravel()[0])
        if not np.isfinite(gradient[index]).all():
            raise RuntimeError('Nonfinite diagnostic gradient')
        finals.append(dict(record))
        if ev.comm.rank == 0:
            write_json(ev.out / 'gradient_progress.json', dict(FLAGS,
                functions_finished=[r['function'] for r in finals],
                gradient_cl_cd=gradient[:index + 1].tolist(), native_finals=finals))
        ev.comm.barrier()
    return gradient, attempts, finals


def run(args):
    from mpi4py import MPI
    from rebuttal.adjoint.check_refined import Evaluator
    comm = MPI.COMM_WORLD
    manifest = json.loads(args.manifest.read_text())
    spec = manifest['anchors' if args.mode == 'anchor' else 'points'][args.index]
    leaf = ('anchor_' if args.mode == 'anchor' else 'point_') + str(args.index)
    out = args.out / leaf
    if comm.rank == 0:
        out.mkdir(parents=True, exist_ok=False)
    comm.barrier()
    started, stage, ev = time.monotonic(), 'provenance', None
    try:
        if comm.size != 16 or manifest['ranks'] != 16:
            raise ValueError('Exactly 16 ranks are required')
        if any(manifest.get(k) != v for k, v in FLAGS.items()):
            raise ValueError('Diagnostic-only manifest flags changed')
        if manifest['forward_gate'] != FORWARD_GATE or manifest['native_gate'] != NATIVE_GATE:
            raise ValueError('Numerical gates changed')
        mesh = Path(manifest['mesh']['container_path'])
        if comm.rank == 0:
            for relative, expected in manifest['source_sha256'].items():
                if file_hash(ROOT / relative) != expected:
                    raise ValueError('Frozen source changed: ' + relative)
            if file_hash(mesh) != manifest['mesh']['sha256']:
                raise ValueError('Frozen mesh hash changed')
        comm.barrier()
        row, scales, vectors, anchors, points = records()
        if (row != manifest['geometry'] or scales != manifest['normalization_scales'] or
                vectors != manifest['directions'] or anchors != manifest['anchors'] or points != manifest['points']):
            raise ValueError('Frozen geometry, scaling, references or points changed')
        stage = 'initialization'
        ev = Evaluator(comm, mesh, out, spec['mach_index'])
        if (ev.solver.getOption('restartFile') is not None or ev.calls or ev.adjoint_calls or
                ev.adjoint_attempts or ev.last_y is not None):
            raise RuntimeError('Evaluator must be cold, with no previous solve/restart')
        for name, expected in [('L2Convergence', 1e-12), ('adjointL2Convergence', 1e-12),
                               ('frozenTurbulence', False), ('ADPC', True)]:
            if ev.solver.getOption(name) != expected:
                raise RuntimeError('Required solver option changed: ' + name)
        runtime = None
        if comm.rank == 0:
            runtime = runtime_hashes(ev)
            for key, expected in manifest['expected_runtime_sha256'].items():
                if runtime['sha256'].get(key) != expected:
                    raise ValueError('Pinned runtime changed: ' + key)
        runtime = comm.bcast(runtime, root=0)
        metadata = dict(FLAGS, mode=args.mode, index=args.index, spec=spec,
            manifest_sha256=file_hash(args.manifest), mesh_sha256=manifest['mesh']['sha256'],
            code_sha256=manifest['source_sha256'], runtime=runtime, ranks=comm.size,
            forward_gate=FORWARD_GATE, strict_native_gate=NATIVE_GATE,
            initialization='Fresh solver, no restart, exactly one cold forward solve',
            scope='Derivative evidence only; does not alter prior failed qualification')
        if comm.rank == 0:
            write_json(out / 'coverage_metadata.json', metadata)
            setup = json.loads((out / 'setup.json').read_text())
            setup.update(FLAGS, execution_mode='observational_' + args.mode,
                         initialization=metadata['initialization'],
                         rerun_reason='Collect derivative evidence without overriding native gate failures')
            write_json(out / 'setup.json', setup)
        comm.barrier()
        y = np.asarray(spec['input'], dtype=float)
        stage = 'cold_forward'
        values = ev.forward(y, 'anchor' if args.mode == 'anchor' else spec['label'])
        raw_norms = [float(v) for v in ev.solver.getResNorms()]
        if (not np.isfinite(raw_norms).all() or raw_norms[0] <= 0 or raw_norms[-1] < 0 or
                raw_norms[-1] / raw_norms[0] > FORWARD_GATE or len(ev.calls) != 1):
            raise RuntimeError('Independent strict forward verification failed')
        result = dict(FLAGS, mode=args.mode, index=args.index, spec=spec,
            manifest_sha256=metadata['manifest_sha256'],
            coverage_job_completed=True, gradient_usable=False,
            values=values.tolist(), forward=ev.calls[0], forward_norms=raw_norms,
            forward_calls=1, native_attempts=[], native_finals=[], failed_native_gates=[])
        if args.mode == 'anchor':
            reference = np.array([float(ev.reference['cl']), float(ev.reference['cd'])])
            error = np.abs(values - reference) / np.abs(reference)
            reproduction = {'relative_errors': error.tolist(), 'within_reference_limit': bool(np.all(error <= .005))}
            if comm.rank == 0:
                write_json(out / 'reproduction.json', reproduction)
            if not reproduction['within_reference_limit']:
                raise RuntimeError('Reference reproduction exceeds unchanged 0.5% limit')
            stage = 'observed_gradient'
            gradient, attempts, finals = observed_gradient(ev, y, values)
            result.update(gradient_usable=True, gradient_cl_cd=gradient.tolist(),
                native_attempts=attempts, native_finals=finals, reproduction=reproduction,
                failed_native_gates=[r for r in finals if not r['qualified']])
        elif ev.adjoint_calls or ev.adjoint_attempts:
            raise RuntimeError('Point job must not call adjoints')
        result['wall_seconds'] = time.monotonic() - started
        if comm.rank == 0:
            write_json(out / 'coverage_result.json', result)
            print('OBSERVED_COVERAGE_RESULT', json.dumps(result), flush=True)
        comm.barrier()
    except BaseException as error:
        if comm.rank == 0:
            write_json(out / 'coverage_result.json', dict(FLAGS,
                coverage_job_completed=False, gradient_usable=False,
                mode=args.mode, index=args.index, spec=spec,
                manifest_sha256=file_hash(args.manifest), failed_stage=stage,
                error_type=type(error).__name__, error=str(error),
                forward_calls=len(ev.calls) if ev else 0,
                wall_seconds=time.monotonic() - started))
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command')
    make = sub.add_parser('manifest')
    make.add_argument('--mesh', required=True, help='Exact container mesh path')
    make.add_argument('--mesh-sha256', required=True)
    make.add_argument('--output', type=Path, required=True)
    execute = sub.add_parser('run')
    execute.add_argument('--manifest', type=Path, required=True)
    execute.add_argument('--out', type=Path, required=True)
    execute.add_argument('--mode', choices=['anchor', 'point'], required=True)
    execute.add_argument('--index', type=int, required=True)
    args = parser.parse_args()
    if args.command == 'manifest':
        make_manifest(args)
    elif args.command == 'run':
        if args.index not in range(3 if args.mode == 'anchor' else 36):
            parser.error('Index out of range')
        try:
            run(args)
        except BaseException:
            import traceback
            traceback.print_exc()
            from mpi4py import MPI
            MPI.COMM_WORLD.Abort(1)
    else:
        parser.error('Select manifest or run')

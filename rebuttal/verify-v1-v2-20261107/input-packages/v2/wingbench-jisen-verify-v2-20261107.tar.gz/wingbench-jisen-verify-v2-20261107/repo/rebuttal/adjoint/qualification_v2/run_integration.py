"""Single conditional pilot or original-grader regrade; preserve external exit."""
from pathlib import Path
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent


def run(args):
    if args.out.exists():raise FileExistsError('Existing output cannot be reused')
    if hashlib.sha256(args.manifest.read_bytes()).hexdigest()!=args.manifest_sha256:
        raise ValueError('Manifest external hash mismatch')
    manifest=json.loads(args.manifest.read_text())
    args.out.parent.mkdir(parents=True,exist_ok=True)
    common=['--manifest',str(args.manifest),'--manifest-sha256',args.manifest_sha256,
            '--checks',str(args.checks),'--out',str(args.out)]
    env=dict(os.environ)
    for key in list(env):
        if key.startswith('ADFLOW_') or key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
            env.pop(key,None)
    if args.mode=='pilot':
        # Certificate is recomputed again inside the MPI pilot before solver creation.
        from rebuttal.adjoint.qualification_v2.certify import certify
        certificate=certify(args.checks,args.manifest,manifest_sha256=args.manifest_sha256,emit=True)
        if certificate.get('can_release_pilot') is not True:raise ValueError('V2 qualification failed; pilot blocked')
        command=['mpirun','-np','16',sys.executable,str(HERE/'serial_pilot.py')]+common+[
            '--mesh',manifest['mesh']['container_path'],'--requested-memory-gib','288']
        env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    else:
        if args.pilot is None:raise ValueError('Regrade requires --pilot')
        command=[sys.executable,str(HERE/'regrade.py')]+common+['--pilot',str(args.pilot)]
    start=time.monotonic()
    record={'schema':'wingbench-adjoint-integration-process-v2','mode':args.mode,
        'manifest_sha256':args.manifest_sha256,'command':command,'return_code':None,
        'timed_out':False,'started_at_utc':datetime.now(timezone.utc).isoformat(),
        'slurm_job_id':os.environ.get('SLURM_JOB_ID'),'can_release_campaign':False}
    claim=args.out.parent/('.launch_'+args.out.name+'.json')
    with claim.open('x') as f:
        f.write(json.dumps(record,indent=2)+'\n');f.flush();os.fsync(f.fileno())
    process=None
    def terminate(signum,frame):
        record['timed_out']=True;record['termination_signal']=signum
        if process is not None:
            try:os.killpg(process.pid,signum)
            except ProcessLookupError:pass
    signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
    try:
        process=subprocess.Popen(command,env=env,start_new_session=True)
        record['return_code']=process.wait()
    except BaseException as exc:
        record.update(return_code=125,error=type(exc).__name__+': '+str(exc))
    record.update(wall_seconds=time.monotonic()-start,finished_at_utc=datetime.now(timezone.utc).isoformat())
    args.out.mkdir(parents=True,exist_ok=True)
    with (args.out/'process.json').open('x') as f:
        f.write(json.dumps(record,indent=2,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
    return 0 if record['return_code']==0 and not record['timed_out'] else 2


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['pilot','regrade'],required=True)
    for name in ('manifest','checks','out'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--pilot',type=Path);p.add_argument('--manifest-sha256',required=True)
    sys.exit(run(p.parse_args()))

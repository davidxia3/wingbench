"""No CFD: guard numerical edge cases, bounded refinements and process evidence."""
from pathlib import Path
from types import SimpleNamespace
import contextlib
import io
import json
import sys
import tempfile
import unittest
from unittest.mock import patch
import numpy as np

from rebuttal.adjoint.qualification_v2 import evaluator as module
from rebuttal.adjoint.qualification_v2 import run_process


class Comm:
    rank=0;size=16
    def allgather(self,value):return [value]*16
    def barrier(self):pass
    def allreduce(self,value,op=None):return value


class EvaluatorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def fake(self,native_ratios=None,forward_norms=(1.,1.,1e-13),failed=False):
        ev=object.__new__(module.Evaluator)
        ev.comm=Comm();ev.out=self.root;ev.calls=[];ev.adjoint_attempts=[];ev.adjoint_calls=[];ev.counter=0
        ev.ap=SimpleNamespace(name='test',solveFailed=failed,fatalFail=False,adjointFailed=False)
        ev.last_y=np.zeros(39);ev.coords0=np.zeros((1,3));ev.base_surface=np.zeros((1,3));ev.indices=[0]
        ev.surface=SimpleNamespace(evaluate=lambda z:(np.zeros((1,3)),1.),
            jacobian=lambda z,i:(np.zeros((1,3,38)),np.zeros(38)))
        ratios=list(native_ratios or [5e-10,5e-10]);counter=[0]
        class Solver:
            designFamilyGroup='wing'
            def __call__(self,ap):pass
            def setSurfaceCoordinates(self,*args):pass
            def evalFunctions(self,ap,funcs):funcs.update(test_cl=.4,test_cd=.02)
            def getResNorms(self):return forward_norms
            def evalFunctionsSens(self,ap,sens,evalFuncs):
                self.ratio=ratios[min(counter[0],len(ratios)-1)];counter[0]+=1
                sens['test_'+evalFuncs[0]]={'alpha':np.array([.1])}
            def getAdjointResNorms(self):return 1.,1.,self.ratio,False
            def getAdjoint(self,function):return np.ones(3)
            def computeJacobianVectorProductBwd(self,**kw):return np.zeros((1,3))
        ev.solver=Solver();return ev
    def gradient(self,ev):
        with patch.dict(sys.modules,{'mpi4py':SimpleNamespace(MPI=SimpleNamespace(SUM='sum'))}),contextlib.redirect_stdout(io.StringIO()):
            return ev.gradient(np.zeros(39),np.array([.4,.02]))
    def test_v2_native_gate_accepts_only_approved_range(self):
        self.assertTrue(module.native_valid([1.,1.,1.1e-9],False))
        self.assertFalse(module.native_valid([1.,1.,1.10001e-9],False))
        self.assertFalse(module.native_valid([1.,1.,1e-10],True))
    def test_native_nonfinite_negative_or_zero_rhs_rejected(self):
        for norms in ([0,1,0],[1,-1,0],[1,1,-1],[1,1,float('nan')],[1,float('inf'),0],[float('nan'),1,0]):
            self.assertFalse(module.native_valid(norms,False))
    def test_forward_nan_hole_closed_and_limit_unchanged(self):
        self.assertTrue(module.forward_valid([1.,1.,1.1e-12],[.4,.02],False))
        for norms in ([1,1,float('nan')],[float('nan'),1,0],[1,-1,0],[1,1,1.2e-12]):
            self.assertFalse(module.forward_valid(norms,[.4,.02],False))
    def test_failed_forward_retains_null_and_raw_nan_evidence(self):
        ev=self.fake(forward_norms=(1.,1.,float('nan')))
        with contextlib.redirect_stdout(io.StringIO()),self.assertRaises(RuntimeError):ev.forward(np.zeros(39),'nan')
        record=json.loads((self.root/'forward_calls.json').read_text())[0]
        self.assertFalse(record['qualified']);self.assertIsNone(record['relative_residual'])
        self.assertEqual(record['raw_norms_repr'][-1],'nan')
    def test_accepted_native_stops_without_extra_refinement(self):
        ev=self.fake();gradient=self.gradient(ev)
        self.assertEqual(gradient.shape,(2,39));self.assertTrue(np.isfinite(gradient).all())
        self.assertEqual(len(ev.adjoint_attempts),2)
        self.assertTrue(all(r['qualified'] for r in ev.adjoint_calls))
        self.assertEqual(ev.adjoint_calls,ev.adjoint_attempts)
    def test_bounded_refinement_success_records_every_attempt(self):
        ev=self.fake([2e-9,5e-10,5e-10]);self.gradient(ev)
        self.assertEqual([r['attempt'] for r in ev.adjoint_attempts],[1,2,1])
        self.assertEqual(ev.adjoint_calls[0],ev.adjoint_attempts[1])
    def test_three_native_misses_abort_before_gradient_extraction(self):
        ev=self.fake([2e-9]*4)
        with self.assertRaises(RuntimeError):self.gradient(ev)
        self.assertEqual(len(ev.adjoint_attempts),3)
        self.assertFalse(ev.adjoint_calls[0]['qualified'])
        self.assertFalse((self.root/'gradient_progress.json').exists())
    def test_nonfinite_native_aborts_with_preserved_attempt(self):
        ev=self.fake([float('nan')])
        with self.assertRaises(RuntimeError):self.gradient(ev)
        records=json.loads((self.root/'native_attempts.json').read_text())
        self.assertEqual(len(records),1);self.assertFalse(records[0]['qualified'])
        self.assertIsNone(records[0]['final_residual_norm'])
    def test_process_exit_is_external_and_no_retry(self):
        args=SimpleNamespace(out=self.root,mode='anchor',index=0,manifest=Path('/frozen/manifest.json'),
            manifest_sha256='a'*64,preflight_only=False)
        process=SimpleNamespace(wait=lambda:7,pid=123)
        with patch.object(run_process.subprocess,'Popen',return_value=process),patch.object(run_process.signal,'signal'):
            self.assertEqual(run_process.run(args),2)
            with self.assertRaises(FileExistsError):run_process.run(args)
        record=json.loads((self.root/'anchor_0/process.json').read_text())
        self.assertEqual(record['return_code'],7);self.assertFalse(record['timed_out'])
        self.assertIn(str(run_process.HERE/'worker.py'),record['command'])


if __name__=='__main__':unittest.main()

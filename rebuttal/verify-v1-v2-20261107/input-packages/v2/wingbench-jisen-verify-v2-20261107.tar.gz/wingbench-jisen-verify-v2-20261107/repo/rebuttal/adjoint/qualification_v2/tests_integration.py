"""Synthetic integration-evidence audit tests. No CFD, MPI or original grading."""
from pathlib import Path
from types import SimpleNamespace
import copy
import json
import math
import tempfile
import unittest

from benchmark.common import load_box
from rebuttal.adjoint.qualification_v2 import regrade as r


def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,allow_nan=True))


class IntegrationAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.pilot=self.root/'pilot';self.checks=self.root/'checks'
        self.manifest=json.loads((r.ROOT/'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json').read_text())
        required=['serial_pilot.py','evaluator.py','protocol.json','run_integration.py','regrade.py']
        sources={'rebuttal/adjoint/qualification_v2/'+name:'a'*64 for name in required}
        self.manifest['source_sha256']=sources
        path=self.root/'manifest.json';write(path,self.manifest)
        self.args=SimpleNamespace(pilot=self.pilot,checks=self.checks,manifest=path,manifest_sha256=r.sha(path))
        self.fresh={'can_release_pilot':True,'evidence_sha256':'b'*64,
                    'manifest_sha256':self.args.manifest_sha256,'protocol_sha256':'c'*64}
        write(self.checks/'certificate.json',self.fresh)
        evidence=dict(self.fresh,kind='fresh_v2_raw_qualification',certificate_path=str(self.checks/'certificate.json'),
            certificate_sha256=r.sha(self.checks/'certificate.json'),actual_mesh_sha256=self.manifest['mesh']['sha256'],
            actual_runtime_sha256=self.manifest['expected_runtime_sha256'])
        box=load_box();geometry=self.manifest['geometry']['geometry']
        alphas=[float(a['reference']['realized_aoa_deg']) for a in self.manifest['anchors']]
        z0=box.to_standardized(geometry)
        bounds=[[max(-.1,-3.5-z),min(.1,3.5-z)] for z in z0]+[[max(-10,a-.5),min(25,a+.5)] for a in alphas]
        plan={'dry_run':False,'max_iterations':4,'max_joint_forward_evaluations':10,'mpi_ranks':16,
            'mach_execution_order':[0,1,2],'resident_evaluators':3,'strict_native_gate':1.1e-9,'forward_gate':1.1e-12,
            'lift_equalities':[.41]*3,'mesh_sha256':self.manifest['mesh']['sha256'],'source_sha256':sources,
            'qualification':{'allowed':True,'evidence':evidence},'bounds':bounds}
        write(self.pilot/'plan.json',plan)
        history=[]
        for index in range(2):
            x=[0.]*38+alphas;x[0]=index*.01
            values=[[.41,.02-index*.0001] for _ in range(3)]
            score=math.exp(sum(math.log(cl/cd) for cl,cd in values)/3)
            history.append({'x':x,'cl_cd':values,'score':score,'max_lift_error':0.,'eligible':True,'elapsed_seconds':index+1.})
        write(self.pilot/'history.json',history)
        selected=history[1]
        rec={'dry_run':False,'competitive_baseline_result':False,'joint_forward_evaluations':2,
            'individual_condition_forwards':6,'warped_mesh_result':selected,'initial_score':history[0]['score'],
            'geometry':[g+s*z for g,s,z in zip(geometry,box.sd,selected['x'][:38])],
            'optimization':{'success':False,'status':9,'message':'Iteration limit reached','iterations':4}}
        write(self.pilot/'recommendation.json',rec)
        write(self.pilot/'pilot_status.json',{'status':'integration_pilot_finished','exit_code':0,'optimizer_success':False})
        command=['mpirun','-np','16','python3','/workspace/repo/rebuttal/adjoint/qualification_v2/serial_pilot.py',
            '--manifest',str(path),'--manifest-sha256',self.args.manifest_sha256,'--out',str(self.pilot),
            '--checks',str(self.checks),'--mesh',self.manifest['mesh']['container_path']]
        write(self.pilot/'process.json',{'schema':'wingbench-adjoint-integration-process-v2','mode':'pilot',
            'return_code':0,'timed_out':False,'manifest_sha256':self.args.manifest_sha256,'command':command})
        for mach in range(3):
            leaf=self.pilot/('mach_'+str(mach))
            write(leaf/'setup.json',{'schema':'wingbench-adjoint-evaluator-v2','mach_index':mach,'ranks':16,
                'geometry':self.manifest['geometry'],'reference':self.manifest['anchors'][mach]['reference'],
                'forward_tolerance':1e-12,'adjoint_tolerance':1e-12,
                'forward_relative_residual_gate':1.1e-12,'adjoint_true_relative_residual_gate':1.1e-9})
            forwards=[]
            for index,item in enumerate(history,1):
                forwards.append({'call':index,'label':'pilot_'+str(index),'input':item['x'][:38]+[item['x'][38+mach]],
                    'cl':item['cl_cd'][mach][0],'cd':item['cl_cd'][mach][1],'raw_norms':[1.,1.,1e-13],
                    'relative_residual':1e-13,'qualified':True,'solve_failed':False,'forward_gate':1.1e-12,
                    'finite_flags':{'norms':True,'values':True}})
            write(leaf/'forward_calls.json',forwards)
            natives=[{'function':f,'attempt':1,'rhs_norm':1.,'starting_residual_norm':1.,'final_residual_norm':1e-10,
                'relative_residual':1e-10,'qualified':True,'failed':False,'solver_failed':False,
                'finite_norms':True,'native_gate':1.1e-9,'strict_native_gate':1.1e-9} for f in ('cl','cd')]
            for filename in ('native_attempts.json','native_finals.json','adjoint_calls.json'):write(leaf/filename,natives)

    def tearDown(self):self.temp.cleanup()
    def audit(self):return r.audit_trace(self.args,self.manifest,self.fresh)
    def change(self,relative,edit):
        path=self.pilot/relative;data=json.loads(path.read_text());edit(data);write(path,data)
    def blocked(self):
        with self.assertRaises((ValueError,KeyError,TypeError)):self.audit()
    def test_complete_trace_passes_without_claiming_convergence(self):
        report=self.audit();self.assertEqual(report['joint_trials'],2);self.assertEqual(report['gradient_calls_per_mach'],1)
    def test_forward_raw_ratio_overrides_claimed_pass(self):
        self.change('mach_0/forward_calls.json',lambda d:d[0]['raw_norms'].__setitem__(2,1e-8));self.blocked()
    def test_native_raw_ratio_overrides_claimed_pass(self):
        self.change('mach_0/native_attempts.json',lambda d:d[0].update(final_residual_norm=2e-9));self.blocked()
    def test_nonfinite_forward_rejected(self):
        self.change('mach_0/forward_calls.json',lambda d:d[0]['raw_norms'].__setitem__(0,float('nan')));self.blocked()
    def test_history_mach_coefficients_must_match_raw_forward(self):
        self.change('mach_1/forward_calls.json',lambda d:d[1].update(cd=.0198));self.blocked()
    def test_history_vector_must_match_raw_forward(self):
        self.change('mach_2/forward_calls.json',lambda d:d[1]['input'].__setitem__(13,.01));self.blocked()
    def test_geometry_must_be_selected_history_geometry(self):
        self.change('recommendation.json',lambda d:d['geometry'].__setitem__(0,d['geometry'][0]+.001));self.blocked()
    def test_bounds_change_rejected(self):
        self.change('plan.json',lambda d:d['bounds'][0].__setitem__(1,.2));self.blocked()
    def test_iteration_limit_rejected(self):
        self.change('recommendation.json',lambda d:d['optimization'].update(iterations=5));self.blocked()
    def test_claimed_call_count_must_match_trace(self):
        self.change('recommendation.json',lambda d:d.update(individual_condition_forwards=3));self.blocked()
    def test_one_point_is_insufficient_integration_coverage(self):
        self.change('history.json',lambda d:d.pop());self.blocked()
    def test_duplicate_trials_are_insufficient_integration_coverage(self):
        self.change('history.json',lambda d:d.__setitem__(1,copy.deepcopy(d[0])));self.blocked()
    def test_process_cannot_invoke_other_executable(self):
        self.change('process.json',lambda d:d['command'].__setitem__(4,'/workspace/old_pilot.py'));self.blocked()
    def test_certificate_hash_must_match_consumed_certificate(self):
        self.change('plan.json',lambda d:d['qualification']['evidence'].update(certificate_sha256='0'*64));self.blocked()
    def test_pilot_source_pin_must_match_manifest(self):
        self.change('plan.json',lambda d:d['source_sha256'].update({'rebuttal/adjoint/qualification_v2/serial_pilot.py':'f'*64}));self.blocked()
    def test_unaccounted_native_attempt_rejected(self):
        self.change('mach_0/native_attempts.json',lambda d:d.append(copy.deepcopy(d[-1])));self.blocked()


if __name__=='__main__':unittest.main()

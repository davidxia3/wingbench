#!/bin/bash
#SBATCH --account=p33116
#SBATCH --partition=short
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --mem=96G
#SBATCH --time=00:15:00
#SBATCH --array=0-2%3
#SBATCH --job-name=wb-v2-preflight
#SBATCH --output=/scratch/unk4211/wingbench-rebuttal-20261106/v2-preflight-%A-%a.log
set -euo pipefail
module load singularityce/4.3.1-gcc-8.5.0
export LD_LIBRARY_PATH="/gpfs/software/2025/spack/opt/spack/linux-rhel8-x86_64/gcc-8.5.0/libfuse-3.16.2-cg5xbdf2pwgqhdwoaujsoqaw2mhvjb3t/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
RUN_ROOT=/scratch/unk4211/wingbench-rebuttal-20261106
RUN_NAME=${1:?unique output-directory name}
MANIFEST_SHA256=${2:?externally bound manifest SHA256}
RELEASE_REPO=${QUALIFICATION_RELEASE_REPO:?isolated read-only release checkout}
TASK_INDEX=${SLURM_ARRAY_TASK_ID:?array index}
[[ "$RUN_NAME" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || exit 2
[[ "$MANIFEST_SHA256" =~ ^[0-9a-f]{64}$ ]] || exit 2
[[ "$RELEASE_REPO" == /* && -d "$RELEASE_REPO" ]] || exit 2
singularity exec --userns --cleanenv \
    --env "SLURM_JOB_ID=${SLURM_JOB_ID:-}" \
    --env "SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID:-}" \
    --bind "$RUN_ROOT:/workspace" --bind "$RELEASE_REPO:/workspace/repo:ro" \
    "$RUN_ROOT/runtime/mdolab-sandbox" \
    bash --noprofile --norc /workspace/repo/rebuttal/container_entry.sh bash -c '
        export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
        exec python3 /workspace/repo/rebuttal/adjoint/qualification_v2/run_process.py \
            --mode anchor --index "$3" --preflight-only \
            --manifest /workspace/repo/rebuttal/adjoint/qualification_v2/coverage_manifest.json \
            --manifest-sha256 "$2" --out "/workspace/adjoint/$1"
    ' _ "$RUN_NAME" "$MANIFEST_SHA256" "$TASK_INDEX"

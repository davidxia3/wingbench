"""One fresh v2 anchor or cold endpoint; never issues a qualification certificate."""
from pathlib import Path
import argparse
from datetime import datetime,timezone
import importlib.util
import json
import os
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from rebuttal.adjoint.qualification_v2.build_manifest import sha
from rebuttal.adjoint.qualification_v2.evaluator import write_json,FORWARD_GATE,NATIVE_GATE

SCHEMA='wingbench-adjoint-qualification-job-v2'
FLAGS={'qualification_completed':False,'can_release_pilot':False,'diagnostic_only':False}


def provenance(args):
    if sha(args.manifest)!=args.manifest_sha256:raise ValueError('Manifest external hash differs')
    manifest=json.loads(args.manifest.read_text())
    if (manifest.get('schema')!='wingbench-adjoint-qualification-v2' or
            manifest.get('phase')!='fresh_qualification_only' or
            any(manifest.get(k)!=v for k,v in FLAGS.items())):
        raise ValueError('Not a fresh v2 qualification manifest')
    required={'forward_target':1e-12,'forward_gate':FORWARD_GATE,'native_target':1e-12,
              'native_gate':NATIVE_GATE,'max_native_attempts':3,'ranks':16,
              'reference_relative_gate':.005}
    if any(manifest.get(k)!=v for k,v in required.items()):raise ValueError('V2 numerical settings differ')
    sources=manifest['source_sha256']
    for relative,expected in sources.items():
        path=Path(relative)
        if path.is_absolute() or '..' in path.parts:raise ValueError('Invalid source path')
        if sha(ROOT/path)!=expected:raise ValueError('Frozen source differs: '+relative)
    for relative in ('rebuttal/adjoint/qualification_v2/worker.py',
                     'rebuttal/adjoint/qualification_v2/evaluator.py',manifest['protocol']['path'],
                     'rebuttal/compute/jisen_verify_v1/preflight.py',
                     'rebuttal/compute/jisen_verify_v1/package_manifest.json'):
        if relative not in sources:raise ValueError('Required source omitted: '+relative)
    if sha(ROOT/manifest['protocol']['path'])!=manifest['protocol']['sha256']:
        raise ValueError('V2 numerical protocol hash differs')
    parent=manifest['parent_coverage'];base_path=ROOT/parent['path']
    if sha(base_path)!=parent['sha256']:raise ValueError('Parent coverage binding differs')
    base=json.loads(base_path.read_text())
    for key in ('mesh','geometry','normalization_scales','directions','anchors','points','forward_target',
                'forward_gate','native_target','max_native_attempts','reference_relative_gate','directional_rule'):
        if manifest[key]!=base[key]:raise ValueError('Frozen scientific coverage changed: '+key)
    package=json.loads((ROOT/'rebuttal/compute/jisen_verify_v1/package_manifest.json').read_text())
    if manifest['expected_runtime_sha256']!=package['runtime_expected_sha256']:
        raise ValueError('Nine-file runtime binding differs')
    if sha(Path(manifest['mesh']['container_path']))!=manifest['mesh']['sha256']:
        raise ValueError('Frozen qualification mesh differs')
    helper=ROOT/'rebuttal/compute/jisen_verify_v1/preflight.py'
    spec=importlib.util.spec_from_file_location('frozen_preflight',str(helper))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    runtime=module.runtime_record();runtime['hardware']=module.hardware_record()
    if any(runtime['sha256'].get(k)!=v for k,v in manifest['expected_runtime_sha256'].items()):
        raise ValueError('Scientific runtime hash differs')
    if runtime['cst_commit']!='9500b19a732463c26b32f6860ac6c517c7d212a5':raise ValueError('CST commit differs')
    if os.geteuid()==0:raise ValueError('Root execution is prohibited')
    if any(os.environ.get(name)!='1' for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')):
        raise ValueError('Exactly one thread per rank required')
    return manifest,runtime


def run(args):
    from mpi4py import MPI
    comm=MPI.COMM_WORLD
    leaf=('anchor_' if args.mode=='anchor' else 'point_')+str(args.index)
    out=args.out/leaf;started=time.monotonic();stage='provenance';ev=None;metadata=None;manifest=None
    if comm.rank==0:out.mkdir(parents=True,exist_ok=False)
    comm.barrier()
    try:
        outcome=None
        if comm.rank==0:
            try:
                manifest,runtime=provenance(args)
                outcome={'manifest':manifest,'runtime':runtime,'error':None}
            except BaseException as error:outcome={'error':type(error).__name__+': '+str(error)}
        outcome=comm.bcast(outcome,root=0)
        if outcome['error']:raise RuntimeError(outcome['error'])
        manifest=outcome['manifest'];runtime=outcome['runtime']
        if comm.size!=16:raise ValueError('Exactly16 MPI ranks required')
        spec=manifest['anchors' if args.mode=='anchor' else 'points'][args.index]
        metadata=dict(FLAGS,schema=SCHEMA,mode=args.mode,index=args.index,spec=spec,
            manifest_sha256=args.manifest_sha256,protocol_sha256=manifest['protocol']['sha256'],
            mesh_sha256=manifest['mesh']['sha256'],source_sha256=manifest['source_sha256'],
            code_sha256=manifest['source_sha256'],runtime=runtime,ranks=comm.size,
            forward_gate=FORWARD_GATE,native_gate=NATIVE_GATE,strict_native_gate=NATIVE_GATE,
            created_at_utc=datetime.now(timezone.utc).isoformat(),
            slurm_job_id=os.environ.get('SLURM_JOB_ID'),slurm_array_task_id=os.environ.get('SLURM_ARRAY_TASK_ID'),
            initialization='Fresh solver, no restart, exactly one cold forward solve')
        if comm.rank==0:write_json(out/'coverage_metadata.json',metadata)
        comm.barrier()
        if args.preflight_only:
            if comm.rank==0:write_json(out/'preflight.json',dict(metadata,preflight_passed=True,CFD_calls=0))
            return
        stage='initialization'
        from rebuttal.adjoint.qualification_v2.evaluator import Evaluator
        ev=Evaluator(comm,Path(manifest['mesh']['container_path']),out,spec['mach_index'])
        if (ev.solver.getOption('restartFile') is not None or ev.calls or ev.adjoint_calls or
                ev.adjoint_attempts or ev.last_y is not None):raise RuntimeError('Qualification solver is not cold')
        if ev.row!=manifest['geometry'] or ev.reference!=manifest['anchors'][spec['mach_index']]['reference']:
            raise ValueError('Evaluator control/reference differs from manifest')
        if comm.rank==0:
            setup=json.loads((out/'setup.json').read_text())
            setup.update(initialization=metadata['initialization'],execution_mode='v2_'+args.mode,
                         protocol_sha256=metadata['protocol_sha256'],manifest_sha256=args.manifest_sha256)
            write_json(out/'setup.json',setup)
        for name,expected in [('L2Convergence',1e-12),('adjointL2Convergence',1e-12),
            ('frozenTurbulence',False),('ADPC',True),('nCycles',3000),('nCyclesCoarse',500),
            ('adjointMaxIter',1000),('useANKSolver',True),('useNKSolver',True),('NKSwitchTol',1e-8)]:
            if ev.solver.getOption(name)!=expected:raise ValueError('Frozen solver option changed: '+name)
        stage='cold_forward';y=np.asarray(spec['input'],dtype=float)
        values=ev.forward(y,'anchor' if args.mode=='anchor' else spec['label'])
        norms=[float(v) for v in ev.solver.getResNorms()]
        if len(ev.calls)!=1:raise RuntimeError('Qualification requires exactly one cold forward')
        result=dict(FLAGS,schema=SCHEMA,mode=args.mode,index=args.index,spec=spec,
            manifest_sha256=args.manifest_sha256,protocol_sha256=manifest['protocol']['sha256'],
            coverage_job_completed=True,job_passed=True,gradient_usable=False,
            values=values.tolist(),forward=ev.calls[0],forward_norms=norms,forward_calls=1,
            native_attempts=[],native_finals=[],failed_native_gates=[])
        if args.mode=='anchor':
            reference=np.array([float(ev.reference['cl']),float(ev.reference['cd'])])
            relative=np.abs(values-reference)/np.abs(reference)
            reproduction={'values':values.tolist(),'reference':reference.tolist(),
                'relative_errors':relative.tolist(),
                'within_reference_limit':bool(np.isfinite(relative).all() and np.all(relative<=.005))}
            if comm.rank==0:write_json(out/'reproduction.json',reproduction)
            if not reproduction['within_reference_limit']:raise RuntimeError('Reference differs beyond0.5%')
            stage='qualified_gradient';gradient=ev.gradient(y,values)
            result.update(gradient_usable=True,gradient_cl_cd=gradient.tolist(),
                native_attempts=ev.adjoint_attempts,native_finals=ev.adjoint_calls,reproduction=reproduction)
        elif ev.adjoint_calls or ev.adjoint_attempts:raise RuntimeError('Cold endpoint must not call adjoints')
        result['wall_seconds']=time.monotonic()-started
        comm.barrier()
        if comm.rank==0:
            write_json(out/'coverage_result.json',result)
            print('V2_QUALIFICATION_JOB_COMPLETE',json.dumps({'mode':args.mode,'index':args.index}),flush=True)
        comm.barrier()
    except BaseException as error:
        if comm.rank==0:
            write_json(out/'coverage_result.json',dict(FLAGS,schema=SCHEMA,coverage_job_completed=False,
                job_passed=False,gradient_usable=False,mode=args.mode,index=args.index,
                manifest_sha256=args.manifest_sha256,
                protocol_sha256=manifest['protocol']['sha256'] if manifest else None,
                failed_stage=stage,error_type=type(error).__name__,error=str(error),
                forward_calls=len(ev.calls) if ev else 0,
                native_attempts=ev.adjoint_attempts if ev else [],native_finals=ev.adjoint_calls if ev else [],
                wall_seconds=time.monotonic()-started))
        raise


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--mode',choices=['anchor','point'],required=True)
    parser.add_argument('--index',type=int,required=True)
    parser.add_argument('--preflight-only',action='store_true')
    args=parser.parse_args()
    if args.index not in range(3 if args.mode=='anchor' else 36):parser.error('Index out of range')
    try:run(args)
    except BaseException:
        import traceback;traceback.print_exc()
        from mpi4py import MPI
        MPI.COMM_WORLD.Abort(1)

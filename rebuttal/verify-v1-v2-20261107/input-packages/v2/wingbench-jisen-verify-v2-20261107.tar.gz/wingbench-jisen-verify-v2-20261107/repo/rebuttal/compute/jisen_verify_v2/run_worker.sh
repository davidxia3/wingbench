#!/bin/bash
# Transport only: sample pod memory without changing worker numerical decisions.
set -euo pipefail
if [[ "$(id -u)" != 1000 ]]; then
  echo 'Jisen verification requires image UID1000.' >&2
  exit 64
fi
cd /workspace/repo
exec /bin/bash /workspace/repo/rebuttal/container_entry.sh \
 python3 /workspace/repo/rebuttal/compute/jisen_verify_v2/sampled_worker.py "$@"

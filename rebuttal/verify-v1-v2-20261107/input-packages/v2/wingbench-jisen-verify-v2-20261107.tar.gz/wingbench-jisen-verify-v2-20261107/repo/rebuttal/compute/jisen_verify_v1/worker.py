"""One predeclared verification batch. No retries, no campaign launcher."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
COVERAGE_MANIFEST = ROOT / 'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json'
MESH = Path('/workspace/validation-flow/V012/work/V012/mesh_attempt_00/V012/wing_vol.cgns')


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    tmp.replace(path)


def tasks():
    return ([{'id': 'anchor_'+str(i), 'kind': 'anchor', 'index': i,
              'pool': 'b' if i == 1 else 'a'} for i in range(3)] +
            [{'id': 'reference_'+pool, 'kind': 'reference', 'pool': pool} for pool in ('a','b')] +
            [{'id': 'point_'+str(i), 'kind': 'point', 'index': i, 'pool': None} for i in range(36)])


def resource_snapshot():
    from preflight import cgroup_resources
    result = {'cgroups': []}
    for row in cgroup_resources()['records']:
        path = Path(row['path'])
        values = {}
        for name in ('memory.current','memory.peak','memory.max_usage_in_bytes',
                     'memory.usage_in_bytes','cpu.stat','cpuacct.usage'):
            try: values[name] = (path/name).read_text().strip()
            except OSError: pass
        result['cgroups'].append({'path':str(path),'measurements':values})
    return result


def execute(command, log, env=None, timeout=None):
    start = time.time()
    before = resource_snapshot()
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('x') as stream:
        child = subprocess.Popen(command, cwd=str(ROOT), env=env, stdout=stream,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try: child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL); child.wait()
            code = 124
    elapsed = time.time()-start
    return {'command': command, 'return_code': code, 'timed_out': timed_out,
            'started_at_utc': datetime.fromtimestamp(start, timezone.utc).isoformat(),
            'wall_seconds': elapsed, 'allocated_core_hours':16*elapsed/3600,
            'resources_before':before,'resources_after':resource_snapshot(),
            'memory_note':'Cgroup peak is cumulative for this pod; per-task peaks cannot be isolated by subtraction.'}


def mpi(script, *args):
    return ['mpirun', '--bind-to', 'none', '-np', '16', sys.executable, str(script)] + [str(a) for a in args]


def main(args):
    shared = args.shared
    # This is a run directory exclusively created by the host launcher.
    plan = json.loads((shared / 'run_plan.json').read_text())
    if plan['workers'] not in (8, 10) or plan.get('run_campaign') is not False:
        raise RuntimeError('Invalid verification run plan')
    leaf = shared / 'workers' / (args.mode+'-'+str(args.worker_id))
    leaf.mkdir(parents=True, exist_ok=False)
    minimum_memory = 288 if args.mode == 'pilot' else 96
    env = dict(os.environ)
    for key in list(env):
        if key.startswith('ADFLOW_') or key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
            env.pop(key, None)
    solve_env = dict(env, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    pre = execute(mpi(HERE/'preflight.py', '--out', leaf/'preflight.json', '--shared', shared,
                      '--minimum-memory-gib', minimum_memory), leaf/'preflight.log', solve_env, timeout=300)
    write(leaf/'preflight_process.json', pre)
    if pre['return_code']:
        return 2
    if args.mode == 'pilot':
        gate = json.loads((shared/'qualification'/'certificate.json').read_text())
        if gate.get('strict_host_qualification_passed') is not True:
            write(leaf/'blocked.json', {'reason': 'Strict host qualification did not pass', 'passed': False})
            return 3
        command = mpi(HERE/'serial_pilot.py', '--mesh', MESH, '--checks', shared/'qualification',
                      '--out', shared/'pilot', '--preflight-report', leaf/'preflight.json')
        result = execute(command, leaf/'pilot.log', solve_env)
        write(leaf/'process.json', result)
        return result['return_code']
    if args.mode == 'regrade':
        if not (shared/'pilot'/'recommendation.json').is_file():
            write(leaf/'blocked.json', {'reason': 'No pilot recommendation', 'passed': False})
            return 3
        result = execute([sys.executable,str(HERE/'run_grade.py'),'--pilot',str(shared/'pilot'),
                          '--out',str(shared/'regrade')], leaf/'regrade.log', env)
        write(leaf/'process.json', result)
        return result['return_code']
    pool = 'a' if args.worker_id < 4 else 'b'
    if args.worker_id not in range(plan['workers']):
        raise RuntimeError('Worker id out of range')
    # All pods must observe all peers through the SAME shared filesystem before
    # CFD begins; this also starts the batch under the intended concurrent load.
    write(leaf/'ready.json', {'worker_id':args.worker_id,'node':args.node,
          'image':os.environ.get('WINGBENCH_IMAGE'), 'ready_at_utc':datetime.now(timezone.utc).isoformat()})
    deadline = time.monotonic()+600
    while True:
        ready_paths=[shared/'workers'/('worker-'+str(i))/'ready.json' for i in range(plan['workers'])]
        if all(p.is_file() for p in ready_paths):
            ready=[json.loads(p.read_text()) for p in ready_paths]
            if any(r['worker_id']!=i or r['node']!=plan['node_a' if i<4 else 'node_b'] for i,r in enumerate(ready)):
                raise RuntimeError('Cross-node worker identity/assignment mismatch')
            write(leaf/'barrier.json', {'passed':True,'workers_seen':ready,
                  'seen_at_utc':datetime.now(timezone.utc).isoformat()})
            break
        if time.monotonic()>deadline:
            write(leaf/'blocked.json', {'passed':False,'reason':'Not all worker preflights/shared storage visible within10minutes'})
            return 2
        time.sleep(3)
    claims = shared/'claims'; claims.mkdir(exist_ok=True)
    processed = []
    for task in tasks():
        if task['pool'] is not None and task['pool'] != pool:
            continue
        claim = claims/task['id']
        try:
            claim.mkdir()
        except FileExistsError:
            continue
        write(claim/'owner.json', {'worker_id': args.worker_id, 'node': args.node, 'task': task})
        if task['kind'] in ('anchor','point'):
            command = mpi(ROOT/'rebuttal/adjoint/coverage_observed_run.py', 'run',
                          '--mode',task['kind'],'--index',task['index'],'--manifest',COVERAGE_MANIFEST,
                          '--out',shared/'coverage')
            task_env = solve_env
        else:
            command = [sys.executable,str(HERE/'run_grade.py'),'--out',str(shared/task['id'])]
            task_env = env
        result = execute(command, claim/'full.log', task_env)
        result.update(task=task, worker_id=args.worker_id, node=args.node)
        write(claim/'process.json', result)
        processed.append(task['id'])
        # A numerical failure is retained; independent scheduled checks still run.
    write(leaf/'worker_finished.json', {'worker_id':args.worker_id,'processed':processed,
          'batch_processing_finished':True,'scientific_pass':False,'can_launch_campaign':False})
    return 0


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--shared', type=Path, required=True)
    p.add_argument('--worker-id', type=int, required=True)
    p.add_argument('--node', required=True)
    p.add_argument('--mode', choices=['worker','pilot','regrade'], default='worker')
    sys.exit(main(p.parse_args()))

#!/bin/bash
#SBATCH --account=p33116
#SBATCH --partition=normal
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --mem=96G
#SBATCH --time=12:00:00
#SBATCH --job-name=wb-v2-regrade
#SBATCH --output=/scratch/unk4211/wingbench-rebuttal-20261106/v2-regrade-%j.log
set -euo pipefail
module load singularityce/4.3.1-gcc-8.5.0
export LD_LIBRARY_PATH="/gpfs/software/2025/spack/opt/spack/linux-rhel8-x86_64/gcc-8.5.0/libfuse-3.16.2-cg5xbdf2pwgqhdwoaujsoqaw2mhvjb3t/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
RUN_ROOT=/scratch/unk4211/wingbench-rebuttal-20261106
RUN_NAME=${1:?unique output-directory name}
MANIFEST_SHA256=${2:?externally bound manifest SHA256}
RELEASE_REPO=${QUALIFICATION_RELEASE_REPO:?isolated read-only release checkout}
CHECKS_NAME=${3:?qualification output name}
PILOT_NAME=${4:?pilot output name}
[[ "$PILOT_NAME" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || exit 2
[[ "$CHECKS_NAME" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || exit 2
[[ "$RUN_NAME" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || exit 2
[[ "$MANIFEST_SHA256" =~ ^[0-9a-f]{64}$ ]] || exit 2
[[ "$RELEASE_REPO" == /* && -d "$RELEASE_REPO" ]] || exit 2
singularity exec --userns --cleanenv \
    --env "SLURM_JOB_ID=${SLURM_JOB_ID:-}" \
    --env "SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID:-}" \
    --bind "$RUN_ROOT:/workspace" --bind "$RELEASE_REPO:/workspace/repo:ro" \
    "$RUN_ROOT/runtime/mdolab-sandbox" \
    bash --noprofile --norc /workspace/repo/rebuttal/container_entry.sh bash -c '
        exec python3 /workspace/repo/rebuttal/adjoint/qualification_v2/run_integration.py \
            --mode regrade --pilot "/workspace/adjoint/$4" --checks "/workspace/adjoint/$3" \
            --manifest /workspace/repo/rebuttal/adjoint/qualification_v2/coverage_manifest.json \
            --manifest-sha256 "$2" --out "/workspace/adjoint/$1"
    ' _ "$RUN_NAME" "$MANIFEST_SHA256" "$CHECKS_NAME" "$PILOT_NAME"

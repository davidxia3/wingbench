"""Record the actual MPI process exit separately from numerical worker output."""
from pathlib import Path
import argparse
from datetime import datetime,timezone
import json
import os
import signal
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent


def now():return datetime.now(timezone.utc).isoformat()


def run(args):
    leaf=('anchor_' if args.mode=='anchor' else 'point_')+str(args.index)
    directory=args.out/leaf
    if directory.exists():raise FileExistsError('Existing qualification leaf cannot be retried')
    args.out.mkdir(parents=True,exist_ok=True)
    claim=args.out/('.launch_'+leaf+'.json')
    command=['mpirun','-np','16',sys.executable,str(HERE/'worker.py'),
        '--manifest',str(args.manifest),'--manifest-sha256',args.manifest_sha256,
        '--out',str(args.out),'--mode',args.mode,'--index',str(args.index)]
    if args.preflight_only:command.append('--preflight-only')
    report={'schema':'wingbench-adjoint-process-v2','mode':args.mode,'index':args.index,
        'manifest_sha256':args.manifest_sha256,'command':command,'started_at_utc':now(),
        'slurm_job_id':os.environ.get('SLURM_JOB_ID'),
        'slurm_array_task_id':os.environ.get('SLURM_ARRAY_TASK_ID'),
        'return_code':None,'timed_out':False,'preflight_only':args.preflight_only}
    with claim.open('x') as stream:
        stream.write(json.dumps(report,indent=2)+'\n');stream.flush();os.fsync(stream.fileno())
    process=None;start=time.monotonic()
    def terminate(signum,frame):
        report['timed_out']=True;report['termination_signal']=signum
        if process is not None:
            try:os.killpg(process.pid,signum)
            except ProcessLookupError:pass
    signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
    try:
        process=subprocess.Popen(command,start_new_session=True)
        report['return_code']=process.wait()
    except BaseException as error:
        report.update(return_code=125,error=type(error).__name__+': '+str(error))
    report.update(finished_at_utc=now(),wall_seconds=time.monotonic()-start)
    directory.mkdir(parents=True,exist_ok=True)
    with (directory/'process.json').open('x') as stream:
        stream.write(json.dumps(report,indent=2,allow_nan=False)+'\n');stream.flush();os.fsync(stream.fileno())
    return 0 if report['return_code']==0 and not report['timed_out'] else 2


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',type=Path,required=True);p.add_argument('--manifest-sha256',required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--mode',choices=['anchor','point'],required=True)
    p.add_argument('--index',type=int,required=True);p.add_argument('--preflight-only',action='store_true')
    a=p.parse_args()
    if a.index not in range(3 if a.mode=='anchor' else 36):p.error('Index out of range')
    sys.exit(run(a))

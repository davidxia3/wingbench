#!/usr/bin/env python3
"""Render (never submit) digest-pinned Kubernetes Jobs as a JSON List.

Run one phase at a time. The launcher must await all workers and read the strict
certificate before creating the pilot, then await its result before regrading.
An observed-coverage summary is not permission to launch a pilot.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--image', required=True, help='Registry image@sha256:64hex; tags refused')
    p.add_argument('--pvc', required=True, help='Existing shared ReadWriteMany PVC')
    p.add_argument('--node-a', required=True, help='Exact kubernetes.io/hostname label')
    p.add_argument('--node-b', required=True, help='Exact kubernetes.io/hostname label')
    p.add_argument('--workers', type=int, choices=(8, 10), default=8)
    p.add_argument('--namespace', default='default')
    p.add_argument('--run-id', required=True, help='Fresh DNS label, at most 40 characters')
    p.add_argument('--shared-dir', help='Absolute result directory under /results; default /results/RUN_ID')
    p.add_argument('--phase', choices=('workers', 'pilot', 'regrade'), default='workers')
    p.add_argument('--image-pull-secret', action='append', default=[])
    p.add_argument('--toleration', action='append', default=[], metavar='KEY=VALUE:EFFECT',
                   help='Repeatable Equal toleration; affects workers, pilot and regrade')
    p.add_argument('--output', type=Path, help='Write JSON here; otherwise stdout')
    return p


def parse_tolerations(values):
    result = []
    for text in values:
        match = re.fullmatch(r'([^=:]+)=([^:]*):(NoSchedule|PreferNoSchedule|NoExecute)', text)
        if not match:
            raise ValueError('Expected --toleration KEY=VALUE:EFFECT: ' + text)
        key, value, effect = match.groups()
        parts = key.split('/')
        if len(parts) > 2:
            raise ValueError('Invalid toleration key: ' + key)
        name = parts[-1]
        label = r'[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,61}[A-Za-z0-9])?'
        if not re.fullmatch(label, name) or (value and not re.fullmatch(label, value)):
            raise ValueError('Invalid toleration key/value: ' + text)
        if len(parts) == 2:
            prefix = parts[0]
            if len(prefix) > 253 or not prefix or any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', x) for x in prefix.split('.')):
                raise ValueError('Invalid toleration DNS prefix: ' + key)
        row = {'key': key, 'operator': 'Equal', 'value': value, 'effect': effect}
        if row in result:
            raise ValueError('Duplicate toleration: ' + text)
        result.append(row)
    return result


def render(args):
    if not re.fullmatch(r'[^\s@]+@sha256:[0-9a-f]{64}', args.image):
        raise ValueError('--image must pin the final uploaded image by SHA256 digest')
    if not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?', args.run_id):
        raise ValueError('--run-id must be a lowercase DNS label of at most 40 characters')
    if args.node_a == args.node_b:
        raise ValueError('The 4+4/4+6 plan requires two distinct nodes')
    shared = args.shared_dir or '/results/' + args.run_id
    if not shared.startswith('/results/') or '..' in Path(shared).parts:
        raise ValueError('--shared-dir must be a new subdirectory of /results')
    if args.phase == 'workers':
        allocations = [(str(i), args.node_a if i < 4 else args.node_b, 96, 'worker')
                       for i in range(args.workers)]
    else:
        allocations = [('0', args.node_b, 288 if args.phase == 'pilot' else 96, args.phase)]
    tolerations = parse_tolerations(getattr(args, 'toleration', []))
    jobs = []
    for worker_id, node, memory, mode in allocations:
        suffix = 'w' + worker_id.zfill(2) if mode == 'worker' else mode
        name = args.run_id + '-' + suffix
        labels = {'app.kubernetes.io/name': 'wingbench-jisen-verify',
                  'wingbench-run': args.run_id, 'wingbench-phase': args.phase,
                  'wingbench-worker': worker_id}
        pod = {
            'restartPolicy': 'Never',
            'automountServiceAccountToken': False,
            'enableServiceLinks': False,
            'terminationGracePeriodSeconds': 120,
            'nodeSelector': {'kubernetes.io/hostname': node, 'kubernetes.io/arch': 'amd64'},
            'securityContext': {'runAsUser': 1000, 'runAsGroup': 1000,
                                'runAsNonRoot': True, 'fsGroup': 1000,
                                'fsGroupChangePolicy': 'OnRootMismatch',
                                'seccompProfile': {'type': 'RuntimeDefault'}},
            'containers': [{
                'name': 'worker', 'image': args.image, 'imagePullPolicy': 'IfNotPresent',
                'args': ['--shared', shared, '--worker-id', worker_id,
                         '--node', node, '--mode', mode],
                'securityContext': {'allowPrivilegeEscalation': False,
                                    'capabilities': {'drop': ['ALL']}},
                'resources': {'requests': {'cpu': '16', 'memory': str(memory) + 'Gi'},
                              'limits': {'cpu': '16', 'memory': str(memory) + 'Gi'}},
                'env': [
                    {'name': 'WINGBENCH_IMAGE', 'value': args.image},
                    {'name': 'WINGBENCH_RUN_ID', 'value': args.run_id},
                    {'name': 'WINGBENCH_REQUESTED_CPU', 'value': '16'},
                    {'name': 'WINGBENCH_MEMORY_GIB', 'value': str(memory)},
                    {'name': 'WINGBENCH_WORKERS', 'value': str(args.workers)},
                    {'name': 'WINGBENCH_POD_NAME', 'valueFrom': {'fieldRef': {'fieldPath': 'metadata.name'}}},
                    {'name': 'WINGBENCH_NODE_NAME', 'valueFrom': {'fieldRef': {'fieldPath': 'spec.nodeName'}}},
                ],
                'volumeMounts': [{'name': 'results', 'mountPath': '/results'},
                                 {'name': 'shm', 'mountPath': '/dev/shm'}],
            }],
            'volumes': [{'name': 'results', 'persistentVolumeClaim': {'claimName': args.pvc}},
                        {'name': 'shm', 'emptyDir': {'medium': 'Memory', 'sizeLimit': '2Gi'}}],
        }
        if tolerations:
            pod['tolerations'] = [dict(row) for row in tolerations]
        if args.image_pull_secret:
            pod['imagePullSecrets'] = [{'name': name} for name in args.image_pull_secret]
        jobs.append({'apiVersion': 'batch/v1', 'kind': 'Job',
                     'metadata': {'name': name, 'namespace': args.namespace, 'labels': labels,
                                  'annotations': {'wingbench/scope': 'verification-only; no baseline episodes',
                                                  'wingbench/cpu-unit-caveat': '16 Kubernetes CPU units; physical-core exclusivity requires operator confirmation'}},
                     'spec': {'backoffLimit': 0, 'completions': 1, 'parallelism': 1,
                              'template': {'metadata': {'labels': labels}, 'spec': pod}}})
    return {'apiVersion': 'v1', 'kind': 'List', 'items': jobs}


def main():
    p = parser()
    args = p.parse_args()
    try:
        output = json.dumps(render(args), indent=2) + '\n'
    except ValueError as exc:
        p.error(str(exc))
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open('x') as stream:
            stream.write(output)
    else:
        print(output, end='')


if __name__ == '__main__':
    main()

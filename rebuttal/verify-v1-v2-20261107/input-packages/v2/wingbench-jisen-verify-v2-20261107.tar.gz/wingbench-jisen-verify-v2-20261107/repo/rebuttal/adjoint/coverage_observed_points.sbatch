#!/bin/bash
#SBATCH --account=p33116
#SBATCH --partition=normal
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --mem=64G
#SBATCH --time=08:00:00
#SBATCH --array=0-35%8
#SBATCH --job-name=wb-observed-points
#SBATCH --output=/scratch/unk4211/wingbench-rebuttal-20261106/observed-points-%A-%a.log
set -euo pipefail
module load singularityce/4.3.1-gcc-8.5.0
export LD_LIBRARY_PATH="/gpfs/software/2025/spack/opt/spack/linux-rhel8-x86_64/gcc-8.5.0/libfuse-3.16.2-cg5xbdf2pwgqhdwoaujsoqaw2mhvjb3t/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
RUN_ROOT=/scratch/unk4211/wingbench-rebuttal-20261106
RUN_NAME=${1:?unique output-directory name}
MANIFEST_NAME=${2:?frozen manifest basename in repo/rebuttal/adjoint}
TASK_INDEX=${SLURM_ARRAY_TASK_ID:?point array index}
[[ "$RUN_NAME" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || exit 2
[[ "$MANIFEST_NAME" =~ ^coverage_observed_[A-Za-z0-9._-]+\.json$ ]] || exit 2
singularity exec --userns --cleanenv --bind "$RUN_ROOT:/workspace" "$RUN_ROOT/runtime/mdolab-sandbox" bash --noprofile --norc /workspace/repo/rebuttal/container_entry.sh bash -c '
    export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
    exec mpirun -np 16 python3 rebuttal/adjoint/coverage_observed_run.py run --mode point --index "$3" --manifest "/workspace/repo/rebuttal/adjoint/$2" --out "/workspace/adjoint/$1"
' _ "$RUN_NAME" "$MANIFEST_NAME" "$TASK_INDEX"

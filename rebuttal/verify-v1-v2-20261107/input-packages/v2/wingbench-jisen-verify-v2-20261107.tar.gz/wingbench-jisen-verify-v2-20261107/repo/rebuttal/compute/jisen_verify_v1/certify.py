"""Independent strict host certification; observations never release a pilot.

Recompute numerical gates and bind raw worker/process/provenance evidence to the
frozen package. Missing or malformed evidence fails closed. No jobs are started.
"""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import json
import math
import re
import sys

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
CONTAINER_ROOT = Path('/workspace/repo')
sys.path.insert(0, str(ROOT))
from rebuttal.adjoint.coverage_observed_summary import summarize

COVERAGE_SHA = '52dc6c65fb29582c25108b78fd14536577cc8c02c0c2daa27ef5cebab7b927ee'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def finite(value):
    if isinstance(value, float): return math.isfinite(value)
    if isinstance(value, dict): return all(finite(v) for v in value.values())
    if isinstance(value, list): return all(finite(v) for v in value)
    return True


def require(condition, message):
    if not condition: raise ValueError(message)


def timestamp(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None, 'Timestamp lacks timezone')
    return result.timestamp()


def close(a, b):
    return math.isfinite(float(a)) and math.isfinite(float(b)) and math.isclose(float(a), float(b), rel_tol=1e-12, abs_tol=1e-14)


def certify(shared, emit=False):
    shared = Path(shared).resolve()
    evidence, errors, numerical_errors, process_failures = {}, [], [], []
    manifest_path = ROOT/'rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json'
    protocol_path, package_path = HERE/'numerical_protocol.json', HERE/'package_manifest.json'
    def read(path):
        try:
            raw = path.read_bytes()
            value = json.loads(raw)
            require(isinstance(value, dict) and finite(value), 'Expected finite JSON object')
            try: key = str(path.relative_to(shared))
            except ValueError: key = 'source/'+str(path.relative_to(ROOT))
            evidence[key] = hashlib.sha256(raw).hexdigest()
            return value
        except (OSError, ValueError, TypeError) as exc:
            errors.append('{}: {}'.format(path, exc)); return {}
    manifest, protocol, package = read(manifest_path), read(protocol_path), read(package_path)
    protocol_hash = evidence.get('source/'+str(protocol_path.relative_to(ROOT)))
    package_hash = evidence.get('source/'+str(package_path.relative_to(ROOT)))
    mesh, runtime_expected, expected_files, grader_protocol = manifest.get('mesh', {}), {}, {}, {}
    try:
        require(sha(manifest_path) == COVERAGE_SHA, 'Frozen coverage manifest changed')
        require(package['protocol_sha256'] == protocol_hash, 'Package protocol binding changed')
        sources = package['source_sha256']
        require(isinstance(sources, dict) and bool(sources), 'Package sources absent')
        for name in ('certify.py','worker.py','preflight.py','run_grade.py','numerical_protocol.json'):
            require(str((HERE/name).relative_to(ROOT)) in sources, 'Package does not pin '+name)
        for relative, digest in sources.items():
            path = Path(relative)
            require(not path.is_absolute() and '..' not in path.parts, 'Unsafe source path')
            require(re.fullmatch('[0-9a-f]{64}', digest) and sha(ROOT/path) == digest, 'Changed package source '+relative)
            expected_files[str(CONTAINER_ROOT/path)] = digest
        for relative, digest in manifest['source_sha256'].items():
            require(sha(ROOT/relative) == digest, 'Changed coverage source '+relative)
            expected_files[str(CONTAINER_ROOT/relative)] = digest
        expected_files[str(CONTAINER_ROOT/manifest_path.relative_to(ROOT))] = COVERAGE_SHA
        expected_files[mesh['container_path']] = mesh['sha256']
        for asset in package.get('assets', []):
            require(Path(asset['path']).is_absolute(), 'Asset path is not absolute')
            if asset['path'] in expected_files:
                require(expected_files[asset['path']] == asset['sha256'], 'Asset overrides existing pin')
            expected_files[asset['path']] = asset['sha256']
        runtime_expected = dict(manifest['expected_runtime_sha256'])
        for key, value in package.get('runtime_expected_sha256', {}).items():
            require(key not in runtime_expected or runtime_expected[key] == value, 'Runtime pin overridden')
            runtime_expected[key] = value
        q = protocol['qualification']
        require(q['native_gate'] == 1.1e-11 and q['forward_gate'] == 1.1e-12 and q['reference_relative_error_max'] == .005,
                'Frozen qualification thresholds changed')
        require(q['reference_control'] == manifest['geometry'] and q['reference_conditions'] == manifest['anchors'] and
                q['directions'] == manifest['directions'] and q['steps'] == [.002,.001], 'Protocol/coverage problem differs')
        grader_path = ROOT/protocol['original_grader']['base_protocol']
        require(sha(grader_path) == protocol['original_grader']['protocol_sha256'], 'Original grader protocol changed')
        grader_protocol = read(grader_path)
        expected_files[str(CONTAINER_ROOT/grader_path.relative_to(ROOT))] = protocol['original_grader']['protocol_sha256']
    except (KeyError, TypeError, ValueError, OSError) as exc:
        errors.append('Frozen package: '+str(exc))
    plan = read(shared/'run_plan.json')
    workers = plan.get('workers')
    try:
        require(type(workers) is int and workers in (8,10) and plan.get('run_campaign') is False, 'Invalid worker plan')
        require(plan['node_a'] and plan['node_b'] and plan['node_a'] != plan['node_b'], 'Two distinct declared nodes required')
        require(re.fullmatch(r'[^\s@]+@sha256:[0-9a-f]{64}', plan['image']) is not None, 'Unpinned image')
        require(plan['protocol_sha256'] == protocol_hash, 'Run plan protocol differs')
    except (KeyError, TypeError, ValueError) as exc:
        errors.append('Run plan: '+str(exc)); workers = 0
    ready, barriers, preflights, finished_records = [], [], [], []
    for i in range(workers):
        leaf = shared/'workers'/('worker-'+str(i))
        ready.append(read(leaf/'ready.json'))
        barriers.append(read(leaf/'barrier.json'))
        preflights.append(read(leaf/'preflight.json'))
        process = read(leaf/'preflight_process.json')
        finished_records.append(read(leaf/'worker_finished.json'))
        pre = preflights[-1]
        try:
            node = plan['node_a'] if i < 4 else plan['node_b']
            require(ready[-1]['worker_id'] == i and ready[-1]['node'] == node and ready[-1]['image'] == plan['image'], 'Ready identity/image mismatch')
            require(pre['passed'] is True and not pre['errors'] and process['return_code'] == 0 and not process.get('timed_out', False), 'Preflight failed')
            require(pre['node_name'] == node and pre['image_declared'] == plan['image'], 'Preflight node/image mismatch')
            require(pre['requested_ranks'] == 16 and pre['rank_sum'] == 120 and len(pre['ranks']) == 16, 'Preflight rank inventory mismatch')
            for r, rank in enumerate(pre['ranks']):
                require(rank['rank'] == r and rank['world_size'] == 16 and rank['uid'] == 1000 and not rank['errors'], 'Rank checks failed')
                require(all(rank['thread_environment'][key] == '1' for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')), 'Thread count changed')
                require('Open MPI v4.1.6' in rank['mpi_library_version'], 'MPI version changed')
                hw = rank['hardware']
                require(len(hw['affinity_logical_cpus']) >= 16 and hw['affinity_physical_core_count'] >= 16 and
                        hw['cgroup']['cpu_quota_units'] >= 16 and hw['cgroup']['memory_limit_bytes'] >= 96*1024**3, 'Worker resources insufficient')
            require(len({r['hardware']['hostname'] for r in pre['ranks']}) == 1, 'Ranks spread across pods')
            provenance = pre['provenance']
            require(provenance['package_manifest_sha256'] == package_hash and provenance['protocol_sha256'] == protocol_hash, 'Preflight package/protocol mismatch')
            files = provenance['files']
            file_map = {}
            for item in files:
                require(item['passed'] is True and item['actual_sha256'] == item['expected_sha256'], 'Preflight file mismatch')
                require(item['path'] not in file_map or file_map[item['path']] == item['actual_sha256'], 'Conflicting file evidence')
                file_map[item['path']] = item['actual_sha256']
            require(all(file_map.get(path) == digest for path,digest in expected_files.items()), 'Preflight omitted/changed frozen file pin')
            runtime = provenance['runtime']
            require(all(runtime['sha256'].get(key) == value for key,value in runtime_expected.items()), 'Preflight runtime pin changed')
            if i:
                require(runtime['sha256'] == preflights[0]['provenance']['runtime']['sha256'], 'Full runtime map varies across workers')
            require(runtime['python'] == '3.9.12' and runtime['petsc_version'] == [3,15,5] and
                    'Open MPI) 4.1.6' in runtime['mpirun_version'] and runtime['cst_commit'] == protocol['package_runtime']['cst_commit'], 'Runtime version changed')
            require(all(runtime['modules'][key]['version'] == value for key,value in {'numpy':'1.21.5','scipy':'1.7.3','mpi4py':'3.1.5'}.items()), 'Module version changed')
            fs = pre['filesystems']
            require(len(fs) == 2 and all(all(row.get(key) is True for key in ('passed','exclusive_create','atomic_rename_readback','exclusive_mkdir','flock_excludes_second_process','flock_released')) for row in fs), 'Filesystem checks failed')
            require(finished_records[-1]['batch_processing_finished'] is True and finished_records[-1]['worker_id'] == i, 'Worker unfinished')
        except (KeyError, TypeError, ValueError, IndexError) as exc:
            errors.append('Worker{}: {}'.format(i, exc))
    for i, barrier in enumerate(barriers):
        try:
            require(barrier['passed'] is True and barrier['workers_seen'] == ready, 'Cross-node ready inventory differs')
            require(timestamp(barrier['seen_at_utc']) >= max(timestamp(r['ready_at_utc']) for r in ready), 'Barrier preceded all workers')
        except (KeyError, TypeError, ValueError) as exc: errors.append('Worker{} barrier: {}'.format(i,exc))
    task_specs = ([{'id':'anchor_'+str(i),'kind':'anchor','index':i,'pool':'b' if i == 1 else 'a'} for i in range(3)] +
                  [{'id':'reference_'+p,'kind':'reference','pool':p} for p in ('a','b')] +
                  [{'id':'point_'+str(i),'kind':'point','index':i,'pool':None} for i in range(36)])
    claimed_by = {i:[] for i in range(workers)}
    for task in task_specs:
        owner = read(shared/'claims'/task['id']/'owner.json')
        proc = read(shared/'claims'/task['id']/'process.json')
        try:
            i = owner['worker_id']
            require(type(i) is int and i in range(workers), 'Invalid owner')
            node = plan['node_a'] if i < 4 else plan['node_b']
            require(owner['task'] == task and proc['task'] == task and proc['worker_id'] == i and owner['node'] == node and proc['node'] == node, 'Task ownership mismatch')
            require(task['pool'] is None or task['pool'] == ('a' if i < 4 else 'b'), 'Task ran in wrong pool')
            require(proc['return_code'] == 0 and proc.get('timed_out') is False and float(proc['wall_seconds']) >= 0, 'Task process failed')
            require(timestamp(proc['started_at_utc']) >= timestamp(barriers[i]['seen_at_utc']), 'Task started before all-worker barrier')
            require(isinstance(proc['command'],list) and bool(proc['command']), 'Missing executed command')
            claimed_by[i].append(task['id'])
        except (KeyError, TypeError, ValueError, IndexError) as exc:
            process_failures.append({'task':task['id'],'error':str(exc)})
    for i in range(workers):
        if sorted(finished_records[i].get('processed',[])) != sorted(claimed_by[i]):
            errors.append('Worker{} processed inventory differs from claims'.format(i))
    control_checks = []
    for pool in ('a','b'):
        report = read(shared/('reference_'+pool)/'verification_result.json')
        raw = read(shared/('reference_'+pool)/'grade.json')
        try:
            require(report['passed'] is True and report['delivered'] is True and report['kind'] == 'original_grader_control' and report['relative_gate'] == .005, 'Control report failed')
            require(bool(grader_protocol) and raw['protocol']['snapshot'] == grader_protocol, 'Control used a different grading protocol')
            require(raw['geometry']['geom_38d'] == manifest['geometry']['geometry'] and raw['geometry']['sha256'] == manifest['geometry']['wing'], 'Control geometry differs')
            require(raw['mesh']['outcome'] == 'valid' and raw['benchmark_grade']['delivered'] is True and raw['benchmark_grade']['outcome'] == 'pass', 'Original grader did not deliver')
            conditions = sorted(raw['conditions'],key=lambda c:float(c['mach']))
            require(len(conditions) == 3, 'Three control conditions required')
            lds, comparisons = [], []
            for condition, anchor in zip(conditions,manifest['anchors']):
                ref, measured = anchor['reference'], condition['measurements']
                require(float(condition['mach']) == float(ref['mach']) and condition['cl_target'] == .41 and condition['outcome_class'] == 'valid', 'Control condition mismatch')
                cl, cd, ld, alpha = [float(measured[k]) for k in ('cl','cd','ld','realized_aoa_deg')]
                require(all(math.isfinite(v) for v in (cl,cd,ld,alpha)) and cd > 0 and 0 < ld <= 40 and close(ld,cl/cd) and abs(cl-.41) <= .02 and -10 <= alpha <= 25, 'Invalid control measurements')
                delta = {k:abs(float(measured[k])-float(ref[k]))/abs(float(ref[k])) for k in ('cl','cd')}
                require(all(e <= .005 for e in delta.values()), 'Control coefficient reference comparison failed')
                comparisons.append({'mach':float(ref['mach']),'relative_errors':delta,'within_limit':True}); lds.append(ld)
            score = math.exp(sum(math.log(v) for v in lds)/3)
            require(close(raw['benchmark_grade']['ld'],score) and close(report['original_score'],score), 'Control score mismatch')
            saved = report['comparisons']
            require(len(saved)==3 and all(s['mach']==c['mach'] and s['within_limit'] is True and all(close(s['relative_errors'][k],c['relative_errors'][k]) for k in ('cl','cd')) for s,c in zip(saved,comparisons)), 'Control comparison report mismatch')
            control_checks.append({'pool':pool,'passed':True,'score':score,'comparisons':comparisons})
        except (KeyError,TypeError,ValueError,IndexError,ZeroDivisionError) as exc:
            control_checks.append({'pool':pool,'passed':False,'error':str(exc)})
    controls_pass = len(control_checks)==2 and all(c['passed'] for c in control_checks)
    try: cov = summarize(shared/'coverage', manifest_path)
    except (OSError,KeyError,TypeError,ValueError,IndexError,ZeroDivisionError) as exc:
        cov = {}; numerical_errors.append('Coverage summary failed: '+str(exc))
    for path, digest in cov.get('evidence_sha256',{}).items():
        try: key = str(Path(path).relative_to(shared))
        except ValueError: key = 'source/'+str(Path(path).relative_to(ROOT))
        evidence[key] = digest
    if (cov.get('summary_status') != 'observations_complete' or cov.get('comparison_count') != 18 or
            cov.get('valid_anchor_jobs') != 3 or cov.get('valid_point_jobs') != 36 or
            cov.get('all_components_within_original_limits') is not True or cov.get('missing') or cov.get('evidence_errors') or cov.get('failed_jobs')):
        numerical_errors.append('Complete valid39-job coverage required')
    if cov.get('failed_native_gates'): numerical_errors.append('Final native adjoint misses unchanged1.1e-11 gate')
    for key,value in runtime_expected.items():
        if key in manifest.get('expected_runtime_sha256',{}) and (cov.get('runtime_sha256') or {}).get(key) != value:
            numerical_errors.append('Coverage runtime differs from frozen pin: '+key)
    observed_runtime = preflights[0].get('provenance',{}).get('runtime',{}).get('sha256',{}) if preflights else {}
    for key,value in (cov.get('runtime_sha256') or {}).items():
        if observed_runtime.get(key) != value:
            numerical_errors.append('Coverage runtime differs from worker runtime: '+key)
    finals = []
    for mach in range(3):
        anchor = read(shared/'coverage'/('anchor_'+str(mach))/'coverage_result.json')
        native = anchor.get('native_finals',[])
        if not isinstance(native,list): native=[]
        if len(native)!=2 or [r.get('function') for r in native if isinstance(r,dict)] != ['cl','cd']:
            numerical_errors.append('Mach{} missing CL/CD native finals'.format(mach))
        for row in native:
            try:
                rhs, start, residual = [float(row[k]) for k in ('rhs_norm','starting_residual_norm','final_residual_norm')]
                require(all(math.isfinite(x) for x in (rhs,start,residual)) and rhs>0 and start>=0 and residual>=0 and residual/rhs<=1.1e-11 and row['relative_residual']==residual/rhs and row['solver_failed'] is False and row['qualified'] is True and row['strict_native_gate']==1.1e-11, 'Strict native criterion failed')
                finals.append(dict(row,mach_index=mach))
            except (KeyError,TypeError,ValueError,ZeroDivisionError): numerical_errors.append('Mach{} native final failed'.format(mach))
    if len(finals)!=6: numerical_errors.append('Exactly six passing exported-gradient native checks required')
    expected_pairs = {(m,n,h) for m in range(3) for n in ('airfoil','twist','mixed_all_coordinates_and_alpha') for h in (.002,.001)}
    seen = set()
    for comparison in cov.get('comparisons',[]):
        try:
            key=(comparison['mach_index'],comparison['direction'],comparison['step'])
            require(key in expected_pairs and key not in seen,'Duplicate/unknown directional pair'); seen.add(key)
            predicted,measured=comparison['predicted_cl_cd'],comparison['measured_cl_cd']
            require(len(predicted)==2 and len(measured)==2,'Exactly two scalar components required')
            for p,m,floor in zip(predicted,measured,(2e-5,2e-6)):
                require(math.isfinite(p) and math.isfinite(m) and abs(p-m)<=.02*max(abs(p),abs(m))+floor,'Recomputed directional gate failed')
        except (KeyError,TypeError,ValueError): numerical_errors.append('Malformed/failed directional pair')
    if seen != expected_pairs: numerical_errors.append('All18 unique directional pairs required')
    report = {'schema':'wingbench-jisen-strict-host-certificate-v1',
        'strict_host_qualification_passed':bool(workers and not errors and not numerical_errors and not process_failures and controls_pass),
        'qualification_scope':'Known nominal control,3Mach,3directions,2steps; bounded integration only',
        'hardware_checks_passed':bool(workers and not errors and controls_pass),
        'original_grader_controls_passed':controls_pass,'control_checks':control_checks,
        'errors':errors,'numerical_errors':numerical_errors,'process_failures':process_failures,
        'final_native_records':finals,'coverage_summary':cov,'evidence_sha256':evidence,
        'protocol_sha256':protocol_hash,'package_manifest_sha256':package_hash,
        'mesh_sha256':mesh.get('sha256'),'mesh_container_path':mesh.get('container_path'),
        'runtime_expected_sha256':dict(observed_runtime,**runtime_expected),'can_launch_campaign':False,
        'historical_failures':'Preserved unchanged; this certificate only assesses this new host batch',
        'unverified':'Whole-box behavior,low/high tasks,production runner,pilot regrade,sustained episode memory/concurrency'}
    if emit:
        out=shared/'qualification';out.mkdir(exist_ok=True)
        target=out/'certificate.json';temp=target.with_suffix('.tmp')
        temp.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');temp.replace(target)
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--shared',type=Path,required=True)
    args=parser.parse_args();report=certify(args.shared,emit=True)
    print(json.dumps({k:v for k,v in report.items() if k not in ('coverage_summary','evidence_sha256','final_native_records')},indent=2))
    sys.exit(0 if report['strict_host_qualification_passed'] else 2)

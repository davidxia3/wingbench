"""Four-iteration, derivative-qualified multipoint SLSQP diagnostic.

Requires three successful derivative reports. Three MPI groups each run one
Mach point; rank zero alone owns the optimizer. This is NOT a benchmark episode.
"""
from pathlib import Path
import argparse
import json
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from benchmark.common import load_box
from rebuttal.adjoint.check_refined import Evaluator, control, write_json


def aggregate(values, gradients=None):
    values = np.asarray(values)
    if np.any(values <= 0) or not np.isfinite(values).all():
        raise ValueError('Nonpositive or nonfinite aerodynamic coefficients')
    objective = -np.mean(np.log(values[:, 0] / values[:, 1]))
    constraints = values[:, 0] - .41
    if gradients is None:
        return float(objective), constraints
    gradients = np.asarray(gradients)
    obj_grad = -np.mean(gradients[:, 0] / values[:, 0, None]
                       - gradients[:, 1] / values[:, 1, None], axis=0)
    return obj_grad, gradients[:, 0]


def main(args):
    from mpi4py import MPI
    from scipy.optimize import minimize
    world = MPI.COMM_WORLD
    if world.size % 3:
        raise ValueError('Use three equal MPI groups')
    if world.rank == 0:
        for k in range(3):
            gate = json.loads((args.checks / f'mach_{k}' / 'completed.json').read_text())
            assert gate['passed'] and len(gate['checks']) == 6, f'Mach {k} derivatives unqualified'
        args.out.mkdir(parents=True, exist_ok=False)
    world.barrier()
    point = world.rank // (world.size // 3)
    comm = world.Split(point, world.rank)
    point_out = args.out / f'mach_{point}'
    if comm.rank == 0:
        point_out.mkdir()
    comm.barrier()
    ev = Evaluator(comm, args.mesh, point_out, point)

    def execute(command):
        x = np.array(command['x'])
        y = np.r_[x[:38], x[38 + point]]
        if command['op'] == 'forward':
            result = ev.forward(y, f'pilot_{command["call"]}')
        else:
            local = ev.gradient(y, np.array(command['values'][point]))
            result = np.zeros((2, 41))
            result[:, :38] = local[:, :38]
            result[:, 38 + point] = local[:, 38]
        results = world.gather((point, result.tolist()) if comm.rank == 0 else None, root=0)
        if world.rank == 0:
            return np.array([r[1] for r in sorted([r for r in results if r is not None])])

    if world.rank:
        while True:
            command = world.bcast(None, root=0)
            if command['op'] == 'stop':
                return
            execute(command)
    else:
        started = time.time()
        history, cache = [], {}
        row, refs = control()
        initial = np.r_[np.zeros(38), [float(r['realized_aoa_deg']) for r in refs]]
        box = load_box()
        z0 = np.array(box.to_standardized(row['geometry']))
        lower = np.maximum(-.1, -3.5 - z0)
        upper = np.minimum(.1, 3.5 - z0)
        bounds = list(zip(lower, upper)) + [(max(-10., a-.5), min(25., a+.5)) for a in initial[38:]]
        write_json(args.out / 'plan.json', {
            'purpose': 'bounded integration pilot, not a competitive baseline result',
            'method': 'SLSQP with ADflow coupled discrete adjoints and IDWarp',
            'geometry_variables': 38, 'internal_alpha_variables': 3,
            'objective': 'negative mean log(CL/CD)', 'lift_equalities': [.41]*3,
            'bounds': bounds, 'max_iterations': 4, 'max_joint_forward_evaluations': 10,
            'warm_start_CFD_labels': 'known-pass diagnostic control; not zero-information initialization',
            'derivative_reports': str(args.checks), 'mpi_ranks': world.size,
        })

        class BudgetReached(Exception):
            pass

        def rpc(command):
            world.bcast(command, root=0)
            return execute(command)

        def values(x):
            if 'x' not in cache or not np.array_equal(x, cache['x']):
                if len(history) >= 10:
                    raise BudgetReached()
                val = rpc({'op': 'forward', 'x': x.tolist(), 'call': len(history)+1})
                cache.clear(); cache.update(x=x.copy(), values=val)
                obj, con = aggregate(val)
                score = float(np.exp(-obj))
                history.append({'x': x.tolist(), 'cl_cd': val.tolist(), 'score': score,
                    'max_lift_error': float(np.max(np.abs(con))),
                    'eligible': bool(np.max(np.abs(con)) <= .001 and
                                     np.all((val[:, 0] / val[:, 1] > 0) &
                                            (val[:, 0] / val[:, 1] <= 40))),
                    'elapsed_seconds': time.time()-started})
                write_json(args.out / 'history.json', history)
            return cache['values']

        def derivatives(x):
            val = values(x)
            if 'gradient' not in cache:
                cache['gradient'] = rpc({'op': 'gradient', 'x': x.tolist(), 'values': val.tolist()})
            return aggregate(val, cache['gradient'])

        try:
            result = minimize(lambda x: aggregate(values(x))[0], initial,
                jac=lambda x: derivatives(x)[0], method='SLSQP', bounds=bounds,
                constraints={'type': 'eq', 'fun': lambda x: aggregate(values(x))[1],
                             'jac': lambda x: derivatives(x)[1]},
                options={'maxiter': 4, 'ftol': 1e-6, 'disp': True})
            status = {'success': bool(result.success), 'message': str(result.message),
                      'status': int(result.status), 'iterations': int(result.nit)}
        except BudgetReached:
            status = {'success': False, 'message': 'Diagnostic forward budget reached'}
        eligible = [r for r in history if r['eligible']]
        if not eligible:
            raise RuntimeError('No eligible recommendation from pilot')
        best = max(eligible, key=lambda r: r['score'])
        geometry = (np.array(row['geometry']) + np.array(box.sd) * np.array(best['x'][:38])).tolist()
        assert box.contains(geometry)
        write_json(args.out / 'recommendation.json', {
            'geometry': geometry, 'optimization': status, 'warped_mesh_result': best,
            'initial_score': history[0]['score'], 'joint_forward_evaluations': len(history),
            'wall_seconds': time.time()-started,
            'interpretation': 'Requires independent original-grader evaluation. Iteration limit is not convergence.'})
        world.bcast({'op': 'stop'}, root=0)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--mesh', type=Path, required=True)
    p.add_argument('--checks', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    try:
        main(p.parse_args())
    except BaseException:
        import traceback
        traceback.print_exc()
        from mpi4py import MPI
        MPI.COMM_WORLD.Abort(1)

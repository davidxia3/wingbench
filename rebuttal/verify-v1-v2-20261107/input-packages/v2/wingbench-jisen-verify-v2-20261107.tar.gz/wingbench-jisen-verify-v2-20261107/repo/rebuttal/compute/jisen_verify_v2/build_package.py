"""Create a NEW immutable combined Jisen v2 bundle; never edit frozen v1."""
from datetime import datetime,timezone
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import shutil
import tarfile

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
OLD_OUTER_SHA='b7110e6d16c12d8143754a8b964cb58dde7da03302a8e653eca95b37601d2f55'
PROTOCOL_SHA='73ef9a9cdf472b1aae26eca0c85041038b4a7d9303e6d4299547d7d33adcbed4'


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
 return h.hexdigest()


def write_exact_new(path,data):
 if path.exists():
  if path.read_bytes()!=data:raise FileExistsError('Preserve existing different artifact: '+str(path))
 else:
  path.parent.mkdir(parents=True,exist_ok=True)
  with path.open('xb') as f:f.write(data)


def build(destination,manifest_sha256):
 old=ROOT/'rebuttal/compute/dist/wingbench-jisen-verify-v1-20261106.tar.gz'
 if sha(old)!=OLD_OUTER_SHA:raise ValueError('Original outer archive changed')
 canonical=ROOT/'rebuttal/adjoint/qualification_v2/coverage_manifest.json'
 if sha(canonical)!=manifest_sha256:raise ValueError('Explicit final canonical manifest SHA mismatch')
 protocol=ROOT/'rebuttal/adjoint/qualification_v2/protocol.json'
 if sha(protocol)!=PROTOCOL_SHA or sha(HERE/'numerical_protocol.json')!=PROTOCOL_SHA:
  raise ValueError('Approved numerical v2 protocol mismatch')
 coverage=json.loads(canonical.read_text())
 if coverage['protocol']['sha256']!=PROTOCOL_SHA:raise ValueError('Coverage protocol mismatch')
 old_package_path=ROOT/'rebuttal/compute/jisen_verify_v1/package_manifest.json'
 old_package=json.loads(old_package_path.read_text())
 sources=dict(old_package['source_sha256'])
 sources[str(old_package_path.relative_to(ROOT))]=sha(old_package_path)
 for name,digest in coverage['source_sha256'].items():
  if name in sources and sources[name]!=digest:raise ValueError('V1 source overwritten: '+name)
  sources[name]=digest
 for name,digest in sources.items():
  rel=Path(name)
  if rel.is_absolute() or '..' in rel.parts or sha(ROOT/rel)!=digest:raise ValueError('Source missing or changed: '+name)
 write_exact_new(HERE/'coverage_manifest.json',canonical.read_bytes())
 sources[str(canonical.relative_to(ROOT))]=manifest_sha256
 for path in sorted(HERE.iterdir()):
  if path.is_file() and path.name!='package_manifest.json':sources[str(path.relative_to(ROOT))]=sha(path)
 required=['launch.py','render_jobs.py','preflight.py','worker.py','certify.py','sampled_worker.py','resource_sampler.py','run_worker.sh','Dockerfile','numerical_protocol.json','coverage_manifest.json','tests_certify.py','tests_transport.py','JISEN_REPLY.md']
 if any(str((HERE/n).relative_to(ROOT)) not in sources for n in required):raise ValueError('Required v2 file missing')
 for name in ['serial_pilot.py','regrade.py','run_integration.py']:
  if 'rebuttal/adjoint/qualification_v2/'+name not in coverage['source_sha256']:
   raise ValueError('Canonical coverage must pin integration source: '+name)
 package={'schema':'wingbench-jisen-package-v2','source_git_commit':old_package['source_git_commit'],
  'protocol_sha256':PROTOCOL_SHA,'coverage_manifest_sha256':manifest_sha256,
  'canonical_coverage_manifest':'rebuttal/adjoint/qualification_v2/coverage_manifest.json',
  'source_sha256':sources,'assets':old_package['assets'],'runtime_expected_sha256':old_package['runtime_expected_sha256'],
  'scope':'Fresh prospective numerical v2 verification; no production episodes or automatic retries',
  'prior_outer_archive_sha256':OLD_OUTER_SHA,
  'separate_changes':{'infrastructure':'Repeatable Equal tolerations;15-second lower-bound memory samples; events and transport provenance.',
                      'approved_scientific_revision':'Native adjoint acceptance1.1e-11 to1.1e-9. Other numerical criteria unchanged; all39jobs fresh; old verdicts retained.'}}
 package_bytes=(json.dumps(package,indent=2,sort_keys=True)+'\n').encode()
 destination=destination.resolve();archive=destination.with_name(destination.name+'.tar.gz');checksum=Path(str(archive)+'.sha256')
 if destination.exists() or archive.exists() or checksum.exists():raise FileExistsError('Use a fresh immutable destination')
 write_exact_new(HERE/'package_manifest.json',package_bytes)
 destination.mkdir(parents=True)
 for relative,digest in sources.items():
  target=destination/'repo'/relative;target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(ROOT/relative,target)
  if sha(target)!=digest:raise ValueError('Copy mismatch: '+relative)
 target=destination/'repo'/str((HERE/'package_manifest.json').relative_to(ROOT));target.write_bytes(package_bytes)
 mesh=ROOT/'rebuttal/compute/dist/wingbench-jisen-verify-v1-20261106/mesh/wing_vol.cgns'
 if sha(mesh)!=package['assets'][0]['sha256']:raise ValueError('Frozen reference mesh differs')
 (destination/'mesh').mkdir();shutil.copyfile(mesh,destination/'mesh/wing_vol.cgns')
 shutil.copyfile(HERE/'JISEN_REPLY.md',destination/'README.md')
 entries=[p for p in sorted(destination.rglob('*')) if p.is_file()]
 (destination/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(destination))+'\n' for p in entries))
 def metadata(info):
  info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  info.mode=0o755 if info.isdir() or info.name.endswith('.sh') else 0o644
  return info
 with archive.open('xb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:tar.add(destination,arcname=destination.name,filter=metadata)
 archive_sha=sha(archive)
 with checksum.open('x') as f:f.write(archive_sha+'  '+archive.name+'\n')
 return {'archive':str(archive),'archive_sha256':archive_sha,'archive_bytes':archive.stat().st_size,
  'inner_files':len(entries),'package_manifest_sha256':sha(HERE/'package_manifest.json'),
  'coverage_manifest_sha256':manifest_sha256,'protocol_sha256':PROTOCOL_SHA,'old_archive_unchanged':sha(old)==OLD_OUTER_SHA,
  'real_cluster_validation':False,'CFD_started':False}

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--destination',type=Path,required=True)
 p.add_argument('--coverage-manifest-sha256',required=True);a=p.parse_args()
 print(json.dumps(build(a.destination,a.coverage_manifest_sha256),indent=2))

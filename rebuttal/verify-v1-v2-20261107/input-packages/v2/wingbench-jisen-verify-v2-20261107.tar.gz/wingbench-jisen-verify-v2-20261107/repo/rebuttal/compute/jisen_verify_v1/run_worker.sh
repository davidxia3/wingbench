#!/bin/bash
# Exactly one worker process per pod. worker.py owns task claims, MPI launch,
# preflight and conditional certification; this wrapper changes no numerics.
set -euo pipefail
if [[ "$(id -u)" != 1000 ]]; then
  echo 'Jisen verification requires the pinned image account UID 1000.' >&2
  exit 64
fi
cd /workspace/repo
exec /bin/bash /workspace/repo/rebuttal/container_entry.sh \
  python3 /workspace/repo/rebuttal/compute/jisen_verify_v1/worker.py "$@"

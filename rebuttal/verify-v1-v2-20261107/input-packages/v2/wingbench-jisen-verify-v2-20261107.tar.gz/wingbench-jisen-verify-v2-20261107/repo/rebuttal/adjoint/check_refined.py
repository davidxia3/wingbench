"""Strict qualification with bounded adjoint residual refinement.

No optimization is allowed by this script. Every check preserves numerical
results, timings and convergence flags. It raises on a failed qualification.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from benchmark.common import load_box
from rebuttal.adjoint.geometry import Surface, directions


def write_json(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def control():
    row = json.loads((ROOT / 'rebuttal/flow_validation_manifest.json').read_text())['cases'][12]
    with (ROOT / 'data/cfd_conditions.csv').open() as f:
        reference = [r for r in csv.DictReader(f) if r['evaluation'] == row['original_evaluation']]
    reference.sort(key=lambda r: float(r['mach']))
    assert len(reference) == 3
    return row, reference


class Evaluator:
    def __init__(self, comm, mesh, out, mach_index):
        from adflow import ADFLOW
        from baseclasses import AeroProblem
        from idwarp import USMesh
        from scipy.spatial import cKDTree
        self.comm, self.out = comm, out
        self.row, refs = control()
        self.reference = refs[mach_index]
        self.surface = Surface(self.row['geometry'], load_box().sd)
        self.base_surface, area = self.surface.evaluate(np.zeros(38))
        self.base_area = area
        self.calls = []
        self.adjoint_calls = []
        self.adjoint_attempts = []
        self.counter = 0
        self.solver = ADFLOW(options={
            'gridFile': str(mesh), 'outputDirectory': str(out),
            'monitorvariables': ['resrho', 'cl', 'cd', 'resturb'],
            'writeVolumeSolution': False, 'writeSurfaceSolution': False,
            'writeTecplotSurfaceSolution': False,
            'equationType': 'RANS', 'MGCycle': '3w',
            'useANKSolver': True, 'useNKSolver': True, 'NKSwitchTol': 1e-8,
            'L2Convergence': 1e-12, 'nCyclesCoarse': 500, 'nCycles': 3000,
            'adjointL2Convergence': 1e-12, 'adjointMaxIter': 1000,
            'restartAdjoint': True,
            'frozenTurbulence': False, 'ADPC': True,
        }, comm=comm)
        self.mesh = USMesh(options={'gridFile': str(mesh)}, comm=comm)
        self.solver.setMesh(self.mesh)
        self.coords0 = self.solver.getSurfaceCoordinates(self.solver.designFamilyGroup, includeZipper=False)
        dist, self.indices = cKDTree(self.base_surface).query(self.coords0)
        from mpi4py import MPI
        self.mapping_error = comm.allreduce(float(dist.max()) if len(dist) else 0., op=MPI.MAX)
        if self.mapping_error > 2e-6:
            raise ValueError(f'Surface mapping mismatch: {self.mapping_error}')
        self.ap = AeroProblem(name=f'check_m{mach_index}', mach=float(self.reference['mach']),
            alpha=float(self.reference['realized_aoa_deg']), reynolds=20e6, reynoldsLength=1.,
            T=300., areaRef=area, chordRef=1., xRef=.25, evalFuncs=['cl', 'cd'])
        self.ap.addDV('alpha', name='alpha')
        self.last_y = None
        if comm.rank == 0:
            write_json(out / 'setup.json', {
                'mach_index': mach_index, 'reference': self.reference,
                'mapping_max_distance': self.mapping_error, 'ranks': comm.size,
                'geometry': self.row, 'surface_area': area,
                'geometry_derivative': 'central differences of geometry only, normalized step 1e-5',
                'flow_derivative': 'ADflow discrete adjoint, coupled turbulence; IDWarp mesh derivatives',
                'root_alignment': 'rigid spanwise translation onto reference root symmetry plane',
                'forward_tolerance': 1e-12, 'adjoint_tolerance': 1e-12,
                'adjoint_true_relative_residual_gate': 1.1e-11,
                'max_adjoint_attempts_per_function': 3,
                'rerun_reason': 'strict-v2 internal adjoint convergence preceded true-residual gate; tighter internal target plus bounded refinement, no gate relaxation',
                'parent_strict_sha256': '2867a04bdf353a1798a8c5e9167cfd62d8c5846bb6879e1f5dd2743bc5e6d495',
                'initialization': 'sequential warm starts; exact order recorded in forward_calls.json',
                'parent_check_sha256': 'e976c62fef9bf31708b10bd3f2d68fb7b091a24f973a0e01fb4dac741695e081',
                'code_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    [Path(__file__), Path(__file__).with_name('geometry.py')]},
            })

    def forward(self, y, label):
        y = np.asarray(y, dtype=float)
        points, area = self.surface.evaluate(y[:38])
        # Preserve reference grid coordinates exactly at the anchor; only apply
        # analytic surface displacements, avoiding file-rounding perturbations.
        coordinates = self.coords0 + points[self.indices] - self.base_surface[self.indices]
        self.solver.setSurfaceCoordinates(coordinates, self.solver.designFamilyGroup)
        self.ap.alpha = float(y[38])
        self.ap.areaRef = area
        start = time.monotonic()
        self.solver(self.ap)
        funcs = {}
        self.solver.evalFunctions(self.ap, funcs)
        initial, _, final = self.solver.getResNorms()
        relative = float(final / max(initial, 1e-300))
        values = np.array([funcs[self.ap.name + '_cl'], funcs[self.ap.name + '_cd']], dtype=float)
        failed = bool(self.ap.solveFailed or self.ap.fatalFail)
        self.counter += 1
        record = {'call': self.counter, 'label': label, 'input': y.tolist(),
                  'cl': float(values[0]), 'cd': float(values[1]), 'area': area,
                  'relative_residual': relative, 'solve_failed': failed,
                  'wall_seconds': time.monotonic() - start}
        self.calls.append(record)
        if self.comm.rank == 0:
            write_json(self.out / 'forward_calls.json', self.calls)
            print('FORWARD_RESULT', json.dumps(record), flush=True)
        if failed or not np.isfinite(values).all() or relative > 1.1e-12:
            raise RuntimeError(f'Forward solve failed qualification: {record}')
        self.last_y = y.copy()
        return values

    def gradient(self, y, values):
        from mpi4py import MPI
        if self.last_y is None or not np.array_equal(y, self.last_y):
            raise ValueError('Gradient requires a forward solve at the same point')
        surface_jac, area_jac = self.surface.jacobian(y[:38], self.indices)
        _, area = self.surface.evaluate(y[:38])
        gradient = np.empty((2, 39))
        for i, f in enumerate(['cl', 'cd']):
            start = time.monotonic()
            # PETSc's convergence estimate can differ from ADflow's explicit
            # residual. Refine the same stored adjoint, without changing the
            # forward state, and require the unchanged true-residual gate.
            for attempt in range(1, 4):
                attempt_start = time.monotonic()
                sens = {}
                self.solver.evalFunctionsSens(self.ap, sens, evalFuncs=[f])
                init, initial_guess, final, failed = self.solver.getAdjointResNorms()
                norms = np.asarray([init, initial_guess, final], dtype=float)
                if not np.isfinite(norms).all() or init <= 0 or final < 0:
                    raise RuntimeError(f'Invalid adjoint residual norms: {norms}')
                relative = float(final / init)
                record = {'function': f, 'attempt': attempt,
                          'rhs_norm': float(init), 'starting_residual_norm': float(initial_guess),
                          'final_residual_norm': float(final), 'relative_residual': relative,
                          'failed': bool(failed or self.ap.adjointFailed),
                          'wall_seconds': time.monotonic() - attempt_start}
                record['qualified'] = bool(not record['failed'] and relative <= 1.1e-11)
                self.adjoint_attempts.append(record.copy())
                if self.comm.rank == 0:
                    write_json(self.out / 'adjoint_attempts.json', self.adjoint_attempts)
                    print('ADJOINT_ATTEMPT', json.dumps(record), flush=True)
                # Preserve rank-zero evidence before any rank may abort MPI.
                self.comm.barrier()
                if record['qualified'] or record['failed']:
                    break
            final_record = dict(record, wall_seconds=time.monotonic() - start)
            self.adjoint_calls.append(final_record)
            if self.comm.rank == 0:
                write_json(self.out / 'adjoint_calls.json', self.adjoint_calls)
            self.comm.barrier()
            if not record['qualified']:
                raise RuntimeError(f'Adjoint failed qualification after bounded refinement: {record}')
            xsbar = self.solver.computeJacobianVectorProductBwd(
                resBar=-self.solver.getAdjoint(f), funcsBar={f: 1.}, xSDeriv=True)
            local = np.einsum('ij,ijk->k', xsbar, surface_jac)
            gradient[i, :38] = self.comm.allreduce(local, op=MPI.SUM) - values[i] / area * area_jac
            gradient[i, 38] = float(np.asarray(sens[self.ap.name + '_' + f]['alpha']).ravel()[0])
        if not np.isfinite(gradient).all():
            raise ValueError('Nonfinite total derivative')
        return gradient


def run(args):
    from mpi4py import MPI
    comm = MPI.COMM_WORLD
    out = args.out / f'mach_{args.mach_index}'
    if comm.rank == 0:
        out.mkdir(parents=True, exist_ok=False)
    comm.barrier()
    ev = Evaluator(comm, args.mesh, out, args.mach_index)
    if args.setup_only:
        return
    y = np.zeros(39)
    y[38] = float(ev.reference['realized_aoa_deg'])
    values = ev.forward(y, 'anchor')
    reference = np.array([float(ev.reference['cl']), float(ev.reference['cd'])])
    relative = np.abs(values - reference) / np.abs(reference)
    if comm.rank == 0:
        write_json(out / 'reproduction.json', {'values': values.tolist(), 'reference': reference.tolist(),
            'relative_errors': relative.tolist(), 'passed': bool(np.all(relative <= .005))})
    if np.any(relative > .005):
        raise RuntimeError(f'Anchor differs from reference by more than 0.5%: {relative}')
    gradient = ev.gradient(y, values)
    if comm.rank == 0:
        write_json(out / 'gradient.json', {'input': y.tolist(), 'values': values.tolist(),
                   'gradient_cl_cd': gradient.tolist()})
    checks = []
    ordered_directions = directions()
    for name in ['airfoil', 'twist', 'mixed_all_coordinates_and_alpha']:
        direction = ordered_directions[name]
        predicted = gradient @ direction
        for h in [2e-3, 1e-3]:
            plus = ev.forward(y + h * direction, name + f'_plus_{h}')
            minus = ev.forward(y - h * direction, name + f'_minus_{h}')
            measured = (plus - minus) / (2 * h)
            absolute_error = np.abs(predicted - measured)
            # A small absolute floor avoids meaningless relative errors for
            # insensitive directions. Both scales must pass, on CL and CD.
            allowed = .02 * np.maximum(np.abs(predicted), np.abs(measured)) + np.array([2e-5, 2e-6])
            checks.append({'direction': name, 'step': h, 'predicted': predicted.tolist(),
                'measured': measured.tolist(), 'absolute_error': absolute_error.tolist(),
                'allowed_error': allowed.tolist(), 'passed': bool(np.all(absolute_error <= allowed))})
            if comm.rank == 0:
                write_json(out / 'directional_checks.json', checks)
                print('DIRECTIONAL_RESULT', json.dumps(checks[-1]), flush=True)
    passed = all(c['passed'] for c in checks)
    if comm.rank == 0:
        write_json(out / 'completed.json', {'passed': passed, 'checks': checks,
                   'forward_calls': len(ev.calls), 'adjoint_calls': len(ev.adjoint_calls)})
    if not passed:
        raise RuntimeError('Directional derivative qualification failed; optimization is blocked')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--mesh', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--mach-index', type=int, choices=[0, 1, 2], required=True)
    p.add_argument('--setup-only', action='store_true')
    args = p.parse_args()
    try:
        run(args)
    except BaseException:
        import traceback
        traceback.print_exc()
        from mpi4py import MPI
        MPI.COMM_WORLD.Abort(1)

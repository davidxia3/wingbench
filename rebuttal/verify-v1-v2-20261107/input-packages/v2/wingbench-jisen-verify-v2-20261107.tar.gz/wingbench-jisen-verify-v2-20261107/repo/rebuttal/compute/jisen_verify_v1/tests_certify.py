"""Synthetic, no-CFD tests of the independent host-certification layer.

The already-tested raw coverage summarizer is mocked; the certifier must still
reject forged summary success when native/comparison/provenance evidence fails.
All package, worker, process and original-grader files are real tempdir files.
"""
from pathlib import Path
import copy
import importlib.util
import json
import math
import shutil
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
spec = importlib.util.spec_from_file_location('certify_under_test', HERE/'certify.py')
cert = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cert)


def write(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n')


class CertificateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)/'repo';self.here = self.root/'rebuttal/compute/jisen_verify_v1'
        self.shared = Path(self.temp.name)/'results';self.shared.mkdir()
        manifest_path=Path('rebuttal/adjoint/coverage_observed_manifest_v1_20261106.json')
        self.manifest=json.loads((REPO/manifest_path).read_text())
        for relative in list(self.manifest['source_sha256'])+[str(manifest_path)]:
            target=self.root/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/relative,target)
        for name in ('certify.py','worker.py','preflight.py','run_grade.py','numerical_protocol.json'):
            target=self.here/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(HERE/name,target)
        self.protocol=json.loads((self.here/'numerical_protocol.json').read_text())
        grader_path=Path(self.protocol['original_grader']['base_protocol'])
        (self.root/grader_path).parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(REPO/grader_path,self.root/grader_path)
        grader_protocol=json.loads((self.root/grader_path).read_text())
        self.protocol_hash=cert.sha(self.here/'numerical_protocol.json')
        self.runtime=dict(self.manifest['expected_runtime_sha256'])
        self.runtime.update(idwarp_python='a'*64,idwarp_binary_libidwarp_so='b'*64,cst_basic='c'*64,cst_section='d'*64,cst_io='e'*64)
        self.package={'protocol_sha256':self.protocol_hash,'source_sha256':{
            str((self.here/n).relative_to(self.root)):cert.sha(self.here/n)
            for n in ('certify.py','worker.py','preflight.py','run_grade.py','numerical_protocol.json')},
            'runtime_expected_sha256':self.runtime,'assets':[{'path':self.manifest['mesh']['container_path'],'sha256':self.manifest['mesh']['sha256']}]}
        write(self.here/'package_manifest.json',self.package)
        self.package_hash=cert.sha(self.here/'package_manifest.json')
        files={str(cert.CONTAINER_ROOT/p):h for p,h in self.manifest['source_sha256'].items()}
        files.update({str(cert.CONTAINER_ROOT/p):h for p,h in self.package['source_sha256'].items()})
        files[str(cert.CONTAINER_ROOT/manifest_path)]=cert.COVERAGE_SHA
        files[self.manifest['mesh']['container_path']]=self.manifest['mesh']['sha256']
        files[str(cert.CONTAINER_ROOT/grader_path)]=self.protocol['original_grader']['protocol_sha256']
        self.plan={'workers':8,'node_a':'node-a','node_b':'node-b','run_id':'synthetic','image':'repo/image@sha256:'+'f'*64,'protocol_sha256':self.protocol_hash,'run_campaign':False}
        write(self.shared/'run_plan.json',self.plan)
        ready=[{'worker_id':i,'node':'node-a' if i<4 else 'node-b','image':self.plan['image'],'ready_at_utc':'2026-11-07T00:00:00+00:00'} for i in range(8)]
        self.claims={i:[] for i in range(8)}
        tasks=([{'id':'anchor_'+str(i),'kind':'anchor','index':i,'pool':'b' if i==1 else 'a'} for i in range(3)]+
               [{'id':'reference_'+p,'kind':'reference','pool':p} for p in ('a','b')]+
               [{'id':'point_'+str(i),'kind':'point','index':i,'pool':None} for i in range(36)])
        for task in tasks:
            owner=4 if task['pool']=='b' else 0;node=ready[owner]['node'];self.claims[owner].append(task['id'])
            identity={'worker_id':owner,'node':node,'task':task}
            write(self.shared/'claims'/task['id']/'owner.json',identity)
            write(self.shared/'claims'/task['id']/'process.json',dict(identity,return_code=0,timed_out=False,command=['mock-no-CFD'],started_at_utc='2026-11-07T00:00:02+00:00',wall_seconds=1.))
        for i in range(8):
            leaf=self.shared/'workers'/('worker-'+str(i));node=ready[i]['node']
            ranks=[{'rank':r,'world_size':16,'uid':1000,'errors':[],
                'thread_environment':{n:'1' for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},
                'mpi_library_version':'Open MPI v4.1.6',
                'hardware':{'hostname':'pod-'+str(i),'affinity_logical_cpus':list(range(16)),
                    'affinity_physical_core_count':16,'cgroup':{'cpu_quota_units':16,'memory_limit_bytes':96*1024**3}}} for r in range(16)]
            runtime={'sha256':self.runtime,'python':'3.9.12','petsc_version':[3,15,5],
                'mpirun_version':'mpirun (Open MPI) 4.1.6','cst_commit':self.protocol['package_runtime']['cst_commit'],
                'modules':{k:{'version':v} for k,v in {'numpy':'1.21.5','scipy':'1.7.3','mpi4py':'3.1.5'}.items()}}
            fs={key:True for key in ('passed','exclusive_create','atomic_rename_readback','exclusive_mkdir','flock_excludes_second_process','flock_released')}
            pre={'passed':True,'errors':[],'node_name':node,'image_declared':self.plan['image'],
                'requested_ranks':16,'rank_sum':120,'ranks':ranks,'filesystems':[fs,fs],
                'provenance':{'package_manifest_sha256':self.package_hash,'protocol_sha256':self.protocol_hash,
                    'files':[{'path':p,'passed':True,'actual_sha256':h,'expected_sha256':h} for p,h in files.items()], 'runtime':runtime}}
            write(leaf/'preflight.json',pre);write(leaf/'preflight_process.json',{'return_code':0,'timed_out':False})
            write(leaf/'ready.json',ready[i]);write(leaf/'barrier.json',{'passed':True,'workers_seen':ready,'seen_at_utc':'2026-11-07T00:00:01+00:00'})
            write(leaf/'worker_finished.json',{'worker_id':i,'batch_processing_finished':True,'processed':self.claims[i]})
        conditions=[];comparisons=[]
        for anchor in self.manifest['anchors']:
            ref=anchor['reference'];cl,cd=float(ref['cl']),float(ref['cd'])
            conditions.append({'mach':float(ref['mach']),'cl_target':.41,'outcome_class':'valid',
                'measurements':{'cl':cl,'cd':cd,'ld':cl/cd,'realized_aoa_deg':float(ref['realized_aoa_deg'])}})
            comparisons.append({'mach':float(ref['mach']),'relative_errors':{'cl':0.,'cd':0.},'within_limit':True})
        score=math.exp(sum(math.log(c['measurements']['ld']) for c in conditions)/3)
        raw={'geometry':{'geom_38d':self.manifest['geometry']['geometry'],'sha256':self.manifest['geometry']['wing']},
            'protocol':{'snapshot':grader_protocol},
            'mesh':{'outcome':'valid'},'benchmark_grade':{'delivered':True,'outcome':'pass','ld':score},'conditions':conditions}
        for pool in ('a','b'):
            write(self.shared/('reference_'+pool)/'grade.json',raw)
            write(self.shared/('reference_'+pool)/'verification_result.json',{'passed':True,'delivered':True,'kind':'original_grader_control','relative_gate':.005,'original_score':score,'comparisons':comparisons})
        for mach in range(3):
            native=[{'function':f,'rhs_norm':1.,'starting_residual_norm':1.,'final_residual_norm':1e-12,'relative_residual':1e-12,'solver_failed':False,'qualified':True,'strict_native_gate':1.1e-11} for f in ('cl','cd')]
            write(self.shared/'coverage'/('anchor_'+str(mach))/'coverage_result.json',{'native_finals':native})
        self.coverage={'summary_status':'observations_complete','comparison_count':18,'valid_anchor_jobs':3,'valid_point_jobs':36,
            'all_components_within_original_limits':True,'failed_native_gates':[],'evidence_sha256':{},'runtime_sha256':self.runtime,
            'comparisons':[{'mach_index':m,'direction':n,'step':h,'predicted_cl_cd':[.01,.001],'measured_cl_cd':[.01,.001]}
                for m in range(3) for n in ('airfoil','twist','mixed_all_coordinates_and_alpha') for h in (.002,.001)]}
        for name,value in [('ROOT',self.root),('HERE',self.here)]:
            patcher=patch.object(cert,name,value);patcher.start();self.addCleanup(patcher.stop)
        patcher=patch.object(cert,'summarize',side_effect=lambda *a:copy.deepcopy(self.coverage));patcher.start();self.addCleanup(patcher.stop)

    def mutate(self,relative,fn):
        path=self.shared/relative;data=json.loads(path.read_text());fn(data);write(path,data)
    def result(self): return cert.certify(self.shared)
    def assertBlocked(self):
        result=self.result();self.assertFalse(result['strict_host_qualification_passed'],result);self.assertFalse(result['can_launch_campaign']);return result
    def test_complete_fixture_passes_only_bounded_qualification(self):
        result=self.result();self.assertTrue(result['strict_host_qualification_passed'],result)
        self.assertFalse(result['can_launch_campaign']);self.assertEqual(len(result['final_native_records']),6)
        self.assertEqual(result['mesh_sha256'],self.manifest['mesh']['sha256'])
    def test_operator_host_root_differs_from_container_source_paths(self):
        self.assertNotEqual(self.root,cert.CONTAINER_ROOT)
        pre=json.loads((self.shared/'workers/worker-0/preflight.json').read_text())
        self.assertTrue(any(r['path'].startswith('/workspace/repo/') for r in pre['provenance']['files']))
        self.assertTrue(self.result()['strict_host_qualification_passed'])
    def test_component_failure_even_with_forged_summary_success(self):
        self.coverage['comparisons'][0]['measured_cl_cd'][0]=.02;self.assertBlocked()
    def test_native_three_e_minus_eleven_even_if_qualified_forged(self):
        self.mutate('coverage/anchor_0/coverage_result.json',lambda d:d['native_finals'][0].update(final_residual_norm=3e-11,relative_residual=3e-11,qualified=True));self.assertBlocked()
    def test_native_missing_function(self):
        self.mutate('coverage/anchor_0/coverage_result.json',lambda d:d['native_finals'].pop());self.assertBlocked()
    def test_missing_worker_preflight(self):
        (self.shared/'workers/worker-7/preflight.json').unlink();self.assertBlocked()
    def test_failed_process(self):
        self.mutate('claims/point_3/process.json',lambda d:d.update(return_code=1));self.assertBlocked()
    def test_missing_process(self):
        (self.shared/'claims/point_3/process.json').unlink();self.assertBlocked()
    def test_failed_control_with_forged_pass(self):
        self.mutate('reference_a/grade.json',lambda d:d['conditions'][0]['measurements'].update(cd=.02));self.assertBlocked()
    def test_control_score_forged(self):
        self.mutate('reference_b/grade.json',lambda d:d['benchmark_grade'].update(ld=35.));self.assertBlocked()
    def test_control_protocol_changed(self):
        self.mutate('reference_b/grade.json',lambda d:d['protocol']['snapshot'].update(edited=True));self.assertBlocked()
    def test_missing_coverage_runtime_returns_failed_report(self):
        self.coverage['runtime_sha256']=None;self.assertBlocked()
    def test_runtime_changed_despite_preflight_pass(self):
        self.mutate('workers/worker-0/preflight.json',lambda d:d['provenance']['runtime']['sha256'].update(adflow_library='0'*64));self.assertBlocked()
    def test_mesh_pin_changed_despite_preflight_pass(self):
        def change(d):
            for row in d['provenance']['files']:
                if row['path']==self.manifest['mesh']['container_path']:row.update(actual_sha256='0'*64,expected_sha256='0'*64)
        self.mutate('workers/worker-1/preflight.json',change);self.assertBlocked()
    def test_protocol_hash_changed(self):
        self.mutate('workers/worker-2/preflight.json',lambda d:d['provenance'].update(protocol_sha256='0'*64));self.assertBlocked()
    def test_package_hash_changed(self):
        self.mutate('workers/worker-2/preflight.json',lambda d:d['provenance'].update(package_manifest_sha256='0'*64));self.assertBlocked()
    def test_source_changed_after_package_freeze(self):
        with (self.here/'worker.py').open('a') as f:f.write('\n# altered\n')
        self.assertBlocked()
    def test_preflight_metadata_hash_change_is_bound(self):
        before=self.result();self.mutate('workers/worker-0/preflight.json',lambda d:d.update(note='new metadata'))
        after=self.result();self.assertTrue(after['strict_host_qualification_passed']);self.assertNotEqual(before['evidence_sha256'],after['evidence_sha256'])
    def test_truncated_scalar_vector(self):
        self.coverage['comparisons'][0]['measured_cl_cd']=[];self.assertBlocked()
    def test_duplicate_pair(self):
        self.coverage['comparisons'][-1]=copy.deepcopy(self.coverage['comparisons'][0]);self.assertBlocked()
    def test_missing_pair_even_with_count_forged(self):
        self.coverage['comparisons'].pop();self.assertBlocked()
    def test_owner_process_mismatch(self):
        self.mutate('claims/point_0/process.json',lambda d:d.update(worker_id=7));self.assertBlocked()
    def test_task_started_before_barrier(self):
        self.mutate('claims/point_0/process.json',lambda d:d.update(started_at_utc='2026-11-07T00:00:00+00:00'));self.assertBlocked()
    def test_forged_barrier_inventory(self):
        self.mutate('workers/worker-1/barrier.json',lambda d:d['workers_seen'].pop());self.assertBlocked()
    def test_forged_thread_preflight(self):
        self.mutate('workers/worker-1/preflight.json',lambda d:d['ranks'][0]['thread_environment'].update(OMP_NUM_THREADS='2'));self.assertBlocked()
    def test_no_campaign_plan(self):
        self.mutate('run_plan.json',lambda d:d.update(run_campaign=True));self.assertBlocked()
    def test_emit_retains_false_qualification(self):
        self.coverage['comparisons'].pop();report=cert.certify(self.shared,emit=True)
        self.assertFalse(report['strict_host_qualification_passed']);self.assertEqual(report,json.loads((self.shared/'qualification/certificate.json').read_text()))


if __name__=='__main__':unittest.main(verbosity=2)

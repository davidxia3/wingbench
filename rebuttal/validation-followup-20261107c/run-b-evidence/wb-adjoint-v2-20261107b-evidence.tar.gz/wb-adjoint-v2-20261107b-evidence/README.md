# Evidence: run wb-adjoint-v2-20261107b and failed first attempt wb-adjoint-v2-20261107a

Prepared 2026-11-08 by Jisen Li. Cluster research-common-h100 (k3s v1.27.6), namespace `jisenli2`. Nodes: `research-common-h100-059` (node A) and `research-common-h100-090` (node B), each with 2× AMD EPYC 9534.

Nothing in this package was edited after collection. The original failed certificate is included unchanged and remains failed.

## Identities

| Item | Value |
|---|---|
| v2 package, outer archive | sha256 `986064b5f06a51b41f2310d884ca0e5e5b4bd3b208b0900164ca126c24606a70`, inner SHA256SUMS 159/159 verified before the image build |
| `protocol_sha256` (launcher result) | `73ef9a9cdf472b1aae26eca0c85041038b4a7d9303e6d4299547d7d33adcbed4` |
| `package_manifest_sha256` (launcher result) | `2cf8cb0183b4ea1483fe5253961aa3724963aa29bfa131d74d61ad72acf4c071` |
| Image | `ghcr.io/mtilyxuegao/wingbench-adjoint-verify@sha256:268ddf9d46457f9c09cfb670e98256369af633319804cceae666ef9fe754286e` |
| kubectl, operator side | official v1.27.6 linux/amd64 binary, sha256 `2b7adb71c8630904da1b94e262c8c3c477e9609b3c0ed8ae1213a1e156ae38dd` |
| kubectl shim, operator side | `operator/kubectl-shim.sh`, sha256 `e9de084c135a5945fa61d216c664fa35484ded11fc528ef90587f9a23d7bfb2a` |

The shim hash is that of the local source we copied into the run-b operator pod as `/tools/kubectl`. The launcher does not record the hash of its `--kubectl` binary. The operator pod has terminated, so its copy can no longer be re-hashed.

## Result

- Run b started 2026-11-07T09:06:50Z and finished 11:16:56Z (2 h 10 min). Status `stopped_after_failed_or_incomplete_qualification`, certify exit 2.
- **Numerical qualification passed.**
  - All 39 anchor and point tasks finished with return code 0 and no timeouts.
  - The 6 native adjoint finals (CL and CD for 3 anchors) qualified on attempt 1, with relative residuals 2.8e-11 to 3.6e-11 against the 1.1e-9 gate. Every one is above the old 1.1e-11 gate.
  - All 18 comparisons and 36 scalar comparisons passed. `coverage_summary.passed=true`, `can_release_pilot=true`.
- **The strict certificate failed** because `agents/tasks/task_documents.json` was missing from the package.
  - `reference_a` and `reference_b` failed in about 0.1 s with `FileNotFoundError` and wrote no `grade.json`.
  - The two "Worker2/Worker4 processed inventory differs from claims" errors follow from this. `certify.py` adds only successful tasks to `claimed_by`, while `worker_finished.json` lists every processed task.
  - The pilot and the regrade were not reached. All 8 worker preflights passed.
- **Resources.**
  - Wall time per task: anchors 0.90 h mean (41–66 min), points 0.37 h mean (17–30 min). 255 allocated core-hours in total.
  - Memory is the maximum of `memory.current` sampled every 15 s. It is a sampled lower bound, not a true peak: 70.8 GiB on workers that ran an anchor, 56.8 GiB on point-only workers. `oom_kill` stayed at 0. `memory.peak` is unavailable on kernel 5.15.
  - CFS throttling hit about 33% of periods, but total throttled time was only 2.5–4.1 min per worker.
  - There were no OOMs, evictions or restarts.
- **Run a** stopped about 1 s after launch with `JSONDecodeError`, before any Job was created. `INFRA_RETRY_NOTE.md` explains the cause and the operator-side shim used for run b.

## Contents

| Path | Contents |
|---|---|
| `run-b/pvc/wb-adjoint-v2-20261107b/` | Full run directory copied from the PVC: 765 files |
| … `run_plan.json`, `final_summary.json` | Plan and final launcher result |
| … `claims/` | 41 task directories: anchors, points, `reference_a`, `reference_b`, each with logs and results |
| … `coverage/` | Per-task coverage results, plus `certificate.json`, the numerical qualification certificate (`passed=true`) |
| … `qualification/certificate.json` | The original strict host certificate: `strict_host_qualification_passed=false`, 4 errors, includes `coverage_summary`. Unchanged |
| … `reference_a/`, `reference_b/` | Failed control outputs |
| … `workers/worker-N/` | Preflight, provenance and the processed list for each worker |
| … `resource_samples/`, `launcher/sampled-resource-peaks.json` | 15 s memory and CPU samples |
| … `launcher/` | Certify log, per-worker logs, recorded kubectl calls, Job, pod and event records |
| `run-b/pvc-SHA256SUMS-computed-on-cluster` | SHA256 of every run file, computed on the cluster before copying |
| `run-b/pvc-file-list.txt` | File listing with sizes |
| `run-b/k8s/` | Operator launcher log, operator pod JSON, Job and pod JSON, namespace events |
| `run-a/` | First attempt: PVC run directory and tarball, operator pod JSON, launcher and init logs, events |
| `INFRA_RETRY_NOTE.md` | Run a failure and the infrastructure-only retry |
| `operator/` | The kubectl shim, both operator pod manifests and the PVC manifest |
| `SHA256SUMS` | SHA256 of every file in this package |

## Verify

```bash
sha256sum -c SHA256SUMS
cd run-b/pvc && sha256sum -c ../pvc-SHA256SUMS-computed-on-cluster   # 765 files
```
